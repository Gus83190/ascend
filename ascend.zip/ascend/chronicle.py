"""Chronique du mois et bilan de l'année : un récit écrit à partir du journal (aucune IA).

On relit le héros la veille de la période et à sa fin : la différence donne l'XP gagnée, les rangs
franchis, les lieux découverts… Les saisies acceptées de la période donnent les chiffres et les records.
"""
import json
from datetime import date, timedelta

from . import catalog as K
from . import config as C
from . import defis as DF
from . import programs as PG

MOIS_COURTS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"]


def _n(x: float, dec: int = 0) -> str:
    s = f"{x:,.{dec}f}".replace(",", " ").replace(".", ",")
    return s[:-2] if dec == 1 and s.endswith(",0") else s


def _plural(n: float, word: str, plural: str | None = None) -> str:
    return f"{_n(n)} {word if n < 2 else (plural or word + 's')}"


def period_bounds(kind: str, ref: str | None, today: date) -> tuple[date, date, str]:
    if kind == "year":
        y = int(ref) if ref else today.year
        if not 2000 <= y <= today.year:
            raise ValueError("Année invalide")
        return date(y, 1, 1), min(date(y, 12, 31), today), f"Année {y}"
    if ref:
        y, m = (int(x) for x in ref.split("-"))
    else:
        y, m = today.year, today.month
    start = date(y, m, 1)
    if start > today or y < 2000:
        raise ValueError("Mois invalide")
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    return start, min(nxt - timedelta(days=1), today), f"{MOIS[m - 1].capitalize()} {y}"


def report(store, hero_id: int, kind: str, ref: str | None, today: date) -> dict:
    start, end, title = period_bounds(kind, ref, today)
    before = store.hero(hero_id, until=start - timedelta(days=1))
    hero, acts_all = PG._accepted(store, hero_id, end, date(2000, 1, 1))
    acts = [a for a in acts_all if start <= a[0] <= end]
    old = [a for a in acts_all if a[0] < start]

    xp = {s: round(hero.stat_xp[s] - before.stat_xp[s]) for s in C.STATS}
    total = sum(xp.values())
    ranks_up = [(s, before.rank_of(s), hero.rank_of(s)) for s in C.STATS
                if C.RANKS.index(hero.rank_of(s)) > C.RANKS.index(before.rank_of(s))]
    active_days = len({a[0] for a in acts})
    first = store.db.execute("SELECT MIN(day) FROM events WHERE hero_id=?", (hero_id,)).fetchone()[0]
    span_start = max(start, date.fromisoformat(first)) if first else start
    span = max(1, (end - span_start).days + 1)                # pas de jours « avant le héros »

    def tot(kind_, field):
        return sum(d.get(field, 0) or 0 for _, k, d, _ in acts if k == kind_)

    def best(kind_, field, rows):
        return max([d.get(field, 0) or 0 for _, k, d, _ in rows if k == kind_], default=0)

    figures = []
    run_km, exp_km, dplus = tot("endurance", "distance_km"), tot("expedition", "distance_km"), tot("expedition", "elevation_m")
    read_h, focus_h, med_min = tot("reading", "minutes") / 60, tot("focus", "minutes") / 60, tot("meditation", "minutes")
    sessions_force = len({a[0] for a in acts if a[1] == "strength" or (a[1] in ("bodyweight", "skill"))})
    books = [w for w, d in hero.works.items() if start <= d <= end]
    new_places = sorted(hero.seen_places - before.seen_places)
    if run_km:
        figures.append(("Endurance", f"{_n(run_km, 1)} km parcourus en {_plural(sum(1 for a in acts if a[1] == 'endurance'), 'séance')}"))
    if sessions_force:
        figures.append(("Force", f"{_plural(sessions_force, 'jour')} d'entraînement de force ou d'agilité"))
    if exp_km:
        figures.append(("Expédition", f"{_n(exp_km, 1)} km d'expédition, {_n(dplus)} m de dénivelé"))
    if read_h:
        figures.append(("Intelligence", f"{_n(read_h, 1)} h de lecture" + (f", {_plural(len(books), 'œuvre validée', 'œuvres validées')}" if books else "")))
    if focus_h:
        figures.append(("Mental", f"{_n(focus_h, 1)} h de concentration au minuteur"))
    if med_min:
        figures.append(("Mental", f"{_n(med_min)} min de méditation"))
    nights = [sc for d, sc in hero.sleep_scores if start <= d <= end]
    if nights:
        figures.append(("Vitalité", f"{_plural(len(nights), 'nuit')} notée(s), {_n(sum(nights) / len(nights))}/100 en moyenne"))
    moods = [w["mood"] for d, w in hero.wellbeing.items() if start <= d <= end and w.get("mood")]

    # Records battus pendant la période (comparés à tout ce qui précède)
    records = []
    for kind_, field, label, unit in [("endurance", "distance_km", "plus longue sortie", "km"),
                                      ("expedition", "distance_km", "plus longue expédition", "km"),
                                      ("focus", "minutes", "plus longue concentration", "min"),
                                      ("meditation", "minutes", "plus longue méditation", "min")]:
        b_new, b_old = best(kind_, field, acts), best(kind_, field, old)
        if b_new and b_new > b_old and b_old:
            records.append(f"Nouveau record de {label} : {_n(b_new, 1)} {unit} (avant : {_n(b_old, 1)})")
    orm_old: dict[str, float] = {}
    for rows, target in ((old, "old"), (acts, "new")):
        for _, k, d, _ in rows:
            if k == "strength":
                ex = K.norm_lift(d.get("exercise", ""))
                v = max([w * (1 + r / 30) for w, r in d.get("sets", []) if w > 0 and 1 <= r <= 12], default=0)
                if target == "old":
                    orm_old[ex] = max(orm_old.get(ex, 0), v)
                elif orm_old.get(ex) and v > orm_old[ex]:
                    records.append(f"Nouveau record en {ex} : {_n(v)} kg estimés (avant : {_n(orm_old[ex])})")
                    orm_old[ex] = v

    # Défis réussis, carnet
    try:
        dv = DF.overview(store, hero_id, end)
        defis_won = [h["name"] for h in dv["history"] if h["state"] == "réussi" and h["end"] and start.isoformat() <= h["end"] <= end.isoformat()]
    except Exception:
        defis_won = []
    notes = [json.loads(r["payload"]) for r in store.db.execute(
        "SELECT payload FROM events WHERE hero_id=? AND type='note' AND day>=? AND day<=?", (hero_id, start.isoformat(), end.isoformat()))]
    gratitude = [g for n in notes for g in n.get("gratitude", [])]

    # Récit
    story = []
    who = hero.name
    period = "Cette année" if kind == "year" else "Ce mois-ci"
    if not acts and not total:
        story.append(f"{period}, {who} s'est reposé : aucune activité enregistrée. Chaque aventure recommence par un premier pas.")
    else:
        top = max(xp, key=xp.get)
        story.append(f"{period}, {who} a été actif {_plural(active_days, 'jour')} sur {span} et a gagné {_n(total)} XP. "
                     f"Sa stat la plus travaillée : {top} ({_n(xp[top])} XP).")
        weak = [s for s in C.STATS if xp[s] == 0 and s in hero.assessed]
        if ranks_up:
            story.append("Rangs franchis : " + ", ".join(f"{s} {a} → {b}" for s, a, b in ranks_up) + ".")
        if new_places:
            story.append(f"{_plural(len(new_places), 'nouveau lieu', 'nouveaux lieux')} découvert(s) : {', '.join(new_places[:6])}"
                         + ("…" if len(new_places) > 6 else "") + ".")
        if defis_won:
            story.append(f"Défi(s) relevé(s) : {', '.join(defis_won)}.")
        if records:
            story.append(f"{_plural(len(records), 'record personnel', 'records personnels')} battu(s).")
        if moods:
            avg = sum(moods) / len(moods)
            story.append("Humeur " + ("au beau fixe" if avg >= 4 else "plutôt bonne" if avg >= 3 else "en dents de scie") +
                         f" ({_n(avg, 1)}/5 en moyenne).")
        if weak:
            story.append(f"À relancer {'l’an prochain' if kind == 'year' else 'le mois prochain'} : {', '.join(weak)}.")
    return {"kind": kind, "title": title, "start": start.isoformat(), "end": end.isoformat(), "story": story,
            "xp": xp, "total": total, "active_days": active_days, "days": span, "ranks_up": [list(r) for r in ranks_up],
            "figures": [{"stat": s, "text": t} for s, t in figures], "records": records, "defis": defis_won,
            "books": books, "places": new_places, "notes": len(notes), "gratitude": gratitude[:5],
            "mood": round(sum(moods) / len(moods), 1) if moods else None,
            "monthly": _monthly(store, hero_id, start, end) if kind == "year" else None}


def _monthly(store, hero_id: int, start: date, end: date) -> list[dict]:
    """XP gagnée chaque mois de l'année (pour le graphique du bilan annuel)."""
    out = []
    prev = store.hero(hero_id, until=start - timedelta(days=1))
    m = start
    while m <= end:
        nxt = date(m.year + (m.month == 12), m.month % 12 + 1, 1)
        h = store.hero(hero_id, until=min(nxt - timedelta(days=1), end))
        out.append({"month": MOIS_COURTS[m.month - 1],
                    "xp": round(sum(h.stat_xp.values()) - sum(prev.stat_xp.values()))})
        prev, m = h, nxt
    return out
