"""Stockage local SQLite.

La base garde le JOURNAL BRUT (activités saisies, évaluations, jours de repos, quêtes),
jamais d'XP calculée. L'état du héros est recalculé en relisant le journal : un réglage
changé dans config.py s'applique donc à tout l'historique, et rien ne peut se désynchroniser.

Tout reste sur le PC du joueur (principe « local d'abord »).
"""
import copy
import json
import sqlite3
from datetime import date, datetime, time
from pathlib import Path

from . import config as C
from . import quests as Q
from . import trials as T
from .engine import Hero, XPResult, assess, assess_cooper, assess_placement, log, stat_of, validate

SCHEMA = """
CREATE TABLE IF NOT EXISTS hero (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    bodyweight  REAL NOT NULL,
    hero_class  TEXT,
    created     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (            -- journal brut, relu dans l'ordre
    id       INTEGER PRIMARY KEY,
    hero_id  INTEGER NOT NULL REFERENCES hero(id),
    day      TEXT NOT NULL,
    type     TEXT NOT NULL,                     -- activity | assess | cooper | rest
    payload  TEXT NOT NULL,                     -- JSON
    created  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_hero_day ON events(hero_id, day, id);
CREATE TABLE IF NOT EXISTS quests (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,   -- jamais réutilisé
    hero_id     INTEGER NOT NULL REFERENCES hero(id),
    day         TEXT NOT NULL,
    stat        TEXT NOT NULL,
    kind        TEXT NOT NULL,
    title       TEXT NOT NULL,
    target      TEXT NOT NULL,                  -- JSON
    status      TEXT NOT NULL DEFAULT 'à faire',   -- à faire | faite | changée
    reason      TEXT,
    replaced_by INTEGER REFERENCES quests(id),
    completed_by INTEGER                        -- saisie (events.id) qui a validé la quête
);
CREATE INDEX IF NOT EXISTS quests_hero_day ON quests(hero_id, day);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS quiz_reports (       -- questions de la banque signalées comme fausses
    question_id TEXT PRIMARY KEY,
    comment     TEXT,
    created     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS proofs (             -- preuves vérifiées par l'application (traces GPX…)
    token    TEXT PRIMARY KEY,
    hero_id  INTEGER NOT NULL REFERENCES hero(id),
    kind     TEXT NOT NULL,                      -- gpx
    summary  TEXT NOT NULL,                      -- JSON (le fichier n'est jamais conservé)
    created  TEXT NOT NULL,
    used_by  INTEGER                             -- saisie (events.id) qui l'utilise
);
"""


def _json_default(o):
    if isinstance(o, time):
        return o.strftime("%H:%M")
    raise TypeError(f"Valeur non enregistrable : {o!r}")


def _enc(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, default=_json_default)


def _dec(payload: str) -> dict:
    data = json.loads(payload)
    if isinstance(data.get("bedtime"), str):
        h, m = data["bedtime"].split(":")
        data["bedtime"] = time(int(h), int(m))
    return data


class Store:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.executescript(SCHEMA)
        # Mise à niveau d'une base créée par une version précédente.
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(quests)")}
        if "completed_by" not in cols:
            self.db.execute("ALTER TABLE quests ADD COLUMN completed_by INTEGER")
        ecols = {r["name"] for r in self.db.execute("PRAGMA table_info(events)")}
        if "seal" not in ecols:                     # journal scellé : ancienne base, on scelle tout
            self.db.execute("ALTER TABLE events ADD COLUMN seal TEXT")
            self.db.commit()
            self._reseal_from(0)
        self.db.commit()

    def close(self) -> None:
        self.db.close()

    # ------------------------------------------------------------ héros et journal
    def create_hero(self, name: str, bodyweight: float, hero_class: str | None = None) -> int:
        cur = self.db.execute("INSERT INTO hero(name, bodyweight, hero_class, created) VALUES (?,?,?,?)",
                              (name, bodyweight, hero_class, datetime.now().isoformat(timespec="seconds")))
        self.db.commit()
        return cur.lastrowid

    def _event(self, hero_id: int, day: date, type_: str, payload: dict) -> int:
        cur = self.db.execute("INSERT INTO events(hero_id, day, type, payload, created) VALUES (?,?,?,?,?)",
                              (hero_id, day.isoformat(), type_, _enc(payload), datetime.now().isoformat(timespec="seconds")))
        self._reseal_from(cur.lastrowid)
        self.db.commit()
        return cur.lastrowid

    # ------------------------------------------------------------ journal scellé (détection des modifications)
    # Chaque saisie porte un sceau qui dépend de son contenu et du sceau précédent (chaîne). Une
    # modification faite en dehors de l'application (éditeur de base de données) casse la chaîne.
    # La clé reste sur le PC : cela DÉTECTE une retouche, sans pouvoir l'empêcher totalement.
    def _seal_key(self) -> bytes:
        key = self.get_meta("seal_key")
        if not key:
            import secrets
            key = secrets.token_hex(32)
            self.set_meta("seal_key", key)
        return bytes.fromhex(key)

    def _seal_of(self, key: bytes, prev: str, row) -> str:
        import hashlib
        import hmac
        msg = f"{prev}|{row['id']}|{row['hero_id']}|{row['day']}|{row['type']}|{row['payload']}".encode()
        return hmac.new(key, msg, hashlib.sha256).hexdigest()[:32]

    def _reseal_from(self, event_id: int) -> None:
        """Recalcule les sceaux à partir d'une saisie (après une correction faite PAR l'application)."""
        key = self._seal_key()
        prev_row = self.db.execute("SELECT seal FROM events WHERE id<? ORDER BY id DESC LIMIT 1", (event_id,)).fetchone()
        prev = (prev_row["seal"] or "") if prev_row else ""
        for row in self.db.execute("SELECT id, hero_id, day, type, payload FROM events WHERE id>=? ORDER BY id",
                                   (event_id,)).fetchall():
            prev = self._seal_of(key, prev, row)
            self.db.execute("UPDATE events SET seal=? WHERE id=?", (prev, row["id"]))
        self.db.commit()

    def integrity(self) -> dict:
        """Vérifie la chaîne des sceaux. Une retouche détectée reste signalée pour toujours (même si
        une correction faite ensuite dans l'application recalcule les sceaux)."""
        key = self._seal_key()
        prev, n, broken = "", 0, None
        for row in self.db.execute("SELECT id, hero_id, day, type, payload, seal FROM events ORDER BY id"):
            expected = self._seal_of(key, prev, row)
            if row["seal"] != expected:
                broken = row["day"]
                break
            prev, n = expected, n + 1
        if broken and not self.get_meta("tampered"):
            self.set_meta("tampered", json.dumps({"day": broken, "seen": date.today().isoformat()}))
        flag = self.get_meta("tampered")
        first = json.loads(flag)["day"] if flag else None
        return {"ok": flag is None, "broken": first, "checked": n}

    def record(self, hero_id: int, day: date, kind: str, proof: str | None = None, **data) -> XPResult:
        """Enregistre une activité, renvoie l'XP gagnée (avec explications) et coche les quêtes remplies."""
        hero = self.hero(hero_id, until=day)
        before = copy.deepcopy(hero)
        result = log(hero, day, kind, proof=proof, **data)
        event_id = self._event(hero_id, day, "activity", {"kind": kind, "proof": proof, "data": data})
        result.event_id = event_id
        result.before, result.after = before, hero          # pour les célébrations (rang, niveau, titre…)
        for row in self._quests(hero_id, day, status="à faire"):
            if self._counts(result, kind, data) and Q.is_met(self._quest(row), kind, data):   # une saisie rejetée ne valide rien
                self.db.execute("UPDATE quests SET status='faite', completed_by=? WHERE id=?", (event_id, row["id"]))
                result.notes.append(f"Quête accomplie : {row['title']}")
        self.db.commit()
        return result

    @staticmethod
    def _counts(result: XPResult, kind: str, data: dict) -> bool:
        """Une saisie compte pour les quêtes si le moteur l'accepte, ou si c'est une séance de
        lecture d'un livre de la banque en attente de son quiz."""
        return result.raw > 0 or (kind == "reading" and bool(data.get("work_id"))
                                  and any(n.startswith("En attente") for n in result.notes))

    # ------------------------------------------------------------ corrections
    def event(self, hero_id: int, event_id: int) -> dict:
        ev = self.db.execute("SELECT * FROM events WHERE id=? AND hero_id=?", (event_id, hero_id)).fetchone()
        if ev is None:
            raise KeyError("Saisie introuvable")
        return {"id": ev["id"], "day": ev["day"], "type": ev["type"], **json.loads(ev["payload"])}

    def delete_event(self, hero_id: int, event_id: int, allow_class: bool = False, today: date | None = None) -> None:
        """Annule une saisie (activité, évaluation ou jour de repos). Tout est recalculé à la
        relecture du journal ; les quêtes du jour sont revérifiées.
        Un changement de classe ne s'annule pas (sinon la limite d'un par saison se contourne),
        sauf en mode test (`allow_class`)."""
        ev = self.event(hero_id, event_id)
        if ev["type"] == "class" and not allow_class:
            raise ValueError("Un changement de classe ne s'annule pas : tu pourras en changer à la saison suivante")
        if ev["type"] == "bookquiz":
            raise ValueError("Un quiz de livre ne s'annule pas : tu pourras le repasser demain")
        if ev["type"] == "langlevel" and not allow_class:
            raise ValueError("Un test de langue ne s'annule pas : tu pourras le repasser plus tard")
        quiz = ev["type"] == "activity" and ev.get("kind") == "homework" and (ev.get("data") or {}).get("quiz_id")
        if (ev["type"] in ("subject_level", "subject_exam") or quiz) and not allow_class:
            raise ValueError("Un quiz de matière, un test de placement ou un examen ne s'annule pas")
        if ev["type"] in ("assess", "cooper", "placement") and not allow_class and today is not None \
                and ev["day"] != today.isoformat():
            raise ValueError("Une évaluation de départ ne s'annule que le jour même (pour corriger une erreur de saisie)")
        self.integrity()                       # une retouche antérieure est notée avant de recalculer
        self.db.execute("DELETE FROM events WHERE id=? AND hero_id=?", (event_id, hero_id))
        self._reseal_from(event_id)
        self._recheck_quests(hero_id, date.fromisoformat(ev["day"]))
        if ev["type"] == "convalescence" and today is not None:
            # Annuler une fin (ou un début) de convalescence regèle (ou dégèle) une stat après coup :
            # les quêtes du jour encore à faire sont recalculées (pas de quête sur une stat gelée).
            self._refresh_quests(hero_id, today)

    def update_event(self, hero_id: int, event_id: int, kind: str, proof: str | None = None, **data) -> XPResult:
        """Corrige une activité déjà saisie. Refusée (et rien n'est changé) si la correction
        n'est pas une saisie valable."""
        ev = self.event(hero_id, event_id)
        if ev["type"] != "activity":
            raise ValueError("Seule une activité peut être modifiée ; une évaluation ou un repos s'annule")
        validate(kind, data)                    # message clair, et rien n'est modifié si c'est faux
        old = self.db.execute("SELECT payload FROM events WHERE id=?", (event_id,)).fetchone()["payload"]
        self.db.execute("UPDATE events SET payload=? WHERE id=?",
                        (_enc({"kind": kind, "proof": proof, "data": data}), event_id))
        day = date.fromisoformat(ev["day"])
        captured: dict[int, XPResult] = {}
        try:
            self.hero(hero_id, until=day, capture=captured)
        except (TypeError, KeyError, ValueError):
            self.db.execute("UPDATE events SET payload=? WHERE id=?", (old, event_id))
            self.db.commit()
            raise ValueError("Correction invalide : vérifie les champs")
        self._recheck_quests(hero_id, day)
        result = captured[event_id]
        if any(n.startswith("Saisie invalide, ignorée") for n in result.notes):
            self.db.execute("UPDATE events SET payload=? WHERE id=?", (old, event_id))
            self.db.commit()
            raise ValueError(result.notes[0].replace("Saisie invalide, ignorée : ", "Correction invalide : "))
        self.db.execute("UPDATE events SET payload=? WHERE id=?", (old, event_id))
        self.integrity()                       # vérifie la chaîne d'avant la correction
        self.db.execute("UPDATE events SET payload=? WHERE id=?", (_enc({"kind": kind, "proof": proof, "data": data}), event_id))
        self._reseal_from(event_id)
        result.event_id = event_id
        return result

    def _recheck_quests(self, hero_id: int, day: date) -> None:
        """Recalcule quelles quêtes du jour sont faites, d'après les saisies qui restent."""
        self.db.execute("UPDATE quests SET status='à faire', completed_by=NULL "
                        "WHERE hero_id=? AND day=? AND status='faite'", (hero_id, day.isoformat()))
        events = self.db.execute("SELECT * FROM events WHERE hero_id=? AND day=? AND type='activity' ORDER BY id",
                                 (hero_id, day.isoformat())).fetchall()
        captured: dict = {}
        self.hero(hero_id, until=day, capture=captured)
        for ev in events:
            p = json.loads(ev["payload"])
            got = captured.get(ev["id"])
            if not isinstance(got, XPResult) or not self._counts(got, p["kind"], p["data"]):
                continue                                   # saisie rejetée par le moteur
            for row in self._quests(hero_id, day, status="à faire"):
                if Q.is_met(self._quest(row), p["kind"], p["data"]):
                    self.db.execute("UPDATE quests SET status='faite', completed_by=? WHERE id=?", (ev["id"], row["id"]))
        self.db.commit()

    def journal(self, hero_id: int, day: date) -> list[dict]:
        """Saisies d'une journée, avec l'XP que chacune rapporte (recalculée)."""
        captured: dict[int, object] = {}
        self.hero(hero_id, until=day, capture=captured)
        out = []
        for ev in self.db.execute("SELECT * FROM events WHERE hero_id=? AND day=? AND type NOT IN ('review', 'habit_check', 'card', 'mistakes', 'revision_practice') "
                                  "ORDER BY id", (hero_id, day.isoformat())).fetchall():
            item = {"id": ev["id"], "type": ev["type"], **json.loads(ev["payload"])}
            got = captured.get(ev["id"])
            if isinstance(got, XPResult):
                item.update(stat=got.stat, granted=round(got.granted, 1), notes=got.notes)
            elif isinstance(got, list):
                item.update(notes=got)
            out.append(item)
        return out

    def assess(self, hero_id: int, day: date, results: dict) -> list[str]:
        notes = assess(self.hero(hero_id, until=day), day, results)
        if notes != ["Évaluation de départ déjà faite"]:
            self._event(hero_id, day, "assess", {"results": results})
            self._refresh_quests(hero_id, day)
        return notes

    def placement(self, hero_id: int, day: date, stat: str, score: float, detail: str = "", answers=None) -> list[str]:
        """Évaluation de départ par questionnaire / quiz : une seule fois par stat."""
        hero = self.hero(hero_id, until=day)
        if stat in hero.assessed:
            raise ValueError("Évaluation de départ déjà faite pour cette stat")
        notes = assess_placement(hero, day, stat, score, detail)
        self._event(hero_id, day, "placement", {"stat": stat, "score": round(score, 4), "detail": detail,
                                                "answers": answers})
        self._refresh_quests(hero_id, day)
        return notes

    def cooper(self, hero_id: int, day: date, meters: float) -> list[str]:
        notes = assess_cooper(self.hero(hero_id, until=day), day, meters)
        if notes != ["Évaluation de départ déjà faite"]:
            self._event(hero_id, day, "cooper", {"meters": meters})
            self._refresh_quests(hero_id, day)
        return notes

    def _refresh_quests(self, hero_id: int, day: date) -> None:
        """Après une évaluation, le niveau réel est connu : les quêtes du jour encore à faire
        sont recalculées (celles déjà faites sont gardées)."""
        kept = [r for r in self._quests(hero_id, day) if r["status"] == "faite"]
        if not self._quests(hero_id, day):
            return
        # On garde l'historique des quêtes changées ; seules les quêtes encore à faire sont recalculées.
        # Une quête changée peut pointer vers une quête à faire supprimée ici : on détache d'abord ce lien.
        self.db.execute("UPDATE quests SET replaced_by=NULL WHERE replaced_by IN "
                        "(SELECT id FROM quests WHERE hero_id=? AND day=? AND status='à faire')", (hero_id, day.isoformat()))
        self.db.execute("DELETE FROM quests WHERE hero_id=? AND day=? AND status='à faire'", (hero_id, day.isoformat()))
        taken = {r["stat"] for r in kept}
        hero = self.hero(hero_id, until=day)
        fresh = [q for q in Q.generate(hero, day, seed=f"{hero_id}|réévalué") if q.stat not in taken]
        for q in fresh[:max(0, C.DAILY_QUESTS - len(kept))]:
            self._add_quest(hero_id, day, q)
        self.db.commit()

    # ------------------------------------------------------------ quiz de livres
    def book_quiz(self, hero_id: int, day: date, work: dict, good: int, total: int, question_ids: list[str]) -> int:
        passed = good >= C.BOOK_QUIZ_PASS
        return self._event(hero_id, day, "bookquiz", {"work_id": work["id"], "title": work["title"], "good": good,
                                                      "total": total, "score": round(good / total, 3), "passed": passed,
                                                      "questions": question_ids})

    def last_book_attempt(self, hero_id: int, work_id: str) -> tuple[date, bool] | None:
        """Dernière tentative au quiz d'un livre : (jour, réussie)."""
        last = None
        for ev in self.db.execute("SELECT day, payload FROM events WHERE hero_id=? AND type='bookquiz' ORDER BY day, id",
                                  (hero_id,)):
            p = json.loads(ev["payload"])
            if p.get("work_id") == work_id:
                last = (date.fromisoformat(ev["day"]), bool(p.get("passed")))
        return last

    def attempted_today(self, hero_id: int, work_id: str, day: date) -> bool:
        for ev in self.db.execute("SELECT payload FROM events WHERE hero_id=? AND day=? AND type='bookquiz'",
                                  (hero_id, day.isoformat())):
            if json.loads(ev["payload"]).get("work_id") == work_id:
                return True
        return False

    def report_question(self, question_id: str, comment: str) -> None:
        self.db.execute("INSERT OR REPLACE INTO quiz_reports(question_id, comment, created) VALUES (?,?,?)",
                        (question_id, comment[:300], datetime.now().isoformat(timespec="seconds")))
        self.db.commit()

    def reported_questions(self) -> set[str]:
        return {r["question_id"] for r in self.db.execute("SELECT question_id FROM quiz_reports")}

    # ------------------------------------------------------------ preuves
    def add_proof(self, hero_id: int, kind: str, summary: dict) -> str:
        import secrets
        token = secrets.token_urlsafe(12)
        self.db.execute("INSERT INTO proofs(token, hero_id, kind, summary, created) VALUES (?,?,?,?,?)",
                        (token, hero_id, kind, json.dumps(summary), datetime.now().isoformat(timespec="seconds")))
        self.db.commit()
        return token

    def proof(self, hero_id: int, token: str) -> dict | None:
        row = self.db.execute("SELECT * FROM proofs WHERE token=? AND hero_id=?", (token, hero_id)).fetchone()
        return None if row is None else {"kind": row["kind"], "summary": json.loads(row["summary"]), "used_by": row["used_by"]}

    def use_proof(self, token: str, event_id: int) -> None:
        self.db.execute("UPDATE proofs SET used_by=? WHERE token=?", (event_id, token))
        self.db.commit()

    def proof_of_event(self, hero_id: int, event_id: int) -> dict | None:
        row = self.db.execute("SELECT * FROM proofs WHERE hero_id=? AND used_by=?", (hero_id, event_id)).fetchone()
        return None if row is None else {"token": row["token"], "summary": json.loads(row["summary"])}

    @staticmethod
    def season(day: date) -> tuple[int, int]:
        """Saison de 3 mois : (année, trimestre)."""
        return day.year, (day.month - 1) // 3 + 1

    def change_class(self, hero_id: int, day: date, hero_class: str, test_mode: bool = False) -> str:
        """Change de classe : une fois par saison, l'XP est gardée (seul le rang global change).
        `test_mode` : sans limite, pour la phase de test."""
        if hero_class not in C.CLASSES:
            raise ValueError(f"Classe inconnue : {hero_class}")
        current = self.hero(hero_id, until=day).hero_class
        if hero_class == current:
            raise ValueError("C'est déjà ta classe")
        for ev in ([] if test_mode else
                   self.db.execute("SELECT day FROM events WHERE hero_id=? AND type='class'", (hero_id,))):
            if self.season(date.fromisoformat(ev["day"])) == self.season(day):
                y, q = self.season(day)
                raise ValueError(f"Classe déjà changée cette saison (saison {q} de {y}) : prochain changement à la saison suivante")
        self._event(hero_id, day, "class", {"class": hero_class})
        return f"Tu es maintenant {hero_class}. Ton XP est gardée ; seul ton rang global est recalculé."

    # ------------------------------------------------------------ profil et convalescence
    def update_profile(self, hero_id: int, day: date, birth_year=None, sex=None, weight=None,
                       adapted=None, name=None, conditions=None) -> list[str]:
        """Met à jour le profil (âge, sexe, poids, profil aménagé). Les champs absents (None) sont
        gardés ; sex="" efface le sexe. Le poids s'applique à partir de ce jour (squat × poids)."""
        hero = self.hero(hero_id, until=day)
        cur = {"birth_year": hero.birth_year, "sex": hero.sex, "weight": hero.bodyweight, "adapted": hero.adapted,
               "conditions": list(hero.conditions)}
        new = dict(cur)
        if birth_year is not None:
            if isinstance(birth_year, bool) or not isinstance(birth_year, int):
                raise ValueError("Année de naissance : nombre entier attendu")
            age = day.year - birth_year
            if not C.MIN_AGE <= age <= C.MAX_AGE:
                raise ValueError(f"Âge : ASCEND est ouvert de {C.MIN_AGE} à {C.MAX_AGE} ans")
            new["birth_year"] = birth_year
        if sex is not None:
            if sex not in ("",) + C.SEXES:
                raise ValueError("Sexe : femme, homme, ou non précisé")
            new["sex"] = sex or None
        if weight is not None:
            if isinstance(weight, bool) or not isinstance(weight, (int, float)) or not 25 <= weight <= 300:
                raise ValueError("Poids : entre 25 et 300 kg")
            new["weight"] = round(float(weight), 1)
        if adapted is not None:
            if not isinstance(adapted, bool):
                raise ValueError("Profil aménagé : oui ou non")
            new["adapted"] = adapted
        if conditions is not None:
            from . import health as HL
            if not isinstance(conditions, list) or len(conditions) > 12 or any(c not in HL.CONDITIONS for c in conditions):
                raise ValueError("Situation de santé inconnue")
            new["conditions"] = sorted(set(conditions), key=list(HL.CONDITIONS).index)
            new["adapted"] = bool(new["conditions"])
        notes = []
        if name is not None:
            name = str(name).strip()[:40]
            if not name:
                raise ValueError("Le nom ne peut pas être vide")
            if name != hero.name:
                self.db.execute("UPDATE hero SET name=? WHERE id=?", (name, hero_id))
                self.db.commit()
                notes.append(f"Nom changé : {name}")
        if new != cur:
            self._event(hero_id, day, "profile", new)
            notes.append("Profil mis à jour : les cibles des épreuves A et S sont recalculées")
        return notes or ["Rien à changer"]

    def convalescence(self, hero_id: int, day: date, action: str, stats: list, reason: str = "") -> str:
        """Gèle des stats (blessure, maladie) : pas de quête sur elles, pas de mise en sommeil."""
        hero = self.hero(hero_id, until=day)
        if not isinstance(stats, list) or not stats or any(s not in C.STATS for s in stats):
            raise ValueError("Choisis au moins une stat")
        stats = sorted(set(stats), key=C.STATS.index)
        reason = str(reason or "").strip()[:80]
        if action == "start":
            already = [s for s in stats if s in hero.convalescence]
            if already:
                raise ValueError(f"Déjà en convalescence : {', '.join(already)}")
            self._event(hero_id, day, "convalescence", {"action": "start", "stats": stats, "reason": reason})
            self._refresh_quests(hero_id, day)
            return f"Convalescence commencée : {', '.join(stats)}. Ces stats sont gelées, sans quête ni mise en sommeil."
        if action == "end":
            missing = [s for s in stats if s not in hero.convalescence]
            if missing:
                raise ValueError(f"Pas en convalescence : {', '.join(missing)}")
            self._event(hero_id, day, "convalescence", {"action": "end", "stats": stats})
            return f"Bon retour ! Convalescence terminée : {', '.join(stats)}."
        raise ValueError("Action inconnue : start ou end")

    def neutral_rest_days(self, hero_id: int) -> set[str]:
        """Jours de repos neutres : au plus REST_NEUTRAL_PER_WEEK sur 7 jours glissants,
        dans l'ordre chronologique. Les repos en trop comptent comme des jours normaux."""
        days = sorted(date.fromisoformat(r["day"]) for r in self.db.execute(
            "SELECT DISTINCT day FROM events WHERE hero_id=? AND type='rest'", (hero_id,)))
        neutral: list[date] = []
        for d in days:
            if sum(1 for n in neutral if 0 <= (d - n).days < 7) < C.REST_NEUTRAL_PER_WEEK:
                neutral.append(d)
        return {d.isoformat() for d in neutral}

    def rest(self, hero_id: int, day: date) -> int:
        """Jour de repos déclaré : neutre pour la Discipline, ses quêtes ne comptent pas.
        Une seule déclaration par jour : une deuxième renvoie la première."""
        row = self.db.execute("SELECT id FROM events WHERE hero_id=? AND day=? AND type='rest'",
                              (hero_id, day.isoformat())).fetchone()
        return row["id"] if row else self._event(hero_id, day, "rest", {})

    def hero(self, hero_id: int, until: date | None = None, capture: dict | None = None) -> Hero:
        """Recalcule le héros en relisant le journal (jusqu'à `until` inclus).
        `capture` reçoit, pour chaque saisie, son résultat (XP et explications)."""
        row = self.db.execute("SELECT * FROM hero WHERE id=?", (hero_id,)).fetchone()
        if row is None:
            raise KeyError(f"Héros {hero_id} introuvable")
        hero = Hero(name=row["name"], bodyweight=row["bodyweight"],
                    hero_class=row["hero_class"] if row["hero_class"] in C.CLASSES else "Équilibré")
        sql = "SELECT * FROM events WHERE hero_id=?" + (" AND day<=?" if until else "") + " ORDER BY day, id"
        args = (hero_id, until.isoformat()) if until else (hero_id,)
        events = self.db.execute(sql, args).fetchall()
        # Livres validés par quiz : connus AVANT la relecture, pour créditer les séances en attente.
        for ev in events:
            if ev["type"] == "bookquiz":
                p = json.loads(ev["payload"])
                if p.get("passed") and p.get("work_id") not in hero.validated_books:
                    hero.validated_books[p["work_id"]] = (date.fromisoformat(ev["day"]), float(p.get("score", 0.67)))
        for ev in events:
            d, p = date.fromisoformat(ev["day"]), _dec(ev["payload"])
            try:
                if ev["type"] == "activity":
                    r = log(hero, d, p["kind"], proof=p.get("proof"), **_dec(json.dumps(p["data"])))
                elif ev["type"] in ("assess", "cooper", "placement"):
                    xp0 = dict(hero.stat_xp)
                    if ev["type"] == "assess":
                        r = assess(hero, d, {f: tuple(v) for f, v in p["results"].items()})
                    elif ev["type"] == "cooper":
                        r = assess_cooper(hero, d, p["meters"])
                    else:
                        r = assess_placement(hero, d, p["stat"], float(p["score"]), p.get("detail", ""))
                    for st, xp in hero.stat_xp.items():
                        if xp > xp0[st]:
                            hero.last_active[st] = max(d, hero.last_active.get(st, d))
            except (TypeError, ValueError, KeyError, AttributeError) as e:
                # Saisie enregistrée par une ancienne version et devenue invalide : ignorée, jamais bloquante.
                msg = f"Saisie invalide, ignorée : {e}"
                r = (XPResult(stat_of(p.get("kind", ""), p.get("data") if isinstance(p.get("data"), dict) else {}),
                              0.0, 0.0, [msg]) if ev["type"] == "activity" else [msg])
                if capture is not None:
                    capture[ev["id"]] = r
                continue
            if ev["type"] == "class":
                hero.hero_class = p["class"] if p.get("class") in C.CLASSES else hero.hero_class
                r = [f"Classe : {p.get('class')}"]
            elif ev["type"] == "rest":
                r = ["Jour de repos déclaré"]
            elif ev["type"] == "profile":
                hero.birth_year = p.get("birth_year") if isinstance(p.get("birth_year"), int) else None
                hero.sex = p.get("sex") if p.get("sex") in C.SEXES else None
                hero.adapted = bool(p.get("adapted"))
                hero.conditions = [c for c in p.get("conditions", []) if isinstance(c, str)]
                if isinstance(p.get("weight"), (int, float)) and 25 <= p["weight"] <= 300:
                    hero.bodyweight = float(p["weight"])
                r = ["Profil mis à jour"]
            elif ev["type"] == "convalescence":
                sts = [s for s in p.get("stats", []) if s in C.STATS]
                if p.get("action") == "start":
                    for st in sts:
                        hero.convalescence.setdefault(st, (d, str(p.get("reason", ""))))
                    r = [f"Convalescence : {', '.join(sts)}" + (f" ({p['reason']})" if p.get("reason") else "")]
                else:
                    for st in sts:
                        if hero.convalescence.pop(st, None):
                            hero.conva_end[st] = d
                    r = [f"Fin de convalescence : {', '.join(sts)}"]
            elif ev["type"] == "bookquiz":
                if p.get("passed"):
                    hero.works.setdefault(str(p.get("title", "")).strip().lower(), d)
                    r = [f"Quiz réussi : « {p.get('title')} » ({p.get('good')}/{p.get('total')})"]
                    r += T.update(hero, d, "bookquiz", {}, None, accepted=True, stat="Intelligence")
                else:
                    r = [f"Quiz non réussi : « {p.get('title')} » ({p.get('good')}/{p.get('total')})"]
            elif ev["type"] == "subject_level":
                if p.get("level") in C.SUBJECT_LEVELS and p.get("chain") in C.SUBJECT_CHAINS:
                    hero.subject_levels[p["chain"]] = p["level"]
                r = [f"Palier {C.LEVEL_LABELS.get(p.get('level'), '?')} en {C.SUBJECT_CHAINS.get(p.get('chain'), '?')}"]
                r += T.update(hero, d, "subject_level", p, "cursus", accepted=True, stat="Intelligence")
            elif ev["type"] not in ("activity", "assess", "cooper", "placement"):
                r = []                     # programme, palier de matière, examen… : sans effet sur le héros
            if capture is not None:
                capture[ev["id"]] = r
        self._discipline(hero, hero_id, until)
        hero.as_of = until or date.today()
        return hero

    # ------------------------------------------------------------ quêtes et Discipline
    def _quests(self, hero_id: int, day: date, status: str | None = None) -> list[sqlite3.Row]:
        sql = "SELECT * FROM quests WHERE hero_id=? AND day=?" + (" AND status=?" if status else "") + " ORDER BY id"
        args = (hero_id, day.isoformat()) + ((status,) if status else ())
        return self.db.execute(sql, args).fetchall()

    @staticmethod
    def _quest(row: sqlite3.Row) -> Q.Quest:
        return Q.Quest(row["stat"], row["kind"], row["title"], json.loads(row["target"]))

    def _add_quest(self, hero_id: int, day: date, q: Q.Quest) -> int:
        cur = self.db.execute("INSERT INTO quests(hero_id, day, stat, kind, title, target) VALUES (?,?,?,?,?,?)",
                              (hero_id, day.isoformat(), q.stat, q.kind, q.title, json.dumps(q.target, ensure_ascii=False)))
        return cur.lastrowid

    def daily_quests(self, hero_id: int, day: date) -> list[sqlite3.Row]:
        """Quêtes du jour : générées à la première ouverture de la journée, puis conservées."""
        if not self._quests(hero_id, day):
            hero = self.hero(hero_id, until=day)
            for q in Q.generate(hero, day, seed=str(hero_id)):
                self._add_quest(hero_id, day, q)
            self.db.commit()
        return [r for r in self._quests(hero_id, day) if r["status"] != "changée"]

    def swap_quest(self, hero_id: int, quest_id: int, reason: str, today: date | None = None) -> str:
        """Change une quête en disant pourquoi ; sans perte de Discipline.
        Seulement le jour même : changer après coup une quête ratée effacerait l'échec."""
        row = self.db.execute("SELECT * FROM quests WHERE id=? AND hero_id=?", (quest_id, hero_id)).fetchone()
        if row is None or row["status"] != "à faire":
            raise ValueError("Seule une quête encore à faire peut être changée")
        day = date.fromisoformat(row["day"])
        if today is not None and day != today:
            raise ValueError("Seules les quêtes du jour peuvent être changées")
        others = frozenset(r["stat"] for r in self._quests(hero_id, day)
                           if r["status"] != "changée" and r["id"] != quest_id)
        new, why = Q.alternative(self.hero(hero_id, until=day), day, self._quest(row), reason,
                                 seed=str(hero_id), exclude=others)
        new_id = self._add_quest(hero_id, day, new)
        self.db.execute("UPDATE quests SET status='changée', reason=?, replaced_by=? WHERE id=?", (reason, new_id, quest_id))
        self.db.commit()
        return why

    def _discipline(self, hero: Hero, hero_id: int, until: date | None) -> None:
        """Discipline = quêtes du jour accomplies. Un jour sans quête générée (application non
        ouverte) est neutre : on ne punit pas de ne pas ouvrir l'application. La journée en
        cours ne compte qu'une fois toutes ses quêtes faites."""
        today = until or date.today()
        rests = self.neutral_rest_days(hero_id)
        rows = self.db.execute(
            "SELECT day, SUM(status!='changée') AS planned, SUM(status='faite') AS done "
            "FROM quests WHERE hero_id=? AND day<=? GROUP BY day", (hero_id, today.isoformat())).fetchall()
        with_quests = set()
        for r in rows:
            d = date.fromisoformat(r["day"])
            with_quests.add(r["day"])
            if d == today and r["done"] < r["planned"] and r["day"] not in rests:
                continue
            hero.discipline.record_day(d, r["planned"], r["done"], rest=r["day"] in rests)
        for day in rests - with_quests:           # repos sans quête générée : compte dans la série
            if day <= today.isoformat():
                hero.discipline.record_day(date.fromisoformat(day), 0, 0, rest=True)

    # ------------------------------------------------------------ sauvegarde
    # ------------------------------------------------------------ réglages
    def get_meta(self, key: str) -> str | None:
        row = self.db.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def set_meta(self, key: str, value: str) -> None:
        self.db.execute("INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)", (key, value))
        self.db.commit()

    def backup_code(self) -> str:
        """Code de récupération des sauvegardes : créé une fois, à noter par le joueur."""
        code = self.get_meta("backup_code")
        if not code:
            from .crypto import new_code
            code = new_code()
            self.set_meta("backup_code", code)
        return code

    def backup(self, folder: str | Path, today: date | None = None, force: bool = False) -> Path | None:
        """Copie quotidienne de la base dans un dossier choisi par le joueur (clé USB, son
        propre cloud…), CHIFFRÉE avec le code de récupération. Une seule par jour (sauf `force`) ;
        les plus anciennes au-delà de BACKUPS_KEPT sont supprimées. Renvoie le chemin créé,
        ou None si la copie du jour existe déjà."""
        from .crypto import encrypt
        today = today or date.today()
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / f"ascend-{today.isoformat()}.ascbak"
        if target.exists() and not force:
            return None
        code = self.backup_code()
        tmp = folder / f".ascend-{today.isoformat()}.tmp"
        dest = sqlite3.connect(tmp)
        with dest:
            self.db.backup(dest)
        dest.close()
        try:
            target.write_bytes(encrypt(tmp.read_bytes(), code))
        finally:
            tmp.unlink(missing_ok=True)
        copies = sorted(list(folder.glob("ascend-????-??-??.ascbak")) + list(folder.glob("ascend-????-??-??.db")),
                        key=lambda p: p.name[7:17])
        for old in copies[:-C.BACKUPS_KEPT]:
            old.unlink()
        self.set_meta("last_backup", today.isoformat())
        return target
