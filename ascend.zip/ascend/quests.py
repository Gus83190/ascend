"""Quête du jour : générée par le Système selon le niveau et l'historique du héros.

Seules ces quêtes comptent pour la Discipline : valider « 5 pompes » ne suffit plus,
la cible monte avec le rang de la stat. Une quête peut être changée sans perte de
Discipline si le joueur dit pourquoi ; le Système propose alors une quête adaptée.
"""
import random
from dataclasses import dataclass
from datetime import date

from . import config as C
from . import catalog as K
from . import health as HL
from . import trials as T
from .engine import Hero, suggest
from .ranks import rank_for


@dataclass
class Quest:
    stat: str
    kind: str        # activité attendue (même nom que dans engine.ACTIVITIES)
    title: str
    target: dict     # critères de réussite


# Type d'effort de chaque famille d'exercices et de chaque stat (profil santé).
FAMILY_DIM = {"poussée": "haut", "tirage": "haut", "gainage": "haut", "jambes": "bas", "souplesse": "souplesse",
              "équilibre": "équilibre", "coordination": "coordination", "explosivité": "bas"}
STAT_DIMS = {"Endurance": ("cardio",), "Expédition": ("outing",), "Intelligence": ("works",), "Mental": ("focus",)}


def health_scale(hero: Hero, stat: str, family: str | None = None) -> float:
    """Volume des quêtes et des programmes selon le profil santé (0 = effort impossible)."""
    ids = T.health_ids(hero)
    if family:
        return HL.factor(ids, FAMILY_DIM.get(family, "haut"))
    dims = STAT_DIMS.get(stat, ())
    return min((HL.factor(ids, d) for d in dims), default=1.0)


def families_for(hero: Hero, stat: str) -> list[str]:
    """Familles possibles avec le profil santé (une famille impossible n'est jamais proposée)."""
    ok = [f for f in K.families_of(stat) if health_scale(hero, stat, f) > 0]
    return ok or K.families_of(stat)


def _lvl(hero: Hero, stat: str) -> int:
    return C.RANKS.index(rank_for(hero.stat_xp[stat]))


def _round5(x: float) -> int:
    return int(5 * round(x / 5))


def _variant_quest(hero: Hero, family: str, scale: float = 1.0) -> Quest:
    """Variante en cours (ou suggérée si la précédente est maîtrisée), une répétition de plus."""
    info = K.FAMILIES[family]
    variants = info["variants"]
    worked = [v for v in variants if hero.best_sets.get((family, v.id), 0) > 0]
    if not worked:
        v, amount = variants[0], max(5, variants[0].mastery // 2)
    else:
        cur = worked[-1]
        nxt = suggest(hero, family)
        if hero.best_sets[(family, cur.id)] >= cur.mastery and nxt is not None:
            v, amount = nxt, max(3, nxt.mastery // 3)
        else:
            v, amount = cur, min(cur.mastery, int(hero.best_sets[(family, cur.id)]) + (5 if info["unit"] == "s" else 1))
    amount = max(1, int(amount * scale * max(0.3, health_scale(hero, info["stat"], family))))
    # 3 séries, et assez de volume pour que le moteur compte l'exercice (sinon la quête serait impossible).
    floor = -(-C.BW_MIN_EQUIV[info["unit"]] // (3 * v.coef))
    amount = max(amount, int(floor))
    unit = "s" if info["unit"] == "s" else "répétitions"
    return Quest(info["stat"], "bodyweight", f"{v.name} : 3 séries de {amount} {unit}",
                 {"family": family, "variant": v.id, "amount": amount, "sets": 3})


def _make(hero: Hero, stat: str, today: date, rnd: random.Random, scale: float = 1.0) -> Quest:
    lvl = _lvl(hero, stat)
    if stat in ("Force", "Agilité"):
        return _variant_quest(hero, rnd.choice(families_for(hero, stat)), scale)
    scale *= max(0.3, health_scale(hero, stat))
    if stat == "Endurance":
        m = max(15, _round5((20 + 6 * lvl) * scale))
        return Quest(stat, "endurance", f"{m} min d'endurance (course, marche rapide, vélo ou natation)",
                     {"minutes": m})
    if stat == "Intelligence":
        m = max(10, _round5((20 + 5 * lvl) * scale))
        return Quest(stat, "reading", f"Lire {m} min d'un livre de la banque de quiz", {"minutes": m, "quiz": 0.6})
    if stat == "Mental":
        if rnd.random() < 0.6:
            m = max(15, _round5((25 + 10 * lvl) * scale))
            return Quest(stat, "focus", f"Session de concentration de {m} min, 2 interruptions au plus",
                         {"minutes": m, "interruptions": 2})
        m = max(5, _round5((5 + 3 * lvl) * scale))
        return Quest(stat, "meditation", f"Méditer {m} min", {"minutes": m})
    if stat == "Vitalité":
        return Quest(stat, "sleep", "Dormir entre 7 et 9 h (siestes comprises)", {"min_hours": 7, "max_hours": 9})
    if stat == "Expédition":
        km = max(3, round((5 + 2 * lvl) * scale))
        return Quest(stat, "expedition", f"Sortie de {km} km ou plus (randonnée ou exploration urbaine)",
                     {"distance_km": km})
    raise ValueError(stat)


def generate(hero: Hero, today: date, seed: str = "") -> list[Quest]:
    """Les quêtes du jour : les stats les moins avancées ont plus de chances d'être choisies.
    L'Expédition n'est proposée que le week-end."""
    rnd = random.Random(f"{seed}|{today.isoformat()}")
    stats = [s for s in C.STATS if (s != "Expédition" or today.weekday() >= 5) and s not in hero.convalescence]
    if not stats:
        return []                                  # tout est en convalescence : journée neutre
    top = max(hero.stat_xp.values()) or 1.0
    weights = [1.0 + 2.0 * (1 - hero.stat_xp[s] / top) for s in stats]
    chosen: list[str] = []
    while len(chosen) < min(C.DAILY_QUESTS, len(stats)):
        s = rnd.choices(stats, weights)[0]
        if s not in chosen:
            chosen.append(s)
    return [_make(hero, s, today, rnd) for s in chosen]


def is_met(q: Quest, kind: str, data: dict) -> bool:
    """La saisie `kind` / `data` remplit-elle la quête ?"""
    t = q.target
    if q.kind == "bodyweight":
        if kind not in ("bodyweight", "skill") or data.get("family") != t["family"]:
            return False
        harder = K.index_of(t["family"], data["variant"]) > K.index_of(t["family"], t["variant"])
        same = data["variant"] == t["variant"]
        sets = data.get("sets") or [0]
        enough_sets = len([x for x in sets if x > 0]) >= t.get("sets", 1)
        return enough_sets and ((same and max(sets) >= t["amount"]) or (harder and max(sets) >= 3))
    if q.kind != kind:
        return False
    if kind == "endurance":
        return data.get("minutes", 0) >= t["minutes"]
    if kind == "reading":   # séance d'un livre de la banque (en attente du quiz) ou quiz réussi
        return data.get("minutes", 0) >= t["minutes"] and (bool(data.get("work_id")) or (data.get("quiz") or 0) >= t["quiz"])
    if kind == "focus":
        return data.get("minutes", 0) >= t["minutes"] and data.get("interruptions", 0) <= t["interruptions"]
    if kind == "meditation":
        return data.get("minutes", 0) >= t["minutes"]
    if kind == "sleep":
        total = data.get("hours", 0) + data.get("nap_minutes", 0) / 60
        return t["min_hours"] <= total <= t["max_hours"]
    if kind == "expedition":
        return data.get("distance_km", 0) >= t["distance_km"]
    return False


# Raisons acceptées pour changer de quête, et ce que le Système propose à la place.
SWAP_REASONS = {
    "météo": "Quête d'intérieur à la place",
    "malade": "Quête douce, sans effort physique",
    "blessure": "Quête sur une autre stat, sans solliciter la zone blessée",
    "matériel": "Variante sans matériel",
    "temps": "Version courte de la même quête",
}
OUTDOOR = {"Endurance", "Expédition"}
PHYSICAL = {"Force", "Agilité", "Endurance", "Expédition"}


def valid_reasons(q: Quest) -> list[str]:
    """Raisons qui ont du sens pour cette quête (la météo ne gêne pas le sommeil…)."""
    reasons = []
    if q.stat in OUTDOOR:
        reasons.append("météo")
    if q.stat in PHYSICAL or q.kind == "focus":
        reasons += ["malade", "blessure"] if q.stat in PHYSICAL else ["malade"]
    if q.kind == "bodyweight":
        reasons.append("matériel")
    if q.kind != "sleep":
        reasons.append("temps")
    else:
        reasons.append("malade")
    return reasons


def alternative(hero: Hero, today: date, q: Quest, reason: str, seed: str = "",
                exclude: frozenset[str] = frozenset()) -> tuple[Quest, str]:
    """Quête de remplacement adaptée à la raison donnée, et l'explication du Système.
    `exclude` : stats déjà présentes dans les autres quêtes du jour (pas de doublon)."""
    if reason not in SWAP_REASONS:
        raise ValueError(f"Raison inconnue : {reason}. Raisons possibles : {', '.join(SWAP_REASONS)}")
    if reason not in valid_reasons(q):
        raise ValueError(f"« {reason} » ne s'applique pas à cette quête. Raisons possibles : {', '.join(valid_reasons(q))}")
    rnd = random.Random(f"{seed}|{today.isoformat()}|swap|{q.title}")
    if reason == "temps":
        new = _make(hero, q.stat, today, rnd, scale=0.5)
    elif reason == "matériel" and q.kind == "bodyweight":
        fam = q.target["family"]
        # tirage (barre) et coordination (corde à sauter) demandent du matériel : autre famille
        no_gear = [f for f in families_for(hero, q.stat) if f not in (fam, "tirage", "coordination")] \
            if fam in ("tirage", "coordination") else [fam]
        new = _variant_quest(hero, rnd.choice(no_gear or [fam]))
        if new.target["family"] == fam:   # même famille : on redescend d'une variante
            idx = max(0, K.index_of(fam, q.target["variant"]) - 1)
            v = K.FAMILIES[fam]["variants"][idx]
            new = Quest(q.stat, "bodyweight", f"{v.name} : 3 séries de {q.target['amount']}",
                        {"family": fam, "variant": v.id, "amount": q.target["amount"], "sets": 3})
    else:
        if reason == "météo":
            pool = [s for s in C.STATS if s not in OUTDOOR and s != q.stat]
        else:   # malade, blessure
            # blessure : une stat qui ne sollicite pas le corps (on ne connaît pas la zone blessée)
            pool = [s for s in ("Intelligence", "Mental") if s != q.stat] if reason == "malade" \
                else [s for s in ("Vitalité", "Intelligence", "Mental") if s != q.stat]
        allowed = [s for s in C.STATS if s not in hero.convalescence and (s != "Expédition" or today.weekday() >= 5)]
        if not allowed:
            raise ValueError("Toutes tes stats sont en convalescence : pas de quête de remplacement")
        pool = [s for s in pool if s in allowed] or [s for s in allowed if s not in OUTDOOR | {q.stat}] or allowed
        pool = [s for s in pool if s not in exclude] or pool
        stat = rnd.choice(pool)
        new = _make(hero, stat, today, rnd, scale=0.5 if reason == "malade" else 1.0)
    return new, f"{SWAP_REASONS[reason]} : {new.title}"
