"""Cursus de l'Intelligence : matières choisies, placement par matière, examens de passage.

- L'utilisateur choisit une filière (qui coche des matières) puis ajuste ; les matières annexes
  (informatique…) s'ajoutent à la demande.
- Chaque matière choisie a un TEST DE PLACEMENT (une seule fois) : quelques questions de chaque
  palier, du collège au master. Le palier de départ est le premier palier non maîtrisé.
- Au quotidien, on joue les quiz de son palier (XP d'Intelligence).
- Pour monter, il faut réussir l'EXAMEN DE PASSAGE (30 questions, 24 bonnes) ; il s'ouvre quand
  les derniers quiz du palier sont bons, et se repasse 7 jours après un échec.
- L'évaluation de départ de l'Intelligence est faite quand toutes les matières choisies sont placées.
Rien n'est stocké à part du journal : tout se relit depuis les événements.
"""
import json
import random
from datetime import date, timedelta

from . import bookquiz as BQ
from . import config as C

LEVELS = list(C.SUBJECT_LEVELS)


def chain_quizzes(chain: str) -> list[dict]:
    """Quiz d'une matière, du palier le plus bas au plus haut."""
    return sorted((w for w in BQ.subjects().values() if w["subject"] == chain), key=lambda w: LEVELS.index(w["type"]))


def chains() -> list[str]:
    return [c for c in C.SUBJECT_CHAINS if chain_quizzes(c)]


# ------------------------------------------------------------------ matières choisies
def get_choice(store, hero_id: int) -> dict:
    raw = store.get_meta(f"cursus:{hero_id}")
    try:
        got = json.loads(raw) if raw else {}
    except ValueError:
        got = {}
    subs = [s for s in got.get("subjects", []) if s in C.SUBJECT_CHAINS]
    return {"filiere": got.get("filiere") if got.get("filiere") in C.FILIERES else None, "subjects": subs}


def set_choice(store, hero_id: int, filiere, subjects) -> str:
    if filiere is not None and filiere not in C.FILIERES:
        raise ValueError("Filière inconnue")
    if not isinstance(subjects, list) or any(s not in C.SUBJECT_CHAINS or not chain_quizzes(s) for s in subjects):
        raise ValueError("Matière inconnue")
    subs = [c for c in C.SUBJECT_CHAINS if c in set(subjects)]
    if not subs:
        raise ValueError("Choisis au moins une matière")
    store.set_meta(f"cursus:{hero_id}", json.dumps({"filiere": filiere, "subjects": subs}, ensure_ascii=False))
    names = ", ".join(C.SUBJECT_CHAINS[s] for s in subs)
    return f"Tes matières : {names}"


# ------------------------------------------------------------------ état d'une matière
def _rows(store, hero_id: int):
    levels, exams, quizzes = {}, {}, {}
    for ev in store.db.execute("SELECT day, type, payload FROM events WHERE hero_id=? AND type IN "
                               "('subject_level', 'subject_exam', 'activity') ORDER BY day, id", (hero_id,)):
        p = json.loads(ev["payload"])
        d = date.fromisoformat(ev["day"])
        if ev["type"] == "subject_level":
            levels.setdefault(p["chain"], []).append((d, p))
        elif ev["type"] == "subject_exam":
            exams.setdefault(p["chain"], []).append((d, p))
        elif p.get("kind") == "homework" and (p.get("data") or {}).get("quiz_id") and not p["data"].get("exam"):
            quizzes.setdefault(p["data"]["quiz_id"], []).append((d, float(p["data"].get("ai_score", 0))))
    return levels, exams, quizzes


def status(store, hero_id: int, today: date) -> dict:
    choice = get_choice(store, hero_id)
    levels, exams, quizzes = _rows(store, hero_id)
    out = []
    for chain in chains():
        qz = chain_quizzes(chain)
        hist = levels.get(chain, [])
        cur_level = hist[-1][1]["level"] if hist else None
        idx = next((i for i, w in enumerate(qz) if w["type"] == cur_level), None) if cur_level else None
        placed = any(p.get("source") == "placement" for _, p in hist)
        item = {"chain": chain, "subject": C.SUBJECT_CHAINS[chain], "annex": chain in C.ANNEX_SUBJECTS,
                "chosen": chain in choice["subjects"], "placed": placed, "started": idx is not None,
                "placement": next((p for _, p in hist if p.get("source") == "placement"), None),
                "levels": [{"id": w["id"], "level": w["type"], "label": C.LEVEL_LABELS[w["type"]],
                            "questions": len(w["questions"]), "difficulty": C.SUBJECT_LEVELS[w["type"]],
                            "state": ("courant" if i == idx else "dépassé" if idx is not None and i < idx else "à venir")}
                           for i, w in enumerate(qz)],
                "current": None, "exam": None}
        if idx is not None:
            w = qz[idx]
            since = hist[-1][0]
            recent = [s for d, s in quizzes.get(w["id"], []) if d >= since][-C.EXAM_RECENT:]
            fails = [d for d, p in exams.get(chain, []) if p["level"] == w["type"] and not p.get("passed")]
            retry = (max(fails) + timedelta(days=C.EXAM_RETRY_DAYS)) if fails else None
            top = idx == len(qz) - 1
            avg = sum(recent) / len(recent) if recent else 0.0
            pool = len(w["questions"])
            if top:
                why, ok = "Tu es au palier le plus haut de cette matière", False
            elif pool < C.EXAM_QUESTIONS:
                why, ok = f"Examen bientôt disponible : la banque de ce palier n'a encore que {pool} questions", False
            elif len(recent) < C.EXAM_RECENT:
                why, ok = f"Fais encore {C.EXAM_RECENT - len(recent)} quiz de ce palier pour ouvrir l'examen", False
            elif avg < C.EXAM_AVERAGE:
                why, ok = f"Moyenne de tes {C.EXAM_RECENT} derniers quiz : {avg:.0%} (il faut {C.EXAM_AVERAGE:.0%})", False
            elif retry and today < retry:
                why, ok = f"Examen raté : tu pourras le repasser le {retry.strftime('%d/%m/%Y')}", False
            else:
                why, ok = "Examen de passage disponible", True
            item["current"] = {"id": w["id"], "level": w["type"], "label": C.LEVEL_LABELS[w["type"]], "index": idx,
                               "recent": [round(s, 2) for s in recent], "average": round(avg, 3)}
            item["exam"] = {"available": ok, "reason": why, "questions": C.EXAM_QUESTIONS, "pass": C.EXAM_PASS,
                            "next": None if top else C.LEVEL_LABELS[qz[idx + 1]["type"]]}
        out.append(item)
    from . import trials as T
    reached = [c["current"]["level"] for c in out if c["current"]]
    best = max(reached, key=LEVELS.index) if reached else None
    cap = T.INTEL_TIER_CAP[best] if best else "D"
    nxt = {"D": "C", "C": "B", "B": "A", "A": "S"}.get(cap)
    rank_cap = {"best": C.LEVEL_LABELS[best] if best else None, "cap": cap,
                "next": ({"rank": nxt, "tier": C.LEVEL_LABELS[T.TIER_FOR_RANK[nxt]]} if nxt else None)}
    return {"filiere": choice["filiere"], "subjects": choice["subjects"], "filieres": C.FILIERES, "chains": out,
            "rank_cap": rank_cap,
            "annex": sorted(C.ANNEX_SUBJECTS), "rules": {"placement_per_level": C.PLACEMENT_PER_LEVEL,
                                                         "exam_questions": C.EXAM_QUESTIONS, "exam_pass": C.EXAM_PASS,
                                                         "exam_recent": C.EXAM_RECENT, "exam_average": C.EXAM_AVERAGE,
                                                         "retry_days": C.EXAM_RETRY_DAYS}}


def chain_state(store, hero_id: int, today: date, chain: str) -> dict:
    st = next((c for c in status(store, hero_id, today)["chains"] if c["chain"] == chain), None)
    if st is None:
        raise ValueError("Matière inconnue")
    return st


# ------------------------------------------------------------------ placement et examen
def _shuffle(q: dict, rnd: random.Random, level: str) -> dict:
    order = list(range(4))
    rnd.shuffle(order)
    return {"id": q["id"], "q": q["q"], "choices": [q["choices"][i] for i in order], "answer": order.index(q["answer"]),
            "level": level}


def draw_placement(chain: str, excluded: set[str], seed=None) -> list[dict]:
    rnd = random.Random(seed)
    out = []
    for w in chain_quizzes(chain):
        pool = [q for q in w["questions"] if q["id"] not in excluded]
        for q in rnd.sample(pool, min(C.PLACEMENT_PER_LEVEL, len(pool))):
            out.append(_shuffle(q, rnd, w["type"]))
    return out                      # du plus facile au plus difficile


def placement_result(chain: str, per_level: dict[str, tuple[int, int]]) -> str:
    """Palier de départ : le premier palier non maîtrisé (ou le plus haut si tout est maîtrisé)."""
    qz = chain_quizzes(chain)
    mastered = -1
    for i, w in enumerate(qz):
        good, total = per_level.get(w["type"], (0, 0))
        need = min(C.PLACEMENT_LEVEL_OK, total) if total else 1
        below_ok = all(per_level.get(qz[j]["type"], (0, 0))[0] >= min(C.PLACEMENT_BELOW_OK, per_level.get(qz[j]["type"], (0, 0))[1])
                       for j in range(i))
        if total and good >= need and below_ok:
            mastered = i
        else:
            break
    return qz[min(mastered + 1, len(qz) - 1)]["type"]


def draw_exam(quiz_id: str, excluded: set[str], seed=None) -> list[dict]:
    w = BQ.subjects()[quiz_id]
    pool = [q for q in w["questions"] if q["id"] not in excluded]
    if len(pool) < C.EXAM_QUESTIONS:
        raise ValueError("Pas assez de questions dans ce palier pour un examen")
    rnd = random.Random(seed)
    return [_shuffle(q, rnd, w["type"]) for q in rnd.sample(pool, C.EXAM_QUESTIONS)]


def intelligence_score(store, hero_id: int) -> tuple[float, str] | None:
    """Évaluation de départ de l'Intelligence, d'après le palier de départ des matières choisies
    (hors annexes). None tant qu'une matière choisie n'est pas placée."""
    choice = get_choice(store, hero_id)
    core = [c for c in choice["subjects"] if c not in C.ANNEX_SUBJECTS] or choice["subjects"]
    levels, _, _ = _rows(store, hero_id)
    placed = {c: next((p for _, p in levels.get(c, []) if p.get("source") == "placement"), None) for c in core}
    if not core or any(v is None for v in placed.values()):
        return None
    t = sum(LEVELS.index(p["level"]) for p in placed.values()) / len(placed)
    score = 0.2 if t < 0.5 else 0.45 if t < 1.5 else 0.7 if t < 2.5 else 0.9
    detail = "placement : " + ", ".join(f"{C.SUBJECT_CHAINS[c]} {C.LEVEL_LABELS[p['level']]}" for c, p in placed.items())
    return score, detail
