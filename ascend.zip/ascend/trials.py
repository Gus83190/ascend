"""Épreuves des rangs A et S.

L'XP mesure l'engagement ; l'épreuve prouve le niveau réel. Sans elle, une stat reste
plafonnée au rang B (épreuve A) ou A (épreuve S), même avec assez d'XP.

Les épreuves se valident AUTOMATIQUEMENT à partir des saisies : pas de formulaire à part.
Chaque épreuve a une ou plusieurs voies (`ways`) ; une voie est réussie quand tous ses
critères le sont. Un critère réussi reste acquis.

Les cibles physiques sont des valeurs de référence pour un adulte de 18 à 34 ans, ajustées
selon le profil du héros (âge, sexe, profil aménagé) : voir `factor()`.
"""
from dataclasses import dataclass
from datetime import date
from typing import Callable

from . import catalog as K
from . import config as C
from . import health as HL

# ------------------------------------------------------------------ ajustement au profil
# Facteur d'âge (borne d'âge exclue → facteur), inspiré des catégories « masters » du sport.
AGE_FACTORS = [(18, 0.9), (35, 1.0), (45, 0.92), (55, 0.85), (65, 0.75), (200, 0.65)]
# Facteur selon le sexe, par type d'effort (valeurs de référence = homme adulte).
SEX_FACTORS = {"femme": {"haut": 0.5, "bas": 0.8, "cardio": 0.89}}
ADAPTED_FACTOR = 0.6          # profil aménagé (handicap, maladie chronique) : cibles physiques allégées
DIM_LABELS = {"haut": "haut du corps", "bas": "jambes", "cardio": "course", "souplesse": "souplesse",
              "équilibre": "équilibre", "coordination": "coordination"}


def age_factor(age: int | None) -> float:
    if age is None:
        return 1.0
    return next(f for bound, f in AGE_FACTORS if age < bound)


def health_ids(hero) -> list[str]:
    """Situations de santé du héros (l'ancien « profil aménagé » vaut « autre situation physique »)."""
    ids = list(getattr(hero, "conditions", []) or [])
    if getattr(hero, "adapted", False) and not ids:
        ids = ["autre_physique"]
    return ids


def factor(hero, today: date, dim: str | None) -> float:
    """Multiplicateur appliqué à la cible d'un critère (1 = valeur de référence, 0 = dispensé)."""
    if dim is None:
        return 1.0
    f = 1.0
    age = hero.age(today) if hasattr(hero, "age") else None
    if dim in ("haut", "bas", "cardio", "coordination", "équilibre", "outing"):
        f *= age_factor(age)
    elif dim == "souplesse" and age is not None and age >= 45:
        f *= 0.85
    f *= SEX_FACTORS.get(getattr(hero, "sex", None), {}).get(dim, 1.0)
    f *= HL.factor(health_ids(hero), dim)
    return f


def applicable(c, hero, today: date) -> bool:
    """Un critère dont l'effort est impossible avec le profil santé (facteur 0) est dispensé."""
    return c.dim is None or factor(hero, today, c.dim) > 1e-9


def explain(hero, today: date) -> list[str]:
    """Explications de l'ajustement pour l'écran Profil."""
    out = []
    age = hero.age(today)
    if age is None:
        out.append("Âge non renseigné : valeurs de référence d'un adulte de 18 à 34 ans.")
    elif age_factor(age) != 1.0:
        out.append(f"{age} ans : cibles physiques à {age_factor(age):.0%} de la référence.")
    else:
        out.append(f"{age} ans : valeurs de référence.")
    if hero.sex in SEX_FACTORS:
        parts = ", ".join(f"{DIM_LABELS[d]} {v:.0%}" for d, v in SEX_FACTORS[hero.sex].items())
        out.append(f"Profil {hero.sex} : {parts} (souplesse et équilibre inchangés).")
    elif hero.sex is None:
        out.append("Sexe non précisé : valeurs de référence.")
    for line in HL.describe(health_ids(hero)):
        out.append(line)
    return out


@dataclass(frozen=True)
class Criterion:
    id: str
    label: str                        # gabarit : {v} est remplacé par la cible ajustée
    check: Callable | None = None     # (hero, today, kind, data, proof, target) -> bool, sur une saisie
    count: Callable | None = None     # (hero, today) -> (valeur, cible), compté sur la durée
    base: float | None = None         # cible de référence
    dim: str | None = None            # type d'effort (ajusté au profil) ; None = pas d'ajustement
    mode: str = "min"                 # "min" : au moins la cible ; "max" : au plus (un temps)
    unit: str = "n"                   # "n" (entier), "ratio" (× poids), "min" (durée)
    fmt: Callable | None = None       # libellé calculé à partir de la cible (cas particuliers)


def target(c: Criterion, hero, today: date):
    if c.base is None and c.count is not None and c.dim:
        return max(1, int(round(c.count(hero, today)[1] * factor(hero, today, c.dim))))
    if c.base is None:
        return None
    f = factor(hero, today, c.dim)
    v = c.base * f if c.mode == "min" else c.base / f
    if c.unit == "ratio":
        return round(v, 2)
    if c.unit == "min":
        return int(round(v))
    return max(1, int(round(v)))


def _show(v, unit: str) -> str:
    if unit == "ratio":
        return f"{v:g}".replace(".", ",")
    if unit == "min":
        h, m = divmod(int(v), 60)
        return f"{h} h {m:02d}" if h else f"{m} min"
    return f"{v:g}"


def label(c: Criterion, hero, today: date) -> str:
    t = target(c, hero, today)
    if c.fmt and t is not None:
        return c.fmt(t)
    return c.label if t is None else c.label.format(v=_show(t, c.unit))


# ------------------------------------------------------------------ critères sur une saisie

def _variant(family: str, min_variant: str):
    def check(hero, today, kind, data, proof, amount):
        if kind not in ("bodyweight", "skill") or data.get("family") != family:
            return False
        try:
            harder = K.index_of(family, data["variant"]) >= K.index_of(family, min_variant)
        except (KeyError, ValueError):
            return False
        return harder and max(data.get("sets") or [0]) >= amount
    return check


def _squat():
    def check(hero, today, kind, data, proof, ratio):
        if kind != "strength" or str(data.get("exercise", "")).lower() != "squat":
            return False
        best = max((w * (1 + min(r, 12) / 30) for w, r in data.get("sets", []) if r >= 1), default=0)
        return best >= ratio * hero.bodyweight
    return check


def _run(km: float):
    def check(hero, today, kind, data, proof, max_minutes):
        return (kind == "endurance" and data.get("sport", "course") == "course"
                and data.get("distance_km", 0) >= km and 0 < data.get("minutes", 0) <= max_minutes)
    return check


def _focus():
    def check(hero, today, kind, data, proof, minutes):
        return kind == "focus" and bool(proof) and data.get("minutes", 0) >= minutes and data.get("interruptions", 0) == 0
    return check


def _lang_tier(min_level: str):
    """Épreuve de langue : un palier atteint en anglais ou en espagnol (vérifié par placement ou examen)."""
    order = list(C.SUBJECT_LEVELS)

    def check(hero, today, kind, data, proof, _t):
        levels = getattr(hero, "subject_levels", {}) or {}
        return any(levels.get(ch) in order and order.index(levels[ch]) >= order.index(min_level)
                   for ch in ("anglais", "espagnol"))
    return check


def _language(min_level: str):
    levels = list(C.LANGUAGE_LEVELS)

    def check(hero, today, kind, data, proof, _t):
        lvl = data.get("level", "B1")
        return (kind in ("language", "english") and lvl in levels
                and levels.index(lvl) >= levels.index(min_level)
                and data.get("n", 0) >= 20 and data.get("score", 0) >= 0.8)
    return check


def _outing(cotations: set[str], km: float, d_plus: float):
    def check(hero, today, kind, data, proof, km_target):
        if kind != "expedition" or not proof:
            return False
        dp = d_plus * km_target / km                     # dénivelé ajusté dans la même proportion
        return data.get("cotation") in cotations or (data.get("distance_km", 0) >= km_target and data.get("elevation_m", 0) >= dp)
    return check


def _outing_label(cot: str, km: float, d_plus: float):
    return lambda t: (f"Sortie {cot}, ou {t:g} km et {round(d_plus * t / km / 50) * 50:,} m D+ en un jour, avec trace GPX"
                      .replace(",", " "))


# ------------------------------------------------------------------ critères comptés sur la durée

def _nights(target_: int, days: int):
    def count(hero, today):
        return sum(1 for d, score in hero.sleep_scores if 0 <= (today - d).days < days and score >= 75), target_
    return count


def _works(target_: int, days: int):
    def count(hero, today):
        return sum(1 for d in hero.works.values() if 0 <= (today - d).days < days), target_
    return count


def _meditation_days(target_: int, days: int):
    def count(hero, today):
        return sum(1 for d in hero.meditation_days if 0 <= (today - d).days < days), target_
    return count


# ------------------------------------------------------------------ les épreuves

TRIALS: dict[tuple[str, str], list[list[Criterion]]] = {
    ("Force", "A"): [
        [Criterion("pompes30", "{v} pompes classiques d'affilée", _variant("poussée", "classique"), base=30, dim="haut"),
         Criterion("tractions10", "{v} tractions strictes", _variant("tirage", "traction"), base=10, dim="haut"),
         Criterion("pistols5", "{v} pistol squats par jambe", _variant("jambes", "pistol"), base=5, dim="bas")],
        [Criterion("squat15", "Squat en salle à {v} × ton poids (1RM estimé)", _squat(), base=1.5, dim="bas", unit="ratio")],
    ],
    ("Force", "S"): [
        [Criterion("unbras5", "{v} pompes sur un bras par côté", _variant("poussée", "un_bras"), base=5, dim="haut"),
         Criterion("tractions15", "{v} tractions strictes", _variant("tirage", "traction"), base=15, dim="haut"),
         Criterion("pistols10", "{v} pistol squats par jambe", _variant("jambes", "pistol"), base=10, dim="bas")],
        [Criterion("squat20", "Squat en salle à {v} × ton poids (1RM estimé)", _squat(), base=2.0, dim="bas", unit="ratio")],
    ],
    ("Endurance", "A"): [[Criterion("10k50", "10 km de course en moins de {v}", _run(10), base=50, dim="cardio",
                                    mode="max", unit="min")]],
    ("Endurance", "S"): [[Criterion("semi95", "Semi-marathon (21,1 km) en moins de {v}", _run(21.1), base=95, dim="cardio",
                                    mode="max", unit="min")]],
    ("Agilité", "A"): [
        [Criterion("paumes60", "Paumes à plat au sol, {v} s", _variant("souplesse", "paumes_sol"), base=60, dim="souplesse"),
         Criterion("yeuxfermes60", "{v} s sur une jambe, yeux fermés", _variant("équilibre", "unipodal_ferme"), base=60,
                   dim="équilibre")],
    ],
    ("Agilité", "S"): [
        [Criterion("grandecart", "Grand écart complet, {v} s", _variant("souplesse", "grand_ecart"), base=30, dim="souplesse"),
         Criterion("doubles30", "{v} s de doubles sauts à la corde sans faute", _variant("coordination", "double_under"),
                   base=30, dim="coordination")],
    ],
    ("Vitalité", "A"): [[Criterion("nuits90", "{v} bonnes nuits sur 120 jours", count=_nights(90, 120), dim="nights")]],
    ("Vitalité", "S"): [[Criterion("nuits300", "{v} bonnes nuits sur 365 jours", count=_nights(300, 365), dim="nights")]],
    ("Intelligence", "A"): [
        [Criterion("langueB2", "Palier Bac +3 (licence) atteint en anglais ou en espagnol", _lang_tier("bac+3"))],
        [Criterion("oeuvres24", "{v} œuvres validées par quiz en un an", count=_works(24, 365), dim="works")],
    ],
    ("Intelligence", "S"): [
        [Criterion("langueC1", "Palier Bac +4/+5 (master) atteint en anglais ou en espagnol", _lang_tier("bac+5"))],
        [Criterion("oeuvres50", "{v} œuvres validées par quiz en deux ans", count=_works(50, 730), dim="works")],
    ],
    ("Mental", "A"): [[Criterion("focus120", "{v} de concentration au minuteur, sans interruption", _focus(), base=120,
                                 dim="focus", unit="min")]],
    ("Mental", "S"): [
        [Criterion("focus180", "{v} de concentration au minuteur, sans interruption", _focus(), base=180, dim="focus", unit="min"),
         Criterion("medit100", "{v} jours de méditation sur 120", count=_meditation_days(100, 120), dim="meditation")],
    ],
    ("Expédition", "A"): [
        [Criterion("sortieA", "", _outing({"T4", "T5", "T6"}, 30, 1500), base=30, dim="outing",
                   fmt=_outing_label("T4", 30, 1500))],
    ],
    ("Expédition", "S"): [
        [Criterion("sortieS", "", _outing({"T5", "T6"}, 50, 2500), base=50, dim="outing",
                   fmt=_outing_label("T5", 50, 2500))],
    ],
}


def update(hero, today: date, kind: str, data: dict, proof, accepted: bool, stat: str | None = None) -> list[str]:
    """Après une saisie acceptée : suit les compteurs et coche les critères atteints.
    Renvoie les messages à afficher (critère réussi, épreuve réussie)."""
    if not accepted:
        return []
    # Compteurs utilisés par les critères « sur la durée ».
    if kind == "meditation" and data.get("minutes", 0) >= 10:
        hero.meditation_days.add(today)
    if kind == "reading" and (data.get("quiz") or 0) >= 0.6 and data.get("oeuvre"):
        hero.works.setdefault(str(data["oeuvre"]).strip().lower(), today)
    notes = []
    only = stat
    for (stat, rank), ways in TRIALS.items():
        if (stat, rank) in hero.trials_passed or (only and stat != only):
            continue
        for way in ways:
            for c in way:
                key = (stat, rank, c.id)
                if key in hero.trial_marks or not applicable(c, hero, today):
                    continue
                ok = c.check(hero, today, kind, data, proof, target(c, hero, today)) if c.check \
                    else _count_ok(c, hero, today)
                if ok:
                    hero.trial_marks.add(key)
                    notes.append(f"Épreuve {stat} rang {rank} : « {label(c, hero, today)} » réussi")
        notes += _close(hero, stat, rank, ways, today)
    return notes


def _count_ok(c: Criterion, hero, today: date) -> bool:
    value, target_ = c.count(hero, today)
    return value >= (target(c, hero, today) or target_)


def _way_ok(hero, stat: str, rank: str, way, today: date) -> bool:
    """Une voie est réussie quand tous ses critères APPLICABLES le sont (et qu'il en reste au moins un)."""
    needed = [c for c in way if applicable(c, hero, today)]
    return bool(needed) and all((stat, rank, c.id) in hero.trial_marks for c in needed)


def _close(hero, stat: str, rank: str, ways, today: date) -> list[str]:
    if any(_way_ok(hero, stat, rank, way, today) for way in ways):
        hero.trials_passed.add((stat, rank))
        return [f"Épreuve du rang {rank} en {stat} réussie !"]
    return []


def status(hero, today: date, stat: str) -> list[dict]:
    """État des épreuves A et S d'une stat, pour l'affichage (cibles ajustées au profil)."""
    out = []
    for rank in ("A", "S"):
        ways = TRIALS.get((stat, rank), [])
        out.append({
            "rank": rank,
            "passed": (stat, rank) in hero.trials_passed,
            "ways": [[{
                "label": label(c, hero, today) if applicable(c, hero, today) else
                (c.label.format(v=_show(c.base, c.unit)) if c.base is not None and not c.fmt else c.label or c.id)
                + " (dispensé pour ton profil)",
                "done": (stat, rank, c.id) in hero.trial_marks,
                "waived": not applicable(c, hero, today),
                "adjusted": c.dim is not None and abs(factor(hero, today, c.dim) - 1) > 1e-9,
                **({"value": c.count(hero, today)[0], "target": target(c, hero, today) or c.count(hero, today)[1]}
                   if c.count else {}),
            } for c in way] for way in ways if any(applicable(c, hero, today) for c in way)],
        })
    return out


# Intelligence : le rang est aussi limité par le palier le plus haut atteint dans une matière.
INTEL_TIER_CAP = {"collège": "D", "lycée": "C", "bac+2": "B", "bac+3": "A", "bac+5": "S"}
TIER_FOR_RANK = {"C": "lycée", "B": "bac+2", "A": "bac+3", "S": "bac+5"}
_R = ["E", "D", "C", "B", "A", "S"]


def intel_tier_cap(hero) -> str:
    levels = getattr(hero, "subject_levels", {}) or {}
    best = max((_R.index(INTEL_TIER_CAP[l]) for l in levels.values() if l in INTEL_TIER_CAP), default=1)
    return _R[best]


def blocker(hero, stat: str, raw_rank: str) -> dict | None:
    """Ce qui empêche d'afficher le rang de l'XP : une épreuve, ou (Intelligence) un palier."""
    shown = cap(hero, stat, raw_rank)
    if shown == raw_rank:
        return None
    nxt = _R[_R.index(shown) + 1]
    trial = cap_trials(hero, stat, raw_rank)
    if trial == shown:                       # c'est l'épreuve qui bloque
        return {"kind": "épreuve", "rank": nxt, "text": f"épreuve du rang {nxt} requise"}
    from . import config as _C
    return {"kind": "palier", "rank": nxt,
            "text": f"palier {_C.LEVEL_LABELS[TIER_FOR_RANK[nxt]]} requis dans une matière pour le rang {nxt}"}

def cap_trials(hero, stat: str, raw_rank: str) -> str:
    """Plafond des épreuves : B sans épreuve A, A sans épreuve S."""
    if raw_rank in ("A", "S") and (stat, "A") not in hero.trials_passed:
        return "B"
    if raw_rank == "S" and (stat, "S") not in hero.trials_passed:
        return "A"
    return raw_rank


def cap(hero, stat: str, raw_rank: str) -> str:
    """Rang affiché : plafonné tant que l'épreuve manque (B sans épreuve A, A sans épreuve S) et,
    pour l'Intelligence, tant que le palier nécessaire n'est pas atteint dans une matière."""
    shown = cap_trials(hero, stat, raw_rank)
    if stat == "Intelligence":
        shown = _R[min(_R.index(shown), _R.index(intel_tier_cap(hero)))]
    return shown
