"""Cartes de révision à répétition espacée (méthode des boîtes de Leitner).

Une carte réussie passe dans la boîte suivante et revient de plus en plus tard (1, 2, 4, 8, 16,
32 jours) ; une carte ratée revient en boîte 1, le lendemain. On ne révise que les cartes « dues » :
réviser 100 fois la même carte ne rapporte rien. Tout est relu depuis le journal (événements
« card » et « review »), comme le reste d'ASCEND.
"""
import json
import secrets
from datetime import date, timedelta

INTERVALS = [0, 1, 2, 4, 8, 16, 32]          # jours d'attente selon la boîte (0 = nouvelle carte)
MAX_CARDS = 3000
MAX_TEXT = 300
SESSION_MAX = 60                             # cartes proposées par séance


def _replay(store, hero_id: int, today: date) -> dict[str, dict]:
    cards: dict[str, dict] = {}
    for ev in store.db.execute("SELECT day, type, payload FROM events WHERE hero_id=? AND type IN ('card', 'review') "
                               "AND day<=? ORDER BY day, id", (hero_id, today.isoformat())):
        p, d = json.loads(ev["payload"]), date.fromisoformat(ev["day"])
        if ev["type"] == "card":
            if p.get("action") == "add":
                cards[p["id"]] = {"id": p["id"], "deck": p.get("deck", "Mes cartes"), "front": p.get("front", ""),
                                  "back": p.get("back", ""), "box": 0, "due": d, "added": d, "reviews": 0, "ok": 0,
                                  "source": p.get("source")}
            elif p.get("action") == "del":
                cards.pop(p.get("id"), None)
            elif p.get("action") == "deldeck":
                for cid in [c["id"] for c in cards.values() if c["deck"] == p.get("deck")]:
                    cards.pop(cid)
        else:
            c = cards.get(p.get("id"))
            if c is None or d < c["due"]:
                continue                                  # révision non due : ignorée (déjà refusée à l'enregistrement)
            c["reviews"] += 1
            if p.get("ok"):
                c["ok"] += 1
                c["box"] = min(len(INTERVALS) - 1, c["box"] + 1)
            else:
                c["box"] = 1
            c["due"] = d + timedelta(days=INTERVALS[c["box"]])
    return cards


def _today_reviews(store, hero_id: int, today: date) -> tuple[int, int]:
    n = ok = 0
    for ev in store.db.execute("SELECT payload FROM events WHERE hero_id=? AND type='review' AND day=?",
                               (hero_id, today.isoformat())):
        n += 1
        ok += bool(json.loads(ev["payload"]).get("ok"))
    return n, ok


def _credited_today(store, hero_id: int, today: date) -> int:
    tot = 0
    for ev in store.db.execute("SELECT payload FROM events WHERE hero_id=? AND type='activity' AND day=?",
                               (hero_id, today.isoformat())):
        p = json.loads(ev["payload"])
        if p.get("kind") == "cards":
            tot += int((p.get("data") or {}).get("n", 0))
    return tot


def overview(store, hero_id: int, today: date) -> dict:
    cards = _replay(store, hero_id, today)
    decks: dict[str, dict] = {}
    for c in cards.values():
        dk = decks.setdefault(c["deck"], {"name": c["deck"], "count": 0, "due": 0, "learned": 0, "source": c.get("source")})
        dk["count"] += 1
        dk["due"] += c["due"] <= today
        dk["learned"] += c["box"] >= 4
    due = sorted((c for c in cards.values() if c["due"] <= today), key=lambda c: (c["box"], c["due"], c["id"]))
    n, ok = _today_reviews(store, hero_id, today)
    nxt = min((c["due"] for c in cards.values() if c["due"] > today), default=None)
    return {"decks": sorted(decks.values(), key=lambda d: d["name"].lower()), "total": len(cards),
            "due_count": len(due), "session": [{"id": c["id"], "deck": c["deck"], "front": c["front"], "back": c["back"],
                                                "box": c["box"]} for c in due[:SESSION_MAX]],
            "today": {"reviews": n, "ok": ok, "uncredited": max(0, n - _credited_today(store, hero_id, today))},
            "next_due": nxt.isoformat() if nxt else None, "boxes": [sum(1 for c in cards.values() if c["box"] == b)
                                                                    for b in range(len(INTERVALS))],
            "intervals": INTERVALS}


def deck_cards(store, hero_id: int, today: date, deck: str) -> list[dict]:
    return [{"id": c["id"], "front": c["front"], "back": c["back"], "box": c["box"], "due": c["due"].isoformat()}
            for c in _replay(store, hero_id, today).values() if c["deck"] == deck]


def _clean(v, label: str) -> str:
    if not isinstance(v, str) or not v.strip():
        raise ValueError(f"{label} : texte attendu")
    return " ".join(v.split())[:MAX_TEXT]


def add_cards(store, hero_id: int, today: date, deck: str, pairs, source: str | None = None) -> int:
    cards = _replay(store, hero_id, today)
    deck = _clean(deck, "Paquet")[:60]
    if len(cards) + len(pairs) > MAX_CARDS:
        raise ValueError(f"{MAX_CARDS} cartes au plus")
    seen = {(c["deck"], c["front"].lower()) for c in cards.values()}
    added = 0
    for front, back in pairs:
        front, back = _clean(front, "Recto"), _clean(back, "Verso")
        if (deck, front.lower()) in seen:
            continue
        seen.add((deck, front.lower()))
        store._event(hero_id, today, "card", {"action": "add", "id": secrets.token_hex(5), "deck": deck, "front": front,
                                              "back": back, **({"source": source} if source else {})})
        added += 1
    return added


def action(store, hero_id: int, today: date, body: dict) -> str:
    act = body.get("action")
    if act == "add":
        n = add_cards(store, hero_id, today, body.get("deck") or "Mes cartes", [(body.get("front"), body.get("back"))])
        if not n:
            raise ValueError("Cette carte existe déjà dans ce paquet")
        return "Carte ajoutée."
    if act == "bulk":
        lines = str(body.get("text", "")).splitlines()
        pairs = []
        for ln in lines[:500]:
            for sep in (" ; ", ";", " = ", "\t"):
                if sep in ln:
                    a, b = ln.split(sep, 1)
                    if a.strip() and b.strip():
                        pairs.append((a, b))
                    break
        if not pairs:
            raise ValueError("Une carte par ligne : recto ; verso")
        n = add_cards(store, hero_id, today, body.get("deck") or "Mes cartes", pairs)
        return f"{n} carte(s) ajoutée(s)" + (f" ({len(pairs) - n} déjà présente(s))" if n < len(pairs) else "") + "."
    cards = _replay(store, hero_id, today)
    if act == "del":
        if body.get("id") not in cards:
            raise ValueError("Carte inconnue")
        store._event(hero_id, today, "card", {"action": "del", "id": body["id"]})
        return "Carte supprimée."
    if act == "deldeck":
        deck = body.get("deck")
        if not any(c["deck"] == deck for c in cards.values()):
            raise ValueError("Paquet inconnu")
        store._event(hero_id, today, "card", {"action": "deldeck", "deck": deck})
        return f"Paquet « {deck} » supprimé."
    if act == "review":
        c = cards.get(body.get("id"))
        if c is None:
            raise ValueError("Carte inconnue")
        if c["due"] > today:
            raise ValueError("Cette carte n'est pas encore à réviser")
        if not isinstance(body.get("ok"), bool):
            raise ValueError("Réponse : su ou pas su")
        store._event(hero_id, today, "review", {"id": c["id"], "ok": body["ok"]})
        return "Vu."
    raise ValueError("Action inconnue")
