"""Couche « jeu » : titres à débloquer et célébrations (rang, niveau, épreuve, titre).

Les titres sont calculés à partir de l'état du héros : rien n'est stocké, donc une saisie
annulée retire aussi le titre qu'elle avait débloqué. Cosmétique uniquement : aucun bonus.
"""
from dataclasses import dataclass
from datetime import date
from typing import Callable

from . import config as C


def _ranks(hero) -> list[int]:
    return [C.RANKS.index(hero.rank_of(s)) for s in C.STATS]


@dataclass(frozen=True)
class Title:
    id: str
    name: str            # nom dans la famille de styles Classique
    manga: str           # nom dans la famille Manga
    desc: str
    rule: Callable       # (hero, day) -> bool


TITLES = [
    Title("eveille", "Premier palier", "Éveillé", "Atteindre le rang D dans une stat", lambda h, d: max(_ranks(h)) >= 1),
    Title("polyvalent", "Polyvalent", "Touche-à-tout", "Atteindre le rang D dans les 7 stats", lambda h, d: min(_ranks(h)) >= 1),
    Title("pilier", "Pilier", "Pilier du clan", "Atteindre le rang C dans 3 stats", lambda h, d: sum(r >= 2 for r in _ranks(h)) >= 3),
    Title("veteran", "Vétéran", "Vétéran des arènes", "Atteindre le rang B dans une stat", lambda h, d: max(_ranks(h)) >= 3),
    Title("eprouve", "Éprouvé", "Héros éprouvé", "Réussir une épreuve du rang A", lambda h, d: any(r == "A" for _, r in h.trials_passed)),
    Title("legende", "Légende", "Légende vivante", "Réussir une épreuve du rang S", lambda h, d: any(r == "S" for _, r in h.trials_passed)),
    Title("regulier", "Régulier", "Flamme tenace", "Tenir une série de 7 jours", lambda h, d: h.discipline.streak(d) >= 7),
    Title("inebranlable", "Inébranlable", "Volonté de fer", "Tenir une série de 30 jours", lambda h, d: h.discipline.streak(d) >= 30),
    Title("lecteur", "Rat de bibliothèque", "Dévoreur de livres", "Valider 10 œuvres par quiz", lambda h, d: len(h.works) >= 10),
    Title("voyageur", "Grand voyageur", "Vagabond", "Découvrir 15 lieux", lambda h, d: len(h.seen_places) >= 15),
    Title("dormeur", "Sommeil réparateur", "Gardien du sommeil", "Réussir 30 bonnes nuits (note ≥ 75)",
          lambda h, d: sum(sc >= 75 for _, sc in h.sleep_scores) >= 30),
    Title("serein", "Esprit serein", "Âme sereine", "Méditer 30 jours (10 min ou plus)", lambda h, d: len(h.meditation_days) >= 30),
    Title("niveau10", "Initié", "Apprenti héros", "Atteindre le niveau 10", lambda h, d: h.level >= 10),
    Title("niveau25", "Ascendant", "Ascendant", "Atteindre le niveau 25", lambda h, d: h.level >= 25),
    Title("lore", "Fin du premier livre", "Au sommet de la Tour", "Atteindre le niveau 100 (dernier chapitre de l'histoire)",
          lambda h, d: h.level >= 100),
]

# Titres liés aux autres écrans (défis, carnet, langues…) : ils se calculent avec des compteurs
# fournis par seasons.Journal (`extra`), pas seulement avec la fiche du héros.
EXTRA_TITLES = [
    ("defi1", "Défi relevé", "Briseur de donjon", "Réussir un défi de plusieurs jours", "defis", 1),
    ("defi5", "Persévérant", "Conquérant", "Réussir 5 défis", "defis", 5),
    ("carnet30", "Plume fidèle", "Chroniqueur", "Écrire 30 pages de carnet", "notes", 30),
    ("gratitude21", "Reconnaissant", "Cœur lumineux", "Noter 3 choses positives 21 jours", "gratitude_days", 21),
    ("mots10k", "Auteur", "Maître des encres", "Écrire 10 000 mots (défi d'écriture)", "words", 10000),
    ("langueb2", "Bilingue", "Polyglotte", "Valider le niveau B2 dans une langue", "lang_level", 4),
    ("languec2", "Maîtrise C2", "Maître des langues", "Valider le niveau C2 dans une langue", "lang_level", 6),
    ("cartes300", "Mémoire d'éléphant", "Mémoire infaillible", "300 cartes de révision bien sues (boîte 4 ou plus)", "cards_learned", 300),
    ("semi", "Semi-marathonien", "Coureur des plaines", "Courir 21,1 km d'une traite", "longest_run", 21.1),
    ("force12", "Force tranquille", "Forgeron", "Suivre 12 semaines un programme de force avec charges", "lift_weeks", 12),
    ("objectifs10", "Bâtisseur", "Visionnaire", "Atteindre 10 objectifs personnels", "goals", 10),
    ("km100", "Randonneur", "Arpenteur", "Cumuler 100 km d'expédition", "exp_km", 100),
    ("mobilite50", "Souplesse", "Corps de roseau", "50 séances de mobilité ou de yoga", "mobility", 50),
]


def unlocked(hero, day: date) -> set[str]:
    return {t.id for t in TITLES if t.rule(hero, day)}


def collection(hero, day: date, extra: dict | None = None) -> list[dict]:
    have = unlocked(hero, day)
    out = [{"id": t.id, "name": t.name, "manga": t.manga, "desc": t.desc, "unlocked": t.id in have} for t in TITLES]
    extra = extra or {}
    for tid, name, manga, desc, key, need in EXTRA_TITLES:
        out.append({"id": tid, "name": name, "manga": manga, "desc": desc, "unlocked": (extra.get(key) or 0) >= need})
    return out


def celebrations(before, after, day: date) -> list[dict]:
    """Ce qui mérite d'être fêté après une saisie : comparaison avant / après."""
    out = []
    for s in C.STATS:
        a, b = before.rank_of(s), after.rank_of(s)
        if C.RANKS.index(b) > C.RANKS.index(a):
            out.append({"type": "rank", "stat": s, "from": a, "to": b, "text": f"Rang {b} atteint en {s} !"})
    if after.level > before.level:
        out.append({"type": "level", "from": before.level, "to": after.level, "text": f"Niveau {after.level} !"})
    for st, rk in sorted(after.trials_passed - before.trials_passed):
        out.append({"type": "trial", "stat": st, "rank": rk, "text": f"Épreuve du rang {rk} réussie en {st} !"})
    names = {t.id: t for t in TITLES}
    for tid in sorted(unlocked(after, day) - unlocked(before, day)):
        out.append({"type": "title", "id": tid, "text": f"Titre débloqué : {names[tid].name}",
                    "manga_text": f"Titre débloqué : {names[tid].manga}", "desc": names[tid].desc})
    return out
