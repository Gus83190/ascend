"""Couche « jeu » : titres à débloquer et célébrations (rang, niveau, épreuve, titre).

Les titres sont calculés à partir de l'état du héros : rien n'est stocké, donc une saisie
annulée retire aussi le titre qu'elle avait débloqué. Cosmétique uniquement : aucun bonus.
"""
from dataclasses import dataclass
from datetime import date
from typing import Callable

from . import config as C


def _ranks(hero) -> list[int]:
    return [C.RANKS.index(hero.rank_of(s)) for s in C.STATS]


@dataclass(frozen=True)
class Title:
    id: str
    name: str
    desc: str
    rule: Callable  # (hero, day) -> bool


TITLES = [
    Title("eveille", "Éveillé", "Atteindre le rang D dans une stat", lambda h, d: max(_ranks(h)) >= 1),
    Title("polyvalent", "Polyvalent", "Atteindre le rang D dans les 7 stats", lambda h, d: min(_ranks(h)) >= 1),
    Title("pilier", "Pilier", "Atteindre le rang C dans 3 stats", lambda h, d: sum(r >= 2 for r in _ranks(h)) >= 3),
    Title("veteran", "Vétéran", "Atteindre le rang B dans une stat", lambda h, d: max(_ranks(h)) >= 3),
    Title("eprouve", "Éprouvé", "Réussir une épreuve du rang A", lambda h, d: any(r == "A" for _, r in h.trials_passed)),
    Title("legende", "Légende", "Réussir une épreuve du rang S", lambda h, d: any(r == "S" for _, r in h.trials_passed)),
    Title("regulier", "Régulier", "Tenir une série de 7 jours", lambda h, d: h.discipline.streak(d) >= 7),
    Title("inebranlable", "Inébranlable", "Tenir une série de 30 jours", lambda h, d: h.discipline.streak(d) >= 30),
    Title("lecteur", "Rat de bibliothèque", "Valider 10 œuvres par quiz", lambda h, d: len(h.works) >= 10),
    Title("voyageur", "Grand voyageur", "Découvrir 15 lieux", lambda h, d: len(h.seen_places) >= 15),
    Title("dormeur", "Gardien du sommeil", "Réussir 30 bonnes nuits (note ≥ 75)", lambda h, d: sum(sc >= 75 for _, sc in h.sleep_scores) >= 30),
    Title("serein", "Esprit serein", "Méditer 30 jours (10 min ou plus)", lambda h, d: len(h.meditation_days) >= 30),
    Title("niveau10", "Initié", "Atteindre le niveau 10", lambda h, d: h.level >= 10),
    Title("niveau25", "Ascendant", "Atteindre le niveau 25", lambda h, d: h.level >= 25),
]


def unlocked(hero, day: date) -> set[str]:
    return {t.id for t in TITLES if t.rule(hero, day)}


def collection(hero, day: date) -> list[dict]:
    have = unlocked(hero, day)
    return [{"id": t.id, "name": t.name, "desc": t.desc, "unlocked": t.id in have} for t in TITLES]


def celebrations(before, after, day: date) -> list[dict]:
    """Ce qui mérite d'être fêté après une saisie : comparaison avant / après."""
    out = []
    for s in C.STATS:
        a, b = before.rank_of(s), after.rank_of(s)
        if C.RANKS.index(b) > C.RANKS.index(a):
            out.append({"type": "rank", "stat": s, "from": a, "to": b, "text": f"Rang {b} atteint en {s} !"})
    if after.level > before.level:
        out.append({"type": "level", "from": before.level, "to": after.level, "text": f"Niveau {after.level} !"})
    for st, rk in sorted(after.trials_passed - before.trials_passed):
        out.append({"type": "trial", "stat": st, "rank": rk, "text": f"Épreuve du rang {rk} réussie en {st} !"})
    names = {t.id: t for t in TITLES}
    for tid in sorted(unlocked(after, day) - unlocked(before, day)):
        out.append({"type": "title", "id": tid, "text": f"Titre débloqué : {names[tid].name}", "desc": names[tid].desc})
    return out
