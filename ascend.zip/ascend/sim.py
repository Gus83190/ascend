"""Simulation de profils sur plusieurs mois pour régler la vitesse de progression."""
import random
from datetime import date, time, timedelta

from . import config as C
from . import catalog as K
from .engine import Hero, log, summary
from .ranks import rank_for

START = date(2026, 1, 5)


def _lift_progress(week: int, start: float, fast: bool = False) -> float:
    """Progression réaliste : rapide au début, puis de plus en plus lente."""
    gain = 1.0 + 0.6 * (1 - 0.985 ** week) if not fast else 1.0 + 0.9 * (1 - 0.99 ** week)
    return start * gain


BW_START = {"poussée": 1.4, "jambes": 1.77, "tirage": 1.07, "gainage": 1.4}   # capacité de départ


def _bw_sets(family: str, cap: float) -> tuple[str, list[int]]:
    """Choisit la variante la plus dure faisable pour une capacité, et ses séries."""
    unit = K.FAMILIES[family]["unit"]
    div, lo, hi = (30, 6, 30) if unit == "reps" else (60, 15, 120)
    best = K.FAMILIES[family]["variants"][0]
    for v in K.FAMILIES[family]["variants"]:
        if lo <= div * (cap / v.coef - 1):
            best = v
    amount = max(1, min(hi, int(div * (cap / best.coef - 1))))
    return best.id, [amount, max(1, int(amount * 0.9)), max(1, int(amount * 0.8))]


def _day(hero: Hero, d: date, profile: str, rnd: random.Random, week: int):
    wd = d.weekday()
    planned = done = 0

    def p(prob):  # le joueur fait-il la séance prévue ?
        return rnd.random() < prob

    if profile in ("sérieux", "sérieux poids du corps"):
        if profile == "sérieux" and wd in (0, 2, 4, 5):
            planned += 1
            if p(0.92):
                done += 1
                top = _lift_progress(week, 80) * rnd.uniform(0.985, 1.01)
                log(hero, d, "strength", exercise="squat", sets=[(top * 0.8, 8)] * 2 + [(top * 0.9, 5), (top, 3)])
        if profile == "sérieux poids du corps" and wd in (0, 2, 4):
            planned += 1
            if p(0.92):
                done += 1
                for fam, start in BW_START.items():   # séance complète : les 4 familles
                    vid, sets = _bw_sets(fam, _lift_progress(week, start) * rnd.uniform(0.985, 1.01))
                    log(hero, d, "bodyweight", family=fam, variant=vid, sets=sets)
        if wd in (1, 3, 6):
            planned += 1
            if p(0.9):
                done += 1
                spd = 9.5 * (1 + 0.15 * (1 - 0.985 ** week)) * rnd.uniform(0.98, 1.02)
                log(hero, d, "endurance", distance_km=spd * 0.6, minutes=36)
        planned += 1
        if p(0.9):
            done += 1
            log(hero, d, "reading", minutes=30, quiz=rnd.uniform(0.7, 0.95))
        planned += 1
        if p(0.85):
            done += 1
            log(hero, d, "sleep", bedtime=time(23, rnd.choice([0, 10, 20, 30, 40])), hours=rnd.uniform(7.0, 8.2))
        # Une « semaine sérieuse » dans chaque stat (base de calibrage : ~250 XP/semaine).
        if wd <= 4:
            planned += 1
            if p(0.85):
                done += 1
                log(hero, d, "focus", minutes=60, interruptions=rnd.randint(0, 2), proof="app")
        if wd in (5, 6):
            planned += 1
            if p(0.8):
                done += 1
                log(hero, d, "meditation", minutes=15)
        if wd == 5:
            planned += 1
            if p(0.7):
                done += 1
                log(hero, d, "expedition", distance_km=12, elevation_m=500, place=f"sentier-{week % 8}", proof="gpx")
        if wd == 2:
            planned += 1
            if p(0.7):
                done += 1
                log(hero, d, "expedition", distance_km=6, elevation_m=50, place=f"quartier-{week % 20}", proof="gpx")
        if wd in (0, 3, 6):
            planned += 1
            if p(0.8):
                done += 1
                log(hero, d, "mobility", minutes=20, score=min(9, 5 + week * 0.04))
    elif profile == "irrégulier":
        if wd in (1, 5):
            planned += 1
            if p(0.5):
                done += 1
                top = _lift_progress(week // 2, 80) * rnd.uniform(0.95, 1.0)
                log(hero, d, "strength", exercise="squat", sets=[(top * 0.8, 8)] * 3)
        planned += 1
        if p(0.4):
            done += 1
            log(hero, d, "reading", minutes=30, quiz=rnd.uniform(0.6, 0.9))
        if wd == 6:
            planned += 1
            if p(0.5):
                done += 1
                log(hero, d, "endurance", distance_km=4, minutes=30)
    elif profile == "présence seule":
        # Se connecte tous les jours mais fait le strict minimum.
        planned += 3
        done += 3
        log(hero, d, "strength", exercise="squat", sets=[(40, 3)])
        log(hero, d, "reading", minutes=45, quiz=None)
        log(hero, d, "endurance", distance_km=0.5, minutes=16)
    elif profile == "tricheur":
        # Invente des charges en forte hausse à chaque séance.
        planned += 2
        done += 2
        try:   # au-delà de 1 000 kg, la saisie est refusée par la validation
            log(hero, d, "strength", exercise="squat", sets=[(80 * (1.2 ** (week + 1)), 5)] * 4)
        except ValueError:
            pass
        log(hero, d, "reading", minutes=300, quiz=None)
    elif profile == "faux explorateur":
        # Déclare chaque jour, sans preuve, une randonnée crédible et 2 h de focus.
        planned += 2
        done += 2
        log(hero, d, "expedition", distance_km=12, elevation_m=500, place=f"lieu-{d.toordinal()}")
        log(hero, d, "focus", minutes=120)
    hero.discipline.record_day(d, planned, done, rest=(planned == 0))


def run(profile: str, days: int, seed: int = 7) -> Hero:
    rnd = random.Random(seed)
    hero = Hero()
    for i in range(days):
        d = START + timedelta(days=i)
        _day(hero, d, profile, rnd, i // 7)
    return hero


PROFILES = ["sérieux", "sérieux poids du corps", "irrégulier", "présence seule", "tricheur", "faux explorateur"]
CHECKPOINTS = [("1 mois", 30), ("3 mois", 91), ("6 mois", 182), ("1 an", 365), ("2 ans", 730), ("3 ans", 1095), ("5 ans", 1825)]


def report(profiles=PROFILES) -> str:
    out = []
    for prof in profiles:
        out.append(f"\n=== Profil « {prof} » ===")
        out.append(f"{'':8}" + "".join(f"{s[:5]:>8}" for s in C.STATS) + f"{'Niv':>6}{'Rang':>6}{'Disc':>7}")
        for label, days in CHECKPOINTS:
            h = run(prof, days)
            end = START + timedelta(days=days - 1)
            row = "".join(f"{rank_for(h.stat_xp[s])+' '+format(h.stat_xp[s]/1000, '.1f')+'k':>8}" for s in C.STATS)
            out.append(f"{label:<8}{row}{h.level:>6}{h.rank:>6}{h.discipline.value(end):>6.0f}%")
    return "\n".join(out)
