"""Records personnels et courbes (relus depuis le journal ; seules les saisies acceptées comptent)."""
import json
from datetime import date, timedelta

from . import catalog as K
from . import config as C
from .engine import XPResult


def _pace(minutes: float, km: float) -> str:
    s = round(minutes * 60 / km)
    return f"{s // 60}:{s % 60:02d} /km"


def overview(store, hero_id: int, today: date, weeks: int = 26) -> dict:
    captured: dict = {}
    hero = store.hero(hero_id, until=today, capture=captured)
    rec: dict[str, dict] = {}

    def keep(key, stat, label, value, shown, day, higher=True):
        cur = rec.get(key)
        if cur is None or (value > cur["value"] if higher else value < cur["value"]):
            rec[key] = {"stat": stat, "label": label, "value": value, "shown": shown, "day": day}

    reading_min = 0.0
    for ev in store.db.execute("SELECT id, day, type, payload FROM events WHERE hero_id=? AND day<=? ORDER BY day, id",
                               (hero_id, today.isoformat())):
        p, day = json.loads(ev["payload"]), ev["day"]
        if ev["type"] == "cooper" and p.get("meters"):
            keep("cooper", "Endurance", "Test de Cooper (12 min)", p["meters"], f"{p['meters']:.0f} m", day)
            continue
        if ev["type"] != "activity":
            continue
        r = captured.get(ev["id"])
        if not isinstance(r, XPResult) or r.raw <= 0:
            continue
        k, d = p.get("kind"), p.get("data") or {}
        if k == "strength":
            for w, reps in d.get("sets", []):
                if w > 0 and 1 <= reps <= 12:
                    orm = w * (1 + reps / 30)
                    ex = K.norm_lift(d.get("exercise", "")).capitalize()
                    keep(f"1rm:{ex.lower()}", "Force", f"{ex} (1RM estimée)", orm, f"{orm:.0f} kg".replace(".", ","), day)
        elif k == "endurance":
            km, mn = d.get("distance_km", 0), d.get("minutes", 0)
            if km:
                keep("end_km", "Endurance", "Plus longue sortie", km, f"{km:g} km".replace(".", ","), day)
            if km >= 5 and mn:
                keep("pace5", "Endurance", "Meilleure allure (5 km et plus)", mn / km, _pace(mn, km), day, higher=False)
            if 9.5 <= km <= 10.5 and mn:
                keep("t10", "Endurance", "Meilleur 10 km", mn / km * 10, f"{mn / km * 10:.0f} min", day, higher=False)
        elif k == "expedition":
            keep("exp_km", "Expédition", "Plus longue expédition", d.get("distance_km", 0), f"{d.get('distance_km', 0):g} km".replace(".", ","), day)
            if d.get("elevation_m"):
                keep("exp_dplus", "Expédition", "Plus gros dénivelé", d["elevation_m"], f"{d['elevation_m']:.0f} m D+", day)
        elif k == "focus":
            keep("focus", "Mental", "Plus longue concentration", d.get("minutes", 0), f"{d.get('minutes', 0):.0f} min", day)
        elif k == "meditation":
            keep("medit", "Mental", "Plus longue méditation", d.get("minutes", 0), f"{d.get('minutes', 0):.0f} min", day)
        elif k == "discomfort":
            keep("froid", "Mental", "Plus long inconfort volontaire", d.get("seconds", 0), f"{d.get('seconds', 0):.0f} s", day)
        elif k == "reading":
            reading_min += d.get("minutes", 0)
        elif k == "wellbeing" and d.get("steps"):
            keep("steps", "Vitalité", "Plus de pas en un jour", d["steps"], f"{d['steps']:,} pas".replace(",", " "), day)
        elif k == "mobility":
            keep("mob", "Agilité", "Plus longue séance de mobilité", d.get("minutes", 0), f"{d.get('minutes', 0):.0f} min", day)

    for (fam, vid), best in hero.best_sets.items():
        try:
            v = K.variant(fam, vid)
        except KeyError:
            continue
        unit = "s" if K.FAMILIES[fam]["unit"] == "s" else "rép."
        if best > 0:
            rec[f"bw:{fam}:{vid}"] = {"stat": K.FAMILIES[fam]["stat"], "label": f"{v.name} (meilleure série)", "value": best,
                                     "shown": f"{best:g} {unit}", "day": None}
    if hero.sleep_scores:
        d, sc = max(hero.sleep_scores, key=lambda x: x[1])
        rec["sleep"] = {"stat": "Vitalité", "label": "Meilleure nuit (note)", "value": sc, "shown": f"{sc:.0f}/100", "day": d.isoformat()}
    if hero.works:
        rec["books"] = {"stat": "Intelligence", "label": "Œuvres validées par quiz", "value": len(hero.works),
                        "shown": str(len(hero.works)), "day": None}
    if reading_min:
        rec["reading"] = {"stat": "Intelligence", "label": "Temps de lecture total", "value": reading_min,
                          "shown": f"{reading_min / 60:.0f} h", "day": None}

    # Courbes : XP par semaine et par stat (plafonds appliqués), sur `weeks` semaines.
    monday = today - timedelta(days=today.weekday())
    wk_list = [monday - timedelta(weeks=i) for i in range(weeks - 1, -1, -1)]
    series = {st: [round(hero.weekly_xp.get(((m.isocalendar()[0], m.isocalendar()[1]), st), 0.0)) for m in wk_list]
              for st in C.STATS}
    days30 = [today - timedelta(days=i) for i in range(29, -1, -1)]
    wb = {"days": [d.isoformat() for d in days30],
          "steps": [(hero.wellbeing.get(d) or {}).get("steps") or None for d in days30],
          "mood": [(hero.wellbeing.get(d) or {}).get("mood") for d in days30],
          "sleep": [next((round(s) for dd, s in hero.sleep_scores if dd == d), None) for d in days30]}
    order = {s: i for i, s in enumerate(C.STATS)}
    records = sorted(rec.values(), key=lambda r: (order.get(r["stat"], 99), r["label"]))
    for r in records:
        r["value"] = round(r["value"], 2)
    return {"records": records, "weeks": [m.isoformat() for m in wk_list], "weekly_xp": series, "daily": wb,
            "bodyweight": hero.bodyweight, "age": hero.age(today) if hasattr(hero, "age") else None, "sex": hero.sex}
