"""Tous les réglages de progression au même endroit.

Modifier ces valeurs puis relancer `python -m ascend sim` permet de voir
tout de suite l'effet sur la vitesse de montée en rang.
"""

STATS = ["Force", "Endurance", "Agilité", "Vitalité", "Intelligence", "Mental", "Expédition"]

RANKS = ["E", "D", "C", "B", "A", "S"]

# XP cumulé nécessaire pour ATTEINDRE chaque rang, par stat.
# Calibré sur une « semaine sérieuse » d'environ 250 XP dans chaque stat :
# D ≈ 1 mois, C ≈ 6 mois, B ≈ 18 mois, A ≈ 3 ans, S ≈ 5,5 ans (+ épreuve pour A et S).
RANK_THRESHOLDS = {"E": 0, "D": 1000, "C": 6500, "B": 19500, "A": 39000, "S": 72000}

# Plafond quotidien par stat : au-delà, l'XP est réduite puis annulée.
DAILY_FULL_XP = 120      # jusqu'ici : 100 %
DAILY_SOFT_XP = 240      # entre FULL et SOFT : 25 %, au-delà : 0
SOFT_RATE = 0.25
# L'Expédition se pratique en une grosse sortie par semaine : plafond quotidien plus haut.
DAILY_CAP_OVERRIDES = {"Expédition": (350, 500)}

# Plafond hebdomadaire par stat (même principe que le plafond quotidien).
WEEKLY_FULL_XP = 350
WEEKLY_SOFT_XP = 600

# Anti-triche / plausibilité.
MAX_PROGRESS_PER_SESSION = 0.05   # gain maximal crédité par séance
MAX_PROGRESS_PER_WEEK = 0.04      # cumul maximal crédité sur 7 jours
MAX_PROGRESS_PER_28D = 0.10       # cumul maximal crédité sur 28 jours
IMPLAUSIBLE_JUMP = 0.10           # au-delà : la série n'est pas comptée
MIN_VOLUME_RATIO = 5.0            # volume (kg) / poids de corps minimal pour compter
# Endurance par sport : (coefficient d'intensité, distance min km, allure min km/h,
# allure max plausible km/h, bornes des tranches de distance « court / moyen / long » en km).
ENDURANCE_SPORTS = {
    "course":   (1.0, 1.5, 4.0, 22.0, (7, 15)),
    "marche":   (0.6, 2.0, 4.0, 9.0, (7, 15)),
    "vélo":     (0.8, 5.0, 10.0, 50.0, (25, 60)),
    "natation": (1.1, 0.4, 1.0, 6.0, (1, 3)),
}
# Intelligence : type de contenu lu (densité) et niveau de langue (cadre européen).
READING_CONTENT = {
    "manga": 0.7, "article": 0.8, "journal": 0.8, "revue de presse": 0.8,
    "documentaire": 0.9, "livre audio": 0.9, "livre": 1.0, "essai": 1.2, "technique": 1.3,
}
LANGUAGE_LEVELS = {"A1": 0.7, "A2": 0.85, "B1": 1.0, "B2": 1.15, "C1": 1.3, "C2": 1.45}

# Mental.
MEDITATION_STYLES = {"guidée": 1.0, "libre": 1.2, "silence": 1.4}
JOURNAL_XP = 12.0
DISCOMFORT_MAX_XP = 15.0

# Expédition : cotation de randonnée (échelle T1 → T6) ou exploration urbaine.
EXPEDITION_COTATION = {"urbain": 0.8, "T1": 0.9, "T2": 1.0, "T3": 1.15, "T4": 1.3, "T5": 1.5, "T6": 1.7}
COTATION_NEEDS_PROOF = {"T4", "T5", "T6"}   # sans trace GPX : toujours « déclaré »

# Test de Cooper (mètres courus en 12 min) → rang de départ en Endurance.
# Repères adulte de référence ; à ajuster par âge et sexe.
COOPER_START_RANK = [("D", 2000), ("C", 2500), ("B", 2900)]

# Force au poids du corps (catalogue dans catalog.py). Valeurs par exercice ;
# une séance complète = environ 4 exercices (poussée, jambes, tirage, gainage).
BW_PRESENCE = 3.0
BW_EFFORT_RATE = 0.4            # XP par « répétition équivalente » (rép. × coefficient)
BW_EFFORT_MAX = 19.0
BW_PROGRESS_MAX = 30.0          # bonus maximal de progression par exercice
BW_BONUS_SCALE = 0.3            # première référence / maintien : 15 et 10 × ce facteur
BW_MIN_EQUIV = {"reps": 10, "s": 30}   # volume minimal pour compter (rép. ou s équivalentes)
JUMP_PARTIAL_RATE = 0.5         # une série « saut improbable » compte à moitié…
JUMP_CONFIRM_SESSIONS = 3       # …jusqu'à être retrouvée sur 3 séances distinctes
JUMP_CONFIRM_DAYS = 28
# Évaluation de départ : niveau moyen des 4 familles (indice de variante) → rang de départ.
ASSESS_START_RANK = [("D", 2.0), ("C", 3.5), ("B", 5.0)]

# Vérification des saisies.
# - vérifié  : une preuve accompagne la saisie (trace GPX, focus surveillé par l'app,
#              données du téléphone) ou l'activité se prouve d'elle-même (quiz, IA).
# - plausible : saisie sans preuve, mais cohérente avec l'historique vérifié du joueur
#              et à une fréquence réaliste.
# - déclaré  : saisie sans preuve et hors de ces limites.
VERIFICATION_RATES = {"vérifié": 1.0, "plausible": 0.6, "déclaré": 0.2}
VERIFICATION_EXEMPT = {"Force", "Endurance", "Agilité"}   # visibles dans la vraie vie
SELF_VERIFIED = {"reading", "homework"}   # le quiz corrigé par l'application est la preuve
# (les exercices de langue saisis à la main sont déclaratifs : le parcours Anglais / Espagnol fait foi)
# Le sommeil saisi à la main compte pleinement s'il est cohérent (pas d'achat de montre).
PLAUSIBLE_RATE_OVERRIDES = {"Vitalité": 1.0}
# XP non vérifiée maximale par semaine et par stat : empêche de monter en accumulant
# des saisies sans preuve, même plausibles.
UNVERIFIED_WEEKLY_CAP = 100
UNVERIFIED_CAP_EXEMPT = {"Vitalité"}
# Limites de plausibilité : (plafonds par défaut sans historique vérifié, saisies sans preuve max sur 7 j).
# Un historique vérifié relève chaque plafond à 1,5 × la meilleure valeur vérifiée.
PLAUSIBILITY = {
    "expedition": ({"distance_km": 15, "elevation_m": 800}, 2),
    "focus": ({"minutes": 120}, 7),
    "meditation": ({"minutes": 30}, 7),
    "discomfort": ({"seconds": 300}, 7),
    "sleep": ({"hours": 10, "nap_minutes": 120}, 7),
}

# Fenêtre de référence pour mesurer la progression personnelle.
BASELINE_DAYS = 56

# Niveau global (1 à 100) calculé à partir de l'XP totale des 7 stats.
LEVEL_MAX = 100
# Niveau 100 ≈ toutes les stats à deux fois le seuil S : un objectif de toute une vie.
LEVEL_XP_REF = 14 * RANK_THRESHOLDS["S"]
LEVEL_EXPONENT = 0.55

# Classes (écran de création du canevas) : coefficient de chaque stat dans le rang global.
# Stats non citées : 1. La classe se change une fois par saison (3 mois), l'XP est gardée.
CLASSES = {
    "Combattant martial": {"Force": 2.0, "Agilité": 1.5},
    "Érudit": {"Intelligence": 2.0, "Mental": 1.5},
    "Explorateur": {"Expédition": 2.0, "Endurance": 1.5, "Vitalité": 1.5},
    "Gardien": {"Vitalité": 2.0, "Mental": 1.5, "Endurance": 1.5},
    "Messager": {"Endurance": 2.0, "Agilité": 1.5, "Expédition": 1.5},
    "Équilibré": {},
}

# Saisie après coup : une activité oubliée peut être saisie jusqu'à 2 jours en arrière
# (7 jours pour une trace GPX, qui porte sa propre date).
BACKDATE_DAYS = 2
BACKDATE_DAYS_GPX = 7
# Lecture : sans quiz, une séance est en attente ; elle est créditée si le quiz du livre est
# réussi dans les 90 jours. Quiz de livre : 6 questions tirées au hasard, 4 bonnes pour valider,
# 45 s par question, une tentative par livre et par jour.
BOOK_PENDING_DAYS = 90
BOOK_QUIZ_QUESTIONS = 6
BOOK_QUIZ_PASS = 4
BOOK_QUIZ_SECONDS = 45
BOOK_RETRY_DAYS = 7          # quiz de livre raté : on le repasse 7 jours plus tard (sans avoir vu les réponses)

# --- Quiz de matière (devoirs) : même principe que les livres, une tentative par jour et par quiz.
SUBJECT_LEVELS = {"collège": 1.0, "lycée": 1.5, "bac+2": 2.0, "bac+3": 2.5, "bac+5": 3.0}   # coefficient de difficulté
LEVEL_LABELS = {"collège": "Collège", "lycée": "Lycée", "bac+2": "Bac +1/+2", "bac+3": "Bac +3 (licence)",
                "bac+5": "Bac +4/+5 (master)"}
# Parcours par matière : un palier se débloque en réussissant (4 bonnes sur 6) le palier précédent.
SUBJECT_CHAINS = {"maths": "Mathématiques", "francais": "Français et lettres", "histoire": "Histoire",
                  "geo": "Géographie", "pc": "Physique-chimie", "svt": "SVT et biologie", "anglais": "Anglais",
                  "philo": "Philosophie", "eco": "Économie", "droit": "Droit", "culture": "Culture générale",
                  "espagnol": "Espagnol", "info": "Informatique"}
# Matières annexes (filières pro) : à ajouter soi-même, XP d'Intelligence normale.
ANNEX_SUBJECTS = {"info"}
# Filières : elles cochent des matières, que l'utilisateur peut ensuite ajouter ou retirer.
FILIERES = {
    "Scientifique": ["maths", "pc", "svt", "anglais", "culture"],
    "Littéraire": ["francais", "philo", "histoire", "anglais", "espagnol", "culture"],
    "Économique et sociale": ["eco", "maths", "histoire", "geo", "anglais", "culture"],
    "Droit et sciences politiques": ["droit", "histoire", "eco", "philo", "anglais", "culture"],
    "Langues": ["anglais", "espagnol", "francais", "culture"],
    "Générale (collège, lycée)": ["maths", "francais", "histoire", "geo", "pc", "svt", "anglais", "culture"],
    "Libre": [],
}
# Placement par matière : PLACEMENT_PER_LEVEL questions par palier ; un palier est acquis avec
# PLACEMENT_LEVEL_OK bonnes réponses, si les paliers du dessous ont au moins PLACEMENT_BELOW_OK.
PLACEMENT_PER_LEVEL = 5
PLACEMENT_LEVEL_OK = 4
PLACEMENT_BELOW_OK = 3
# Examen de passage : EXAM_QUESTIONS questions, EXAM_PASS bonnes pour monter de palier.
# Il s'ouvre quand les EXAM_RECENT derniers quiz du palier ont une moyenne d'au moins EXAM_AVERAGE.
EXAM_QUESTIONS = 30
EXAM_PASS = 24
EXAM_SECONDS = 40
EXAM_RECENT = 5
EXAM_AVERAGE = 0.7
EXAM_RETRY_DAYS = 7

# --- Profil du héros : âge minimum (16 ans, avec accord parental avant 18 ans).
MIN_AGE, MAX_AGE = 16, 100
SEXES = ("femme", "homme")                            # non précisé : valeurs de référence

# --- Inactivité : au-delà de DORMANT_DAYS sans activité sur une stat, elle passe « en sommeil »
# (rang affiché d'un cran plus bas, l'XP est gardée). Test de retour : WAKE_SESSIONS séances
# (jours différents) en WAKE_DAYS jours. Les périodes de convalescence ne comptent pas.
DORMANT_DAYS = 90
WAKE_SESSIONS = 3
WAKE_DAYS = 14

# --- Minuteur de concentration intégré (preuve « app » pour le Mental).
FOCUS_MIN_MINUTES = 5
FOCUS_MAX_MINUTES = 300

# --- Saisons de 3 mois : objectifs de saison, sceau obtenu à partir de SEASON_SEAL objectifs.
SEASON_SEAL = 5

# Repos : au plus 2 jours de repos neutres par période de 7 jours ; au-delà, la journée
# compte normalement pour la Discipline (sinon déclarer « repos » effacerait chaque échec).
REST_NEUTRAL_PER_WEEK = 2

# Quête du jour : nombre de quêtes générées par jour (seules elles comptent pour la Discipline).
DAILY_QUESTS = 3
# Sauvegarde : nombre de copies quotidiennes conservées.
BACKUPS_KEPT = 14

# Discipline : fenêtre et poids de la récence.
DISCIPLINE_DAYS = 28
DISCIPLINE_DECAY = 0.97
