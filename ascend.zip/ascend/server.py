"""Application locale : un petit serveur HTTP (bibliothèque standard uniquement) qui sert
les écrans HTML et expose le moteur en JSON. Il n'écoute que sur 127.0.0.1 : rien n'est
accessible depuis le réseau, toutes les données restent sur le PC.
"""
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import webbrowser
from datetime import date, time, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import ai as AI
from . import bookquiz as BQ
from . import catalog as K
from . import config as C
from . import gpx as GPX
from . import quests as Q
from . import reports as R
from . import seasons as SZ
from . import health as HL
from . import placement as PL
from . import programs as PG
from . import defis as DF
from . import records as RC
from . import coach as CO
from . import goals as GO
from . import chronicle as CH
from . import lore as LO
from . import places as PCS
from . import cartes as CA
from . import langues as LG
from . import revision as RV
from . import cursus as CU
from . import titles as TT
from . import trials as T
from .engine import ACTIVITIES, mastered, suggest
from .ranks import progress_to_next
from .store import Store

WEB = Path(__file__).parent / "web"


def default_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    return Path(base) / "ASCEND" if base else Path.home() / ".ascend"


KIND_LABELS = {
    "bodyweight": "Exercice", "skill": "Exercice", "strength": "Salle", "endurance": "Endurance",
    "reading": "Lecture", "language": "Langue", "english": "Langue", "homework": "Devoir",
    "focus": "Concentration", "meditation": "Méditation", "journal": "Journal", "discomfort": "Inconfort",
    "sleep": "Sommeil", "expedition": "Expédition", "mobility": "Mobilité", "wellbeing": "Bien-être",
    "documentary": "Documentaire", "writing": "Écriture", "cards": "Cartes de révision",
}


def describe(ev: dict) -> str:
    """Libellé court d'une saisie pour le journal."""
    if ev["type"] == "rest":
        return "Jour de repos"
    if ev["type"] == "assess":
        return "Évaluation de départ · " + ", ".join(ev.get("results", {}))
    if ev["type"] == "cooper":
        return f"Test de Cooper · {ev.get('meters', 0):.0f} m"
    if ev["type"] == "class":
        return f"Changement de classe · {ev.get('class', '')}"
    if ev["type"] == "profile":
        return "Profil mis à jour"
    if ev["type"] == "placement":
        return f"Évaluation de départ · {ev.get('stat', '')} ({ev.get('detail', '')})"
    if ev["type"] == "subject_level":
        how = {"placement": "test de placement", "exam": "examen réussi"}.get(ev.get("source"), ev.get("source", ""))
        return f"Palier · {C.SUBJECT_CHAINS.get(ev.get('chain'), '?')} : {C.LEVEL_LABELS.get(ev.get('level'), '?')} ({how})"
    if ev["type"] == "subject_exam":
        return (f"Examen · {C.SUBJECT_CHAINS.get(ev.get('chain'), '?')} {C.LEVEL_LABELS.get(ev.get('level'), '?')} : "
                f"{ev.get('good')}/{ev.get('total')} " + ("réussi" if ev.get("passed") else "raté"))
    if ev["type"] == "defi":
        name = DF.PAR_ID[ev["id"]].name if ev.get("id") in DF.PAR_ID else "?"
        return f"Défi {'commencé' if ev.get('action') == 'start' else 'abandonné'} · {name}"
    if ev["type"] == "defi_check":
        return f"Défi validé pour la journée · {DF.PAR_ID[ev['id']].name if ev.get('id') in DF.PAR_ID else '?'}"
    if ev["type"] == "habit":
        return f"Habitude {'ajoutée' if ev.get('action') == 'add' else 'supprimée'}" + (f" · {ev['name']}" if ev.get("name") else "")
    if ev["type"] == "habit_check":
        return "Habitude cochée" if ev.get("done", True) else "Habitude décochée"
    if ev["type"] == "langlevel":
        return (f"Test de langue · {str(ev.get('lang', '')).capitalize()} {ev.get('level', '')} : {ev.get('good')}/{ev.get('total')} "
                + ("validé" if ev.get("passed") else "abandonné" if ev.get("abandoned") else "raté"))
    if ev["type"] == "card":
        what = {"add": "Carte ajoutée", "del": "Carte supprimée", "deldeck": "Paquet supprimé"}.get(ev.get("action"), "Carte")
        return what + (f" · {ev['deck']}" if ev.get("deck") else "")
    if ev["type"] == "review":
        return "Carte révisée · " + ("sue" if ev.get("ok") else "pas sue")
    if ev["type"] == "goal":
        what = {"add": "fixé", "del": "supprimé", "done": "atteint"}.get(ev.get("action"), "")
        return f"Objectif {what}" + (f" · {ev['title']}" if ev.get("title") else "")
    if ev["type"] == "note":
        return "Journal personnel" + (" · gratitude" if ev.get("gratitude") else "")
    if ev["type"] == "program":
        return f"Programme · {ev.get('stat', '')} : {ev.get('name') or 'arrêté'}"
    if ev["type"] == "convalescence":
        what = "Début" if ev.get("action") == "start" else "Fin"
        return f"{what} de convalescence · {', '.join(ev.get('stats', []))}"
    if ev["type"] == "bookquiz":
        verdict = "réussi" if ev.get("passed") else "raté"
        return f"Quiz de lecture {verdict} · {ev.get('title', '')} ({ev.get('good', 0)}/{ev.get('total', 0)})"
    k, d = ev.get("kind"), ev.get("data", {})
    label = KIND_LABELS.get(k, k)
    try:
        if k in ("bodyweight", "skill"):
            return f"{K.variant(d['family'], d['variant']).name} · {'/'.join(str(int(x)) for x in d.get('sets', []))}"
        if k == "strength":
            return f"{d.get('exercise', '').capitalize()} · " + ", ".join(f"{w:g}×{r}" for w, r in d.get("sets", []))
        if k == "endurance":
            return f"{d.get('sport', 'course').capitalize()} · {d.get('distance_km', 0):g} km en {d.get('minutes', 0):g} min"
        if k == "reading":
            book = BQ.bank().get(d.get("work_id") or "")
            if book:
                return f"{label} · {book['title']} · {d.get('minutes', 0):g} min"
            quiz = "sans quiz" if d.get("quiz") is None else f"quiz {d['quiz']:.0%}"
            return f"{label} · {d.get('content', 'livre')} {d.get('minutes', 0):g} min, {quiz}"
        if k == "homework" and d.get("subject"):
            return f"Quiz de devoir · {d['subject']} · {d.get('ai_score', 0):.0%}"
        if k == "focus" and ev.get("proof") == "app":
            return f"Minuteur · {d.get('minutes', 0):g} min, {d.get('interruptions', 0)} interruption(s)"
        if k in ("focus", "meditation"):
            return f"{label} · {d.get('minutes', 0):g} min"
        if k == "sleep":
            return f"{label} · coucher {d.get('bedtime', '?')}, {d.get('hours', 0):g} h"
        if k == "cards":
            return f"{label} · {d.get('n', 0)} cartes, {d.get('ok', 0)} sues"
        if k == "documentary":
            return f"{label} · {d.get('minutes', 0):.0f} min" + (f" · {d['title']}" if d.get("title") else "")
        if k == "writing":
            return f"{label} · {d.get('words', 0)} mots" + (f" · {d['title']}" if d.get("title") else "")
        if k == "wellbeing":
            parts = []
            if d.get("water_l"):
                parts.append(f"{d['water_l']:g} L d'eau".replace(".", ","))
            if d.get("fruits_veg"):
                parts.append(f"{d['fruits_veg']:g} fruits/légumes")
            if d.get("steps"):
                parts.append(f"{d['steps']:,} pas".replace(",", " "))
            if d.get("mood"):
                parts.append("humeur " + "★" * int(d["mood"]))
            return f"{label} · " + (", ".join(parts) or "bilan")
        if k == "expedition":
            return f"{label} · {d.get('distance_km', 0):g} km, {d.get('elevation_m', 0):g} m D+, {d.get('cotation', 'T2')}"
    except (KeyError, TypeError, ValueError):
        pass
    return label


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


class App:
    """État partagé du serveur : la base et le héros actif."""

    def __init__(self, db_path: Path, today=date.today, test_mode: bool = False, backup_dir: Path | None = None):
        self.store = Store(db_path)
        self.store.db.close()                       # une connexion par requête (serveur multi-fil)
        self.db_path = db_path
        self.backup_dir = Path(backup_dir) if backup_dir else Path(db_path).parent / "sauvegardes"
        self.quizzes: dict[str, dict] = {}            # quiz en cours (les réponses ne quittent pas le serveur)
        self.quiz_backend = AI.generate_quiz          # remplaçable dans les tests (IA simulée)
        self.today = today
        self.test_mode = test_mode                  # phase de test : changements de classe illimités
        self.lock = threading.Lock()
        import time as _time
        self.clock = _time.time                     # horloge du minuteur (remplaçable dans les tests)

    def _store(self) -> Store:
        return Store(self.db_path)

    def hero_id(self, s: Store) -> int | None:
        row = s.db.execute("SELECT id FROM hero ORDER BY id LIMIT 1").fetchone()
        return row["id"] if row else None

    # ------------------------------------------------------------------ lectures
    def state(self) -> dict:
        s = self._store()
        try:
            hid = self.hero_id(s)
            if hid is None:
                return {"hero": None, "test_mode": self.test_mode}
            today = self.today()
            with self.lock:                          # deux écrans ouverts en même temps : une seule génération
                quests = s.daily_quests(hid, today)
            hero = s.hero(hid, until=today)
            row = s.db.execute("SELECT * FROM hero WHERE id=?", (hid,)).fetchone()
            stats = []
            for name in C.STATS:
                raw, frac, left = progress_to_next(hero.stat_xp[name])
                shown = hero.rank_of(name)
                stats.append({"name": name, "xp": round(hero.stat_xp[name]), "rank": shown,
                              "frac": round(frac, 3) if shown == raw else 1.0, "left": round(left),
                              "trial_needed": (T.blocker(hero, name, raw) or {}).get("rank"), "need": (T.blocker(hero, name, raw) or {}).get("text"),
                              "dormant": hero.is_dormant(name, today), "convalescence": name in hero.convalescence})
            return {
                "today": today.isoformat(),
                "test_mode": self.test_mode,
                "integrity": self._integrity(s, today),
                "interests": PG.interests(s, hid),
                "hero": {"name": row["name"], "bodyweight": hero.bodyweight, "level": hero.level,
                         "rank": hero.rank, "total_xp": round(hero.total_xp), "assessed": sorted(hero.assessed),
                         "hero_class": hero.hero_class},
                "stats": stats,
                "discipline": {"value": hero.discipline.value(today), "streak": hero.discipline.streak(today)},
                "quests": [{"id": r["id"], "stat": r["stat"], "kind": r["kind"], "title": r["title"],
                            "status": r["status"], "target": json.loads(r["target"]),
                            "completed_by": r["completed_by"],
                            "reasons": Q.valid_reasons(Store._quest(r))} for r in quests],
                "rested": bool(s.db.execute("SELECT 1 FROM events WHERE hero_id=? AND day=? AND type='rest'",
                                            (hid, today.isoformat())).fetchone()),
            }
        finally:
            s.close()

    @staticmethod
    def _integrity(s: Store, today: date) -> dict:
        """Détection de triche locale : journal retouché hors de l'application, date du PC qui recule."""
        last = s.get_meta("last_seen_day")
        if last and today < date.fromisoformat(last) - timedelta(days=1) and not s.get_meta("clock_back"):
            s.set_meta("clock_back", json.dumps({"seen": last, "then": today.isoformat()}))
        if not last or today.isoformat() > last:
            s.set_meta("last_seen_day", today.isoformat())
        j = s.integrity()
        clock = json.loads(s.get_meta("clock_back")) if s.get_meta("clock_back") else None
        return {"ok": j["ok"] and clock is None, "journal_ok": j["ok"], "journal_broken": j["broken"],
                "clock_ok": clock is None, "clock": clock}

    def hero_sheet(self) -> dict:
        """Fiche du héros : classe, coefficients, et épreuves A/S de chaque stat."""
        s = self._store()
        try:
            hid = self._need_hero(s)
            today = self.today()
            hero = s.hero(hid, until=today)
            changed = any(s.season(date.fromisoformat(r["day"])) == s.season(today) for r in
                          s.db.execute("SELECT day FROM events WHERE hero_id=? AND type='class'", (hid,)))
            y, q = s.season(today)
            return {
                "hero_class": hero.hero_class, "rank": hero.rank,
                "classes": [{"name": n, "weights": w} for n, w in C.CLASSES.items()],
                "can_change": self.test_mode or not changed,
                "test_mode": self.test_mode,
                "season": f"Saison {q} de {y}",
                "titles": TT.collection(hero, today),
                "stats": [{"name": st, "rank": hero.rank_of(st), "xp_rank": progress_to_next(hero.stat_xp[st])[0],
                           "xp": round(hero.stat_xp[st]), "weight": C.CLASSES[hero.hero_class].get(st, 1.0),
                           "trials": T.status(hero, today, st)} for st in C.STATS],
            }
        finally:
            s.close()

    def change_class(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                try:
                    return {"message": s.change_class(self._need_hero(s), self.today(), str(body.get("hero_class", "")),
                                                      test_mode=self.test_mode)}
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()

    def bilan(self, day_str: str | None) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            try:
                day = date.fromisoformat(day_str) if day_str else self.today()
            except ValueError:
                raise ApiError(400, "Date attendue au format AAAA-MM-JJ")
            monday = R.monday_of(min(day, self.today()))
            report = R.week_report(s, hid, monday, self.today())
            report["is_current"] = monday == R.monday_of(self.today())
            return report
        finally:
            s.close()

    def quest_history(self, days_str: str | None) -> dict:
        s = self._store()
        try:
            try:
                days = max(7, min(int(days_str or 28), 365))
            except ValueError:
                raise ApiError(400, "Nombre de jours invalide")
            return R.quest_history(s, self._need_hero(s), self.today(), days)
        finally:
            s.close()

    # Activités à saisir pour chaque stat (types de saisie de l'écran Saisie rapide).
    REGION_KINDS = {
        "Force": [("bodyweight", "Exercice au poids du corps"), ("strength", "Séance en salle")],
        "Agilité": [("bodyweight", "Exercice d'agilité")],
        "Endurance": [("endurance", "Course, marche, vélo, natation")],
        "Vitalité": [("sleep", "Nuit de sommeil"), ("wellbeing", "Bilan bien-être (eau, pas, humeur)")],
        "Intelligence": [("reading", "Lecture"), ("language", "Langue"), ("homework", "Devoir"), ("documentary", "Documentaire")],
        "Mental": [("focus", "Concentration"), ("meditation", "Méditation"), ("journal", "Journal"),
                   ("discomfort", "Inconfort")],
        "Expédition": [("expedition", "Sortie")],
    }

    def region(self, stat: str) -> dict:
        """Tout ce qu'il faut pour tester une stat : résumé, références, coefficients,
        épreuves et dernières saisies avec leur XP."""
        if stat not in C.STATS:
            raise ApiError(400, f"Stat inconnue : {stat}")
        s = self._store()
        try:
            hid = self._need_hero(s)
            today = self.today()
            captured: dict = {}
            hero = s.hero(hid, until=today, capture=captured)
            raw, frac, left = progress_to_next(hero.stat_xp[stat])
            shown = hero.rank_of(stat)
            recent = []
            for ev in s.db.execute("SELECT * FROM events WHERE hero_id=? AND type='activity' ORDER BY day DESC, id DESC",
                                   (hid,)).fetchall():
                got = captured.get(ev["id"])
                if getattr(got, "stat", None) == stat:
                    item = {"id": ev["id"], "type": "activity", "day": ev["day"], **json.loads(ev["payload"])}
                    recent.append({"id": ev["id"], "day": ev["day"], "label": describe(item),
                                   "granted": round(got.granted, 1), "raw": round(got.raw, 1), "notes": got.notes})
                if len(recent) >= 10:
                    break
            return {
                "stat": stat, "xp": round(hero.stat_xp[stat]), "rank": shown, "xp_rank": raw,
                "frac": round(frac, 3), "left": round(left),
                "trial_needed": (T.blocker(hero, stat, raw) or {}).get("rank"), "need": (T.blocker(hero, stat, raw) or {}).get("text"),
                "weight": C.CLASSES[hero.hero_class].get(stat, 1.0), "hero_class": hero.hero_class,
                "kinds": [{"kind": k, "label": l} for k, l in self.REGION_KINDS[stat]],
                "sections": self._region_sections(hero, stat, today),
                "trials": T.status(hero, today, stat),
                "recent": recent,
                "has_ladders": stat in ("Force", "Agilité"),
            }
        finally:
            s.close()

    @staticmethod
    def _region_sections(hero, stat: str, today: date) -> list[dict]:
        """Références personnelles et coefficients propres à chaque stat."""
        def best(key):
            vals = [v for d, v in hero.refs.get(key, []) if 0 <= (today - d).days <= C.BASELINE_DAYS]
            return max(vals) if vals else None

        def coefs(title, table):
            return {"title": title, "rows": [[k.capitalize() if k[0].islower() else k, f"×{str(v).replace('.', ',')}"]
                                             for k, v in table.items()]}
        if stat == "Endurance":
            rows = []
            for sport, (coef, min_km, min_kmh, max_kmh, (b1, b2)) in C.ENDURANCE_SPORTS.items():
                for band, label in (("court", f"< {b1} km"), ("moyen", f"{b1}–{b2} km"), ("long", f"≥ {b2} km")):
                    v = best(f"vit:{sport}:{band}")
                    if v:
                        rows.append([f"{sport.capitalize()} {label}", f"{v:.1f} km/h"])
            cooper = best("vit:course:cooper") or next((v for d, v in hero.refs.get("vit:course:cooper", [])), None)
            sections = [{"title": "Tes meilleures allures (8 dernières semaines)",
                         "rows": rows or [["Aucune sortie enregistrée", "—"]]},
                        {"title": "Test de Cooper", "rows": [["Allure du test", f"{cooper:.1f} km/h" if cooper else "Pas encore fait"]]},
                        {"title": "Intensité par sport", "rows": [[k.capitalize(), f"×{str(v[0]).replace('.', ',')}"]
                                                                  for k, v in C.ENDURANCE_SPORTS.items()]}]
            return sections
        if stat == "Vitalité":
            last = sorted(hero.sleep_scores, key=lambda x: x[0])[-7:]
            good = sum(1 for d, sc in hero.sleep_scores if 0 <= (today - d).days < 120 and sc >= 75)
            return [{"title": "Tes dernières nuits (note /100)",
                     "rows": [[d.strftime("%d/%m"), f"{sc:.0f}"] for d, sc in reversed(last)] or [["Aucune nuit", "—"]]},
                    {"title": "Régularité", "rows": [["Bonnes nuits (≥ 75) sur 120 jours", str(good)]]},
                    {"title": "Comment c'est noté", "rows": [["Durée sur 24 h, siestes comprises", "50 pts entre 7 et 9 h"],
                                                              ["Régularité du coucher (par type de poste)", "jusqu'à 50 pts"],
                                                              ["Mode jeune parent", "seule la durée compte"]]}]
        if stat == "Intelligence":
            works = sorted(hero.works.items(), key=lambda x: x[1], reverse=True)
            return [{"title": f"Œuvres validées par quiz ({len(works)})",
                     "rows": [[t.capitalize(), d.strftime("%d/%m/%Y")] for t, d in works[:8]] or [["Aucune pour l'instant", "—"]]},
                    coefs("Type de contenu", C.READING_CONTENT),
                    coefs("Niveau de langue", C.LANGUAGE_LEVELS)]
        if stat == "Mental":
            med = sum(1 for d in hero.meditation_days if 0 <= (today - d).days < 120)
            return [{"title": "Régularité", "rows": [["Jours de méditation (≥ 10 min) sur 120", str(med)]]},
                    coefs("Style de méditation", C.MEDITATION_STYLES),
                    {"title": "Autres activités", "rows": [["Journal jugé réfléchi", f"+{C.JOURNAL_XP:.0f} XP"],
                                                           ["Inconfort (douche froide…)", f"jusqu'à {C.DISCOMFORT_MAX_XP:.0f} XP"]]}]
        if stat == "Expédition":
            return [{"title": "Exploration", "rows": [["Lieux découverts", str(len(hero.seen_places))]]},
                    coefs("Cotation", C.EXPEDITION_COTATION),
                    {"title": "Preuve", "rows": [["T4 à T6 sans trace GPX", "comptée comme déclarée (20 %)"]]}]
        return []

    def catalog(self, stat: str) -> dict:
        if stat not in ("Force", "Agilité"):
            raise ApiError(400, "Catalogue disponible pour Force et Agilité")
        s = self._store()
        try:
            hid = self.hero_id(s)
            hero = s.hero(hid, until=self.today()) if hid else None
            fams = []
            for fam in K.families_of(stat):
                info = K.FAMILIES[fam]
                pending = bool(hero and hero.jump_claims.get(f"pdc:{fam}"))
                worked = [v.id for v in info["variants"] if hero and hero.best_sets.get((fam, v.id), 0) > 0]
                current = worked[-1] if worked else None
                if current and not mastered(hero, fam, current):
                    i = K.index_of(fam, current) + 1           # celle d'après, une fois la variante en cours maîtrisée
                    sug = info["variants"][i] if i < len(info["variants"]) else None
                else:
                    sug = suggest(hero, fam) if hero else None
                variants = []
                for v in info["variants"]:
                    best = hero.best_sets.get((fam, v.id), 0) if hero else 0
                    state = ("maîtrisée" if hero and mastered(hero, fam, v.id) else "en cours" if v.id == current
                             else "suggérée" if sug and v.id == sug.id else "ouverte")
                    variants.append({"id": v.id, "name": v.name, "coef": v.coef, "mastery": v.mastery,
                                     "best": best, "state": state})
                fams.append({"id": fam, "unit": info["unit"], "variants": variants, "pending_jump": pending})
            return {"stat": stat, "families": fams, "assessed": bool(hero and stat in hero.assessed)}
        finally:
            s.close()

    # ------------------------------------------------------------------ écritures
    def create_hero(self, body: dict) -> dict:
        name = str(body.get("name", "")).strip()[:40]
        try:
            bw = float(body.get("bodyweight", 0))
        except (TypeError, ValueError):
            bw = 0
        if not name or not 25 <= bw <= 300:
            raise ApiError(400, "Indique un nom et un poids de corps entre 25 et 300 kg")
        hero_class = body.get("hero_class") or "Équilibré"
        if hero_class not in C.CLASSES:
            raise ApiError(400, f"Classe inconnue : {hero_class}")
        body = {**body, "hero_class": hero_class}
        with self.lock:
            s = self._store()
            try:
                if self.hero_id(s) is not None:
                    raise ApiError(409, "Un héros existe déjà")
                hid = s.create_hero(name, bw, body.get("hero_class"))
                extra = {k: body[k] for k in ("birth_year", "sex") if body.get(k) not in (None, "")}
                if extra:
                    try:
                        s.update_profile(hid, self.today(), **extra)
                    except ValueError as e:
                        s.db.execute("DELETE FROM hero WHERE id=?", (hid,))
                        s.db.commit()
                        raise ApiError(400, str(e))
                return {"id": hid}
            finally:
                s.close()

    # ------------------------------------------------------------------ quiz de lecture par IA
    QUIZ_SECONDS_PER_QUESTION = 45      # chronométré : pas le temps de chercher les réponses

    def quiz_status(self) -> dict:
        return AI.status(Path(self.db_path).parent)

    def quiz_new(self, body: dict) -> dict:
        import secrets
        import time as _t
        if body.get("consent") is not True:
            raise ApiError(400, "Accepte l'envoi du titre à Claude (Anthropic) pour générer le quiz")
        title = str(body.get("title", "")).strip()[:120]
        if len(title) < 2:
            raise ApiError(400, "Indique le titre de l'œuvre")
        author, part = str(body.get("author", "")).strip()[:80], str(body.get("part", "")).strip()[:120]
        meta = {"minutes": body.get("minutes"), "content": body.get("content", "livre"),
                "finished": bool(body.get("finished")), "day": body.get("day")}
        from .engine import validate
        try:
            validate("reading", {"minutes": meta["minutes"], "quiz": 0.0, "content": meta["content"]})
        except ValueError as e:
            raise ApiError(400, str(e))
        if meta["content"] not in C.READING_CONTENT:
            raise ApiError(400, "Type de contenu inconnu")
        try:
            quiz = self.quiz_backend(title, author, part, Path(self.db_path).parent)
        except AI.AIUnavailable as e:
            raise ApiError(503, str(e))
        except ValueError as e:
            raise ApiError(502, str(e))
        if not quiz["known"]:
            return {"known": False, "reason": quiz["reason"]}
        qid = secrets.token_urlsafe(9)
        limit = self.QUIZ_SECONDS_PER_QUESTION * len(quiz["questions"])
        with self.lock:
            self.quizzes = {k: v for k, v in self.quizzes.items() if _t.time() - v["started"] < 3600}
            self.quizzes[qid] = {"quiz": quiz, "started": _t.time(), "limit": limit, "title": title, **meta}
        return {"known": True, "id": qid, "time_limit_s": limit, "title": title,
                "questions": [{"question": q["question"], "choices": q["choices"]} for q in quiz["questions"]]}

    def quiz_answer(self, qid: str, body: dict) -> dict:
        import time as _t
        with self.lock:
            q = self.quizzes.pop(qid, None)          # une seule tentative par quiz
        if q is None:
            raise ApiError(404, "Quiz introuvable ou déjà corrigé")
        answers = body.get("answers")
        questions = q["quiz"]["questions"]
        if not isinstance(answers, list) or len(answers) != len(questions):
            raise ApiError(400, "Réponds à toutes les questions")
        good = sum(1 for a, item in zip(answers, questions) if a == item["answer"])
        score = good / len(questions)
        late = _t.time() - q["started"] > q["limit"] + 10
        data = {"minutes": q["minutes"], "quiz": None if late else round(score, 3), "content": q["content"]}
        if q["finished"] and not late and score >= 0.6:
            data["oeuvre"] = q["title"]
        body2 = {"kind": "reading", "data": data, **({"day": q["day"]} if q.get("day") else {})}
        result = self.log(body2, quiz_checked=True)
        result.update(score=score, good=good, total=len(questions), late=late,
                      correction=[{"question": it["question"], "answer": it["choices"][it["answer"]],
                                   "yours": it["choices"][a] if isinstance(a, int) and 0 <= a < 4 else None}
                                  for a, it in zip(answers, questions)])
        if late:
            result["notes"].insert(0, "Temps dépassé : le quiz ne valide pas la lecture")
        return result

    # ------------------------------------------------------------------ quiz de livres (banque ASCEND)
    def books(self, q: str | None) -> dict:
        return {"items": BQ.search(q) if q else BQ.catalog(), "total": len(BQ.bank())}

    def book_quiz_new(self, body: dict) -> dict:
        import secrets
        import time as _t
        work = BQ.bank().get(str(body.get("work_id", "")))
        if work is None:
            raise ApiError(404, "Livre absent de la banque de quiz")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                self._resolve_abandoned(s, hid, "book", work["id"])
                last = s.last_book_attempt(hid, work["id"])
                if last and last[0] == self.today():
                    raise ApiError(400, "Tu as déjà passé le quiz de ce livre aujourd'hui")
                if last and not last[1] and (self.today() - last[0]).days < C.BOOK_RETRY_DAYS:
                    again = last[0] + timedelta(days=C.BOOK_RETRY_DAYS)
                    raise ApiError(400, f"Quiz raté le {last[0].strftime('%d/%m')} : tu pourras le repasser le {again.strftime('%d/%m/%Y')}")
                try:
                    questions = BQ.draw(work["id"], s.reported_questions())
                except ValueError as e:
                    raise ApiError(400, str(e))
                slow = HL.quiz_time(T.health_ids(s.hero(hid, until=self.today())))
                self._begin(s, "book", work["id"])
            finally:
                s.close()
            qid = secrets.token_urlsafe(9)
            limit = round(C.BOOK_QUIZ_SECONDS * slow) * len(questions)
            self.quizzes = {k: v for k, v in self.quizzes.items() if _t.time() - v["started"] < 3600}
            self.quizzes[qid] = {"book": work, "questions": questions, "started": _t.time(), "limit": limit}
        return {"id": qid, "time_limit_s": limit, "title": work["title"], "part": work.get("part", ""),
                "pass": C.BOOK_QUIZ_PASS, "questions": [{"id": q["id"], "question": q["q"], "choices": q["choices"]} for q in questions]}

    def book_quiz_answer(self, qid: str, body: dict) -> dict:
        import time as _t
        with self.lock:
            q = self.quizzes.pop(qid, None)
            if q is None or "book" not in q:
                raise ApiError(404, "Quiz introuvable ou déjà corrigé")
            answers = body.get("answers")
            if not isinstance(answers, list) or len(answers) != len(q["questions"]):
                raise ApiError(400, "Réponds à toutes les questions")
            late = _t.time() - q["started"] > q["limit"] + 10
            good = 0 if late else sum(1 for a, it in zip(answers, q["questions"]) if a == it["answer"])
            s = self._store()
            try:
                hid = self._need_hero(s)
                day = self.today()
                before = s.hero(hid, until=day)
                self._finish(s, "book", q["book"]["id"])
                s.book_quiz(hid, day, q["book"], good, len(q["questions"]), [it["id"] for it in q["questions"]])
                after = s.hero(hid, until=day)
            finally:
                s.close()
        passed = good >= C.BOOK_QUIZ_PASS
        gained = after.stat_xp["Intelligence"] - before.stat_xp["Intelligence"]
        notes = ["Temps dépassé : le quiz n'est pas validé"] if late else []
        notes.append(f"{good} / {len(q['questions'])} bonnes réponses : " +
                     ("livre validé !" if passed else f"il en faut {C.BOOK_QUIZ_PASS} pour valider. Relis le livre : tu pourras repasser le quiz dans {C.BOOK_RETRY_DAYS} jours."))
        if passed:
            notes.append(f"Tes séances de lecture en attente sur ce livre sont créditées : +{gained:.0f} XP d'Intelligence"
                         if gained > 0 else "Aucune séance en attente sur ce livre : pense à saisir tes lectures avec le livre choisi")
        return {"passed": passed, "good": good, "total": len(q["questions"]), "late": late, "granted": round(gained, 1),
                "notes": notes, "celebrations": TT.celebrations(before, after, day),
                "correction": self._correction(answers, q["questions"], reveal=passed)}

    # ------------------------------------------------------------------ quiz de matière (devoirs)
    @staticmethod
    def _subject_passes(s: Store, hid: int) -> dict[str, int]:
        """Réussites (4 bonnes sur 6 ou plus) par quiz de matière."""
        out: dict[str, int] = {}
        for ev in s.db.execute("SELECT payload FROM events WHERE hero_id=? AND type='activity'", (hid,)):
            p = json.loads(ev["payload"])
            d = p.get("data") or {}
            if p.get("kind") == "homework" and d.get("quiz_id") and \
                    d.get("ai_score", 0) >= C.BOOK_QUIZ_PASS / C.BOOK_QUIZ_QUESTIONS - 1e-9:
                out[d["quiz_id"]] = out.get(d["quiz_id"], 0) + 1
        return out

    def subjects(self) -> dict:
        s = self._store()
        try:
            hid = self.hero_id(s)
            passed = self._subject_passes(s, hid) if hid else {}
        finally:
            s.close()
        return {"items": BQ.subject_catalog(), "chains": BQ.chains(passed), "levels": C.SUBJECT_LEVELS,
                "labels": C.LEVEL_LABELS}

    def subject_quiz_new(self, body: dict) -> dict:
        import secrets
        import time as _t
        quiz = BQ.subjects().get(str(body.get("quiz_id", "")))
        if quiz is None:
            raise ApiError(404, "Quiz de matière inconnu")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                self._resolve_abandoned(s, hid, "subject", quiz["id"])
                if not self.test_mode:
                    stc = CU.chain_state(s, hid, self.today(), quiz["subject"])
                    if not stc["chosen"]:
                        raise ApiError(400, f"{stc['subject']} ne fait pas partie de tes matières : ajoute-la d'abord")
                    if not stc["current"]:
                        raise ApiError(400, f"Passe d'abord le test de placement en {stc['subject']}")
                    if stc["current"]["id"] != quiz["id"]:
                        lvl = next(l for l in stc["levels"] if l["id"] == quiz["id"])
                        raise ApiError(400, ("Palier dépassé" if lvl["state"] == "dépassé" else "Palier verrouillé") +
                                       f" : en {stc['subject']}, ton palier est {stc['current']['label']}")
                for ev in s.db.execute("SELECT payload FROM events WHERE hero_id=? AND day=? AND type='activity'",
                                       (hid, self.today().isoformat())):
                    p = json.loads(ev["payload"])
                    if p.get("kind") == "homework" and (p.get("data") or {}).get("quiz_id") == quiz["id"]:
                        raise ApiError(400, "Tu as déjà passé ce quiz aujourd'hui : réessaie demain")
                try:
                    questions = BQ.draw(quiz["id"], s.reported_questions(), source=BQ.subjects())
                except ValueError as e:
                    raise ApiError(400, str(e))
                slow = HL.quiz_time(T.health_ids(s.hero(hid, until=self.today())))
                self._begin(s, "subject", quiz["id"])
            finally:
                s.close()
            qid = secrets.token_urlsafe(9)
            limit = round(C.BOOK_QUIZ_SECONDS * slow) * len(questions)
            self.quizzes = {k: v for k, v in self.quizzes.items() if _t.time() - v["started"] < 3600}
            self.quizzes[qid] = {"subject": quiz, "questions": questions, "started": _t.time(), "limit": limit}
        return {"id": qid, "time_limit_s": limit, "title": f"{C.SUBJECT_CHAINS[quiz['subject']]} · {C.LEVEL_LABELS[quiz['type']]}", "part": "",
                "pass": C.BOOK_QUIZ_PASS,
                "questions": [{"id": q["id"], "question": q["q"], "choices": q["choices"]} for q in questions]}

    def subject_quiz_answer(self, qid: str, body: dict) -> dict:
        import time as _t
        with self.lock:
            q = self.quizzes.get(qid)
            if q is None or "subject" not in q:
                raise ApiError(404, "Quiz introuvable ou déjà corrigé")
            answers = body.get("answers")
            if not isinstance(answers, list) or len(answers) != len(q["questions"]):
                raise ApiError(400, "Réponds à toutes les questions")
            self.quizzes.pop(qid, None)
            late = _t.time() - q["started"] > q["limit"] + 10
            good = 0 if late else sum(1 for a, it in zip(answers, q["questions"]) if a == it["answer"])
            quiz = q["subject"]
            s = self._store()
            try:
                self._finish(s, "subject", quiz["id"])
                wrong = [it["id"] for a, it in zip(answers, q["questions"]) if late or a != it["answer"]]
                RV.record(s, self._need_hero(s), self.today(), quiz["subject"], wrong, "quiz", hidden=False)
            finally:
                s.close()
            data = {"ai_score": round(good / len(q["questions"]), 3), "difficulty": C.SUBJECT_LEVELS[quiz["type"]],
                    "subject": f"{C.SUBJECT_CHAINS[quiz['subject']]} ({C.LEVEL_LABELS[quiz['type']]})", "quiz_id": quiz["id"]}
        result = self.log({"kind": "homework", "proof": None, "data": data}, quiz_checked=True)
        passed = good >= C.BOOK_QUIZ_PASS
        result["notes"].insert(0, ("Temps dépassé : " if late else "") +
                               f"{good} / {len(q['questions'])} bonnes réponses" + (" : quiz réussi !" if passed else ""))
        result.update(passed=passed, good=good, total=len(q["questions"]), late=late,
                      correction=[{"id": it["id"], "question": it["q"], "answer": it["choices"][it["answer"]],
                                   "yours": it["choices"][a] if isinstance(a, int) and 0 <= a < 4 else None}
                                  for a, it in zip(answers, q["questions"])])
        return result

    # ------------------------------------------------------------------ évaluations de départ (questionnaires, quiz)
    def placement_info(self) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            hero = s.hero(hid, until=self.today())
            return {"stats": [{"stat": st, "assessed": st in hero.assessed, "result": hero.placements.get(st),
                               "rank": hero.rank_of(st), "cap": PL.CAP.get(st, "B"),
                               "kind": "matieres" if st == "Intelligence" else "questionnaire" if st in PL.CAP else "physique",
                               "questions": PL.public(st)} for st in C.STATS],
                    "quiz_questions": PL.INTEL_QUESTIONS, "span_points": PL.SPAN_POINTS}
        finally:
            s.close()

    def placement_submit(self, body: dict) -> dict:
        stat = body.get("stat")
        if stat not in ("Vitalité", "Expédition", "Mental"):
            raise ApiError(400, "Évaluation par questionnaire : Vitalité, Mental ou Expédition")
        answers = body.get("answers")
        try:
            if stat == "Mental":
                score = PL.score_mental(answers, body.get("span"))
                detail = f"mémoire des chiffres : {body.get('span')}"
            else:
                score, detail = PL.score_questionnaire(stat, answers), "questionnaire"
        except ValueError as e:
            raise ApiError(400, str(e))
        with self.lock:
            s = self._store()
            try:
                try:
                    notes = s.placement(self._need_hero(s), self.today(), stat, score, detail,
                                        {"answers": answers, **({"span": body.get("span")} if stat == "Mental" else {})})
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"notes": notes, "score": round(score, 3)}
            finally:
                s.close()

    def placement_quiz_new(self) -> dict:
        import secrets
        import time as _t
        if not self.test_mode:
            raise ApiError(400, "L'évaluation de l'Intelligence se fait matière par matière (écran Quiz → Matières)")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                hero = s.hero(hid, until=self.today())
                if "Intelligence" in hero.assessed:
                    raise ApiError(400, "Évaluation de départ déjà faite pour l'Intelligence")
                questions = PL.draw_intelligence(s.reported_questions())
                slow = HL.quiz_time(T.health_ids(hero))
            finally:
                s.close()
            qid = secrets.token_urlsafe(9)
            limit = round(C.BOOK_QUIZ_SECONDS * slow) * len(questions)
            self.quizzes = {k: v for k, v in self.quizzes.items() if _t.time() - v["started"] < 3600}
            self.quizzes[qid] = {"placement": True, "questions": questions, "started": _t.time(), "limit": limit}
        return {"id": qid, "time_limit_s": limit, "title": "Évaluation de départ · Intelligence", "part": "",
                "pass": 0, "questions": [{"id": q["id"], "question": q["q"], "choices": q["choices"]} for q in questions]}

    def placement_quiz_answer(self, qid: str, body: dict) -> dict:
        import time as _t
        with self.lock:
            q = self.quizzes.get(qid)
            if q is None or "placement" not in q:
                raise ApiError(404, "Quiz introuvable ou déjà corrigé")
            answers = body.get("answers")
            if not isinstance(answers, list) or len(answers) != len(q["questions"]):
                raise ApiError(400, "Réponds à toutes les questions")
            self.quizzes.pop(qid, None)
            late = _t.time() - q["started"] > q["limit"] + 10
            ok = [not late and a == it["answer"] for a, it in zip(answers, q["questions"])]
            gc = sum(1 for o, it in zip(ok, q["questions"]) if o and it["level"] == "collège")
            gl = sum(1 for o, it in zip(ok, q["questions"]) if o and it["level"] == "lycée")
            score = PL.score_intelligence(gc, gl)
            s = self._store()
            try:
                try:
                    notes = s.placement(self._need_hero(s), self.today(), "Intelligence", score,
                                        f"quiz {gc + gl} / {len(ok)}", {"college": gc, "lycee": gl})
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()
        if late:
            notes.insert(0, "Temps dépassé : réponses non comptées")
        return {"passed": True, "good": gc + gl, "total": len(ok), "granted": 0, "late": late, "notes": notes,
                "celebrations": [],
                "correction": self._correction(answers, q["questions"], reveal=passed)}

    # ------------------------------------------------------------------ cursus : matières, placement, examens
    def cursus(self) -> dict:
        s = self._store()
        try:
            return CU.status(s, self._need_hero(s), self.today())
        finally:
            s.close()

    def cursus_choose(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                try:
                    return {"message": CU.set_choice(s, self._need_hero(s), body.get("filiere"), body.get("subjects"))}
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()

    # ---- quiz commencés mais jamais rendus : ils comptent comme ratés (sinon on pourrait lire les
    # questions, abandonner, chercher les réponses et relancer un autre tirage à volonté).
    @staticmethod
    def _pkey(kind: str, item: str) -> str:
        return f"encours:{kind}:{item}"

    def _begin(self, s: Store, kind: str, item: str, **info) -> None:
        s.set_meta(self._pkey(kind, item), json.dumps({"day": self.today().isoformat(), **info}, ensure_ascii=False))

    def _finish(self, s: Store, kind: str, item: str) -> None:
        s.db.execute("DELETE FROM meta WHERE key=?", (self._pkey(kind, item),))
        s.db.commit()

    def _resolve_abandoned(self, s: Store, hid: int, kind: str, item: str) -> None:
        raw = s.get_meta(self._pkey(kind, item))
        if not raw:
            return
        self._finish(s, kind, item)
        info = json.loads(raw)
        d = date.fromisoformat(info["day"])
        if kind == "book" and item in BQ.bank():
            s.book_quiz(hid, d, BQ.bank()[item], 0, C.BOOK_QUIZ_QUESTIONS, [])
        elif kind == "subject" and item in BQ.subjects():
            w = BQ.subjects()[item]
            s.record(hid, d, "homework", ai_score=0.0, difficulty=C.SUBJECT_LEVELS[w["type"]],
                     subject=f"{C.SUBJECT_CHAINS[w['subject']]} ({C.LEVEL_LABELS[w['type']]})", quiz_id=item)
        elif kind == "exam":
            s._event(hid, d, "subject_exam", {"chain": item, "level": info.get("level"), "good": 0,
                                              "total": C.EXAM_QUESTIONS, "passed": False, "abandoned": True})
        elif kind == "lang":
            lang, _, level = item.partition(":")
            s._event(hid, d, "langlevel", {"lang": lang, "level": level, "good": 0, "total": 10, "passed": False,
                                           "abandoned": True})
        elif kind == "placement":
            first = CU.chain_quizzes(item)[0]["type"]
            s._event(hid, d, "subject_level", {"chain": item, "level": first, "source": "placement",
                                               "detail": {"abandon": True}})
            intel = CU.intelligence_score(s, hid)
            if intel and "Intelligence" not in s.hero(hid, until=d).assessed:
                s.placement(hid, d, "Intelligence", intel[0], intel[1])

    def _timed_quiz(self, s: Store, hid: int, key: str, payload: dict, questions: list[dict], per_q: int, title: str) -> dict:
        import secrets
        import time as _t
        slow = HL.quiz_time(T.health_ids(s.hero(hid, until=self.today())))
        qid = secrets.token_urlsafe(9)
        limit = round(per_q * slow) * len(questions)
        self.quizzes = {k: v for k, v in self.quizzes.items() if _t.time() - v["started"] < 3600 * 3}
        self.quizzes[qid] = {key: payload, "questions": questions, "started": _t.time(), "limit": limit}
        return {"id": qid, "time_limit_s": limit, "title": title, "part": "", "pass": payload.get("pass", 0),
                "questions": [{"id": q["id"], "question": q["q"], "choices": q["choices"]} for q in questions]}

    def _take(self, qid: str, key: str, body: dict):
        import time as _t
        q = self.quizzes.get(qid)
        if q is None or key not in q:
            raise ApiError(404, "Quiz introuvable ou déjà corrigé")
        answers = body.get("answers")
        if not isinstance(answers, list) or len(answers) != len(q["questions"]):
            raise ApiError(400, "Réponds à toutes les questions")
        self.quizzes.pop(qid, None)
        late = _t.time() - q["started"] > q["limit"] + 15
        ok = [not late and a == it["answer"] for a, it in zip(answers, q["questions"])]
        corr = self._correction(answers, q["questions"], reveal=False)
        return q, ok, late, corr

    def placement_subject_new(self, body: dict) -> dict:
        chain = body.get("chain")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                if chain in C.SUBJECT_CHAINS:
                    self._resolve_abandoned(s, hid, "placement", chain)
                try:
                    stc = CU.chain_state(s, hid, self.today(), chain)
                except ValueError as e:
                    raise ApiError(400, str(e))
                if not stc["chosen"]:
                    raise ApiError(400, "Ajoute d'abord cette matière à tes matières")
                if stc["placed"]:
                    raise ApiError(400, "Test de placement déjà fait pour cette matière")
                qs = CU.draw_placement(chain, s.reported_questions())
                self._begin(s, "placement", chain)
                return self._timed_quiz(s, hid, "cursus_placement", {"chain": chain}, qs, C.EXAM_SECONDS,
                                        f"Test de placement · {stc['subject']}")
            finally:
                s.close()

    def placement_subject_answer(self, qid: str, body: dict) -> dict:
        with self.lock:
            q, ok, late, corr = self._take(qid, "cursus_placement", body)
            chain = q["cursus_placement"]["chain"]
            per: dict[str, list[int]] = {}
            for o, it in zip(ok, q["questions"]):
                g = per.setdefault(it["level"], [0, 0])
                g[0] += int(o)
                g[1] += 1
            level = CU.placement_result(chain, {k: (v[0], v[1]) for k, v in per.items()})
            s = self._store()
            try:
                hid = self._need_hero(s)
                day = self.today()
                self._finish(s, "placement", chain)
                RV.record(s, hid, day, chain, [it["id"] for o, it in zip(ok, q["questions"]) if not o
                                               and CU.LEVELS.index(it["level"]) <= CU.LEVELS.index(level)],
                          "placement", hidden=True)
                s._event(hid, day, "subject_level", {"chain": chain, "level": level, "source": "placement",
                                                     "detail": {k: v for k, v in per.items()}})
                notes = [f"{C.SUBJECT_CHAINS[chain]} : palier de départ {C.LEVEL_LABELS[level]}"]
                hero = s.hero(hid, until=day)
                intel = CU.intelligence_score(s, hid)
                if intel and "Intelligence" not in hero.assessed:
                    notes += s.placement(hid, day, "Intelligence", intel[0], intel[1])
                elif not intel:
                    notes.append("Passe le test de tes autres matières pour terminer l'évaluation de l'Intelligence")
            finally:
                s.close()
        if late:
            notes.insert(0, "Temps dépassé : réponses non comptées")
        good = sum(ok)
        return {"passed": True, "good": good, "total": len(ok), "granted": 0, "late": late, "notes": notes,
                "level": level, "per_level": {C.LEVEL_LABELS[k]: v for k, v in per.items()}, "correction": corr,
                "celebrations": []}

    def exam_new(self, body: dict) -> dict:
        chain = body.get("chain")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                if chain in C.SUBJECT_CHAINS:
                    self._resolve_abandoned(s, hid, "exam", chain)
                try:
                    stc = CU.chain_state(s, hid, self.today(), chain)
                except ValueError as e:
                    raise ApiError(400, str(e))
                if not stc["current"]:
                    raise ApiError(400, "Passe d'abord le test de placement")
                if not stc["exam"]["available"] and not (self.test_mode and "banque" not in stc["exam"]["reason"]
                                                         and stc["exam"]["next"]):
                    raise ApiError(400, stc["exam"]["reason"])
                try:
                    qs = CU.draw_exam(stc["current"]["id"], s.reported_questions())
                except ValueError as e:
                    raise ApiError(400, str(e))
                self._begin(s, "exam", chain, level=stc["current"]["level"])
                return self._timed_quiz(s, hid, "cursus_exam", {"chain": chain, "quiz_id": stc["current"]["id"],
                                                               "level": stc["current"]["level"], "pass": C.EXAM_PASS},
                                        qs, C.EXAM_SECONDS,
                                        f"Examen de passage · {stc['subject']} · {stc['current']['label']}")
            finally:
                s.close()

    def exam_answer(self, qid: str, body: dict) -> dict:
        with self.lock:
            q, ok, late, corr = self._take(qid, "cursus_exam", body)
        info = q["cursus_exam"]
        good, total = sum(ok), len(ok)
        passed = good >= C.EXAM_PASS
        chain, level = info["chain"], info["level"]
        data = {"ai_score": round(good / total, 3), "difficulty": C.SUBJECT_LEVELS[level],
                "subject": f"{C.SUBJECT_CHAINS[chain]} ({C.LEVEL_LABELS[level]})", "quiz_id": info["quiz_id"], "exam": True}
        result = self.log({"kind": "homework", "proof": None, "data": data}, quiz_checked=True)
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                day = self.today()
                self._finish(s, "exam", chain)
                RV.record(s, hid, day, chain, [it["id"] for o, it in zip(ok, q["questions"]) if not o], "exam",
                          hidden=not passed)
                s._event(hid, day, "subject_exam", {"chain": chain, "level": level, "good": good, "total": total,
                                                    "passed": passed})
                nxt = None
                if passed:
                    qz = CU.chain_quizzes(chain)
                    i = next(k for k, w in enumerate(qz) if w["type"] == level)
                    if i + 1 < len(qz):
                        nxt = qz[i + 1]["type"]
                        s._event(hid, day, "subject_level", {"chain": chain, "level": nxt, "source": "exam"})
            finally:
                s.close()
        msg = (f"{good} / {total} : examen réussi ! Tu passes au palier {C.LEVEL_LABELS[nxt]} en {C.SUBJECT_CHAINS[chain]}"
               if nxt else f"{good} / {total} : examen réussi !" if passed else
               f"{good} / {total} : il en fallait {C.EXAM_PASS}. Tu pourras le repasser dans {C.EXAM_RETRY_DAYS} jours.")
        result["notes"].insert(0, ("Temps dépassé : " if late else "") + msg)
        cel = list(result.get("celebrations") or [])
        if nxt:
            cel.append({"type": "palier", "text": f"Nouveau palier en {C.SUBJECT_CHAINS[chain]} : {C.LEVEL_LABELS[nxt]}"})
        if passed:
            corr = self._correction(body.get("answers"), q["questions"], reveal=True)
        result.update(passed=passed, good=good, total=total, late=late, correction=corr, celebrations=cel, promoted=nxt)
        return result

    # ------------------------------------------------------------------ journal personnel et gratitude
    PROMPTS = ["Qu'est-ce qui t'a donné de l'énergie aujourd'hui ?", "Qu'est-ce qui t'a coûté le plus d'effort, et pourquoi ?",
               "Une chose que tu as apprise aujourd'hui ?", "Qu'est-ce que tu ferais différemment si tu revivais cette journée ?",
               "De quoi es-tu fier, même un peu ?", "Qu'est-ce qui t'inquiète ? Que peux-tu y faire demain ?",
               "Une personne qui a compté aujourd'hui, et ce qu'elle t'a apporté ?", "Où en es-tu de ton objectif principal ?",
               "Qu'est-ce que ton corps t'a dit aujourd'hui (fatigue, douleur, forme) ?", "Un moment où tu as été pleinement présent ?",
               "Qu'est-ce que tu remets à plus tard ? Quel petit pas pour demain ?", "Comment as-tu pris soin de toi aujourd'hui ?",
               "Qu'est-ce qui t'a surpris aujourd'hui ?", "Si ta semaine était un chapitre, quel serait son titre ?"]

    WRITING_PROMPTS = ["Décris un lieu de ton enfance avec les cinq sens.", "Écris une lettre à toi-même dans dix ans.",
                       "Raconte une journée ordinaire comme si c'était une aventure épique.", "Défends une opinion que tu ne partages pas.",
                       "Invente le début d'une histoire qui commence par une porte qui s'ouvre seule.",
                       "Explique à un enfant de 10 ans quelque chose que tu maîtrises.", "Raconte un échec et ce qu'il t'a appris.",
                       "Décris une personne que tu admires sans jamais dire son nom.", "Imagine ta ville dans 100 ans.",
                       "Écris le dialogue entre ton toi d'aujourd'hui et ton toi d'il y a cinq ans.",
                       "Résume un livre ou un film qui t'a marqué, et dis pourquoi.", "Écris un conte dont la morale est « la patience paie »."]

    def writing_info(self) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            today = self.today()
            rows = s.db.execute("SELECT id, day, payload FROM events WHERE hero_id=? AND type='activity' AND day<=? "
                                "ORDER BY day DESC, id DESC LIMIT 400", (hid, today.isoformat())).fetchall()
            items = []
            for r in rows:
                p = json.loads(r["payload"])
                if p.get("kind") == "writing":
                    d = p.get("data") or {}
                    items.append({"id": r["id"], "day": r["day"], "title": d.get("title", ""), "words": d.get("words", 0),
                                  "text": d.get("text", "")})
            return {"prompt": self.WRITING_PROMPTS[today.toordinal() % len(self.WRITING_PROMPTS)], "entries": items[:50],
                    "total_words": sum(i["words"] for i in items), "min_words": C.WRITING_MIN_WORDS, "max_chars": C.WRITING_MAX_CHARS}
        finally:
            s.close()

    def writing_add(self, body: dict) -> dict:
        import re as _re
        text, title = body.get("text", ""), body.get("title", "")
        if not isinstance(text, str) or not isinstance(title, str):
            raise ApiError(400, "Texte attendu")
        text, title = text.strip()[:C.WRITING_MAX_CHARS], title.strip()[:120]
        words = _re.findall(r"[^\W\d_]+(?:['’-][^\W\d_]+)*", text.lower())
        if not words:
            raise ApiError(400, "Écris quelque chose avant d'enregistrer")
        uniq = round(len(set(words)) / len(words), 3)
        return self.log({"kind": "writing", "proof": None, "_server_proof": "app",
                         "data": {"words": len(words), "unique_ratio": uniq, "title": title, "text": text}}, server_proof=True)

    def notes(self, days: str | None) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            today = self.today()
            try:
                n = max(1, min(366, int(days or 30)))
            except ValueError:
                raise ApiError(400, "Nombre de jours invalide")
            rows = s.db.execute("SELECT id, day, payload FROM events WHERE hero_id=? AND type='note' AND day>? AND day<=? "
                                "ORDER BY day DESC, id DESC",
                                (hid, (today - timedelta(days=n)).isoformat(), today.isoformat())).fetchall()
            items = [{"id": r["id"], "day": r["day"], **json.loads(r["payload"])} for r in rows]
            return {"today": today.isoformat(), "prompt": self.PROMPTS[today.toordinal() % len(self.PROMPTS)],
                    "entries": items, "max_chars": C.NOTE_MAX_CHARS, "xp_min_chars": C.NOTE_XP_MIN_CHARS}
        finally:
            s.close()

    def note_add(self, body: dict) -> dict:
        text = body.get("text", "")
        grat = body.get("gratitude", [])
        if not isinstance(text, str) or not isinstance(grat, list) or not all(isinstance(g, str) for g in grat):
            raise ApiError(400, "Texte attendu")
        text = text.strip()[:C.NOTE_MAX_CHARS]
        grat = [g.strip()[:200] for g in grat if g.strip()][:5]
        prompt = str(body.get("prompt", ""))[:200]
        if not text and not grat:
            raise ApiError(400, "Écris quelque chose avant d'enregistrer")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                today = self.today()
                before = s.hero(hid, until=today)
                eid = s._event(hid, today, "note", {"text": text, "gratitude": grat, "prompt": prompt})
                notes, granted, after, stat = ["Entrée enregistrée (elle reste sur ton appareil)"], 0.0, None, "Mental"
                worthy = len(text) >= C.NOTE_XP_MIN_CHARS or len(grat) >= 3
                already = any(json.loads(r["payload"]).get("kind") == "journal" for r in s.db.execute(
                    "SELECT payload FROM events WHERE hero_id=? AND type='activity' AND day=?", (hid, today.isoformat())))
                if worthy and not already:
                    r = s.record(hid, today, "journal", proof="app", ai_ok=True)
                    notes += r.notes
                    granted, stat = r.granted, r.stat
                    after = s.hero(hid, until=today) if any("Quête accomplie" in n for n in r.notes) else r.after
                elif worthy:
                    notes.append("Le journal ne rapporte de l'XP qu'une fois par jour")
                else:
                    notes.append(f"Pour gagner de l'XP : au moins {C.NOTE_XP_MIN_CHARS} caractères, ou 3 choses positives")
                return {"event_id": eid, "granted": round(granted, 1), "stat": stat, "notes": notes,
                        "celebrations": TT.celebrations(before, after, today) if after else []}
            finally:
                s.close()

    def chronicle(self, kind: str | None, ref: str | None) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            try:
                return CH.report(s, hid, "year" if kind == "year" else "month", ref, self.today())
            except (ValueError, TypeError):
                raise ApiError(400, "Période invalide")
        finally:
            s.close()

    def revisions(self) -> dict:
        s = self._store()
        try:
            return RV.overview(s, self._need_hero(s), self.today())
        finally:
            s.close()

    def revision_practice_new(self, body: dict) -> dict:
        chain, theme = body.get("chain"), body.get("theme")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                ov = RV.overview(s, hid, self.today())
                th = next((t for t in ov["todo"] + ov["done"] if t["chain"] == chain and t["theme"] == theme), None)
                if th is None:
                    raise ApiError(400, "Aucune fiche de révision sur ce thème")
                if not th["practice_available"]:
                    raise ApiError(400, "Un entraînement par thème et par jour : reviens demain")
                try:
                    qs = RV.draw_practice(s, hid, self.today(), chain, theme)
                except ValueError as e:
                    raise ApiError(400, str(e))
                return self._timed_quiz(s, hid, "revision", {"chain": chain, "theme": theme, "pass": RV.PRACTICE_PASS},
                                        qs, 60, f"Entraînement · {th['subject']} · {th['label']}")
            finally:
                s.close()

    def revision_practice_answer(self, qid: str, body: dict) -> dict:
        with self.lock:
            q, ok, late, _corr = self._take(qid, "revision", body)
            info = q["revision"]
            good, total = sum(ok), len(ok)
            s = self._store()
            try:
                hid = self._need_hero(s)
                s._event(hid, self.today(), "revision_practice", {"chain": info["chain"], "theme": info["theme"],
                                                                  "good": good, "total": total})
            finally:
                s.close()
        passed = good >= RV.PRACTICE_PASS
        return {"good": good, "total": total, "passed": passed, "late": late,
                "notes": [f"{good} / {total}" + (" : thème revu, bravo !" if passed else
                                                 f" : il en faut {RV.PRACTICE_PASS} pour valider ce thème. Relis la fiche et réessaie demain.")],
                "correction": self._correction(body.get("answers"), q["questions"], reveal=True)}

    def langues(self) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            for lang in LG.LANGS:
                for lv in LG.LEVELS:
                    self._resolve_abandoned(s, hid, "lang", f"{lang}:{lv}")
            return LG.status(s, hid, self.today())
        finally:
            s.close()

    def langue_test_new(self, body: dict) -> dict:
        lang, level = body.get("lang"), body.get("level")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                if lang in LG.LANGS and level in LG.LEVELS:
                    self._resolve_abandoned(s, hid, "lang", f"{lang}:{level}")
                try:
                    LG.check_available(s, hid, self.today(), lang, level)
                except ValueError as e:
                    raise ApiError(400, str(e))
                self._begin(s, "lang", f"{lang}:{level}")
                return self._timed_quiz(s, hid, "lang_test", {"lang": lang, "level": level, "pass": LG.PASS},
                                        LG.draw(lang, level), LG.SECONDS_PER_Q, f"Test de niveau · {lang.capitalize()} {level}")
            finally:
                s.close()

    def langue_test_answer(self, qid: str, body: dict) -> dict:
        with self.lock:
            q, ok, late, corr = self._take(qid, "lang_test", body)
        info = q["lang_test"]
        good, total = sum(ok), len(ok)
        passed = good >= LG.PASS
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                self._finish(s, "lang", f"{info['lang']}:{info['level']}")
                s._event(hid, self.today(), "langlevel", {"lang": info["lang"], "level": info["level"], "good": good,
                                                          "total": total, "passed": passed})
            finally:
                s.close()
        result = self.log({"kind": "language", "data": {"n": total, "score": round(good / total, 3), "level": info["level"],
                                                        "language": info["lang"]}}, server_proof=True)
        msg = (f"{good} / {total} : niveau {info['level']} validé en {info['lang']} !" if passed else
               f"{good} / {total} : il en fallait {LG.PASS}. Tu pourras le repasser dans {LG.RETRY_DAYS} jours.")
        result["notes"].insert(0, ("Temps dépassé : " if late else "") + msg)
        cel = list(result.get("celebrations") or [])
        if passed:
            cel.append({"type": "palier", "text": f"Niveau {info['level']} validé en {info['lang']}"})
            corr = self._correction(body.get("answers"), q["questions"], reveal=True)
        result.update(passed=passed, good=good, total=total, late=late, correction=corr, celebrations=cel)
        return result

    def langue_vocab(self, body: dict) -> dict:
        lang, level = body.get("lang"), body.get("level")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    pairs = LG.vocab(lang, level)
                    n = CA.add_cards(s, hid, self.today(), f"{lang.capitalize()} {level}", pairs, source=f"{lang}:{level}")
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"message": f"{n} carte(s) ajoutée(s) au paquet « {lang.capitalize()} {level} »" if n
                        else "Ce vocabulaire est déjà dans tes cartes", "added": n}
            finally:
                s.close()

    def cartes(self, deck: str | None) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            out = CA.overview(s, hid, self.today())
            if deck:
                out["deck_cards"] = CA.deck_cards(s, hid, self.today(), deck)
            return out
        finally:
            s.close()

    def cartes_action(self, body: dict) -> dict:
        if body.get("action") == "finish":
            with self.lock:
                s = self._store()
                try:
                    hid = self._need_hero(s)
                    today = self.today()
                    n, ok = CA._today_reviews(s, hid, today)
                    todo = n - CA._credited_today(s, hid, today)
                finally:
                    s.close()
            if todo < 1:
                raise ApiError(400, "Aucune nouvelle carte révisée aujourd'hui")
            r = self.log({"kind": "cards", "data": {"n": todo, "ok": round(ok * todo / n)}}, server_proof=True)
            return {**r, **self.cartes(None)}
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    msg = CA.action(s, hid, self.today(), body)
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"message": msg, **CA.overview(s, hid, self.today())}
            finally:
                s.close()

    def places(self) -> dict:
        s = self._store()
        try:
            return PCS.collection(s, self._need_hero(s), self.today())
        finally:
            s.close()

    def lore(self) -> dict:
        s = self._store()
        try:
            return LO.chapters(s.hero(self._need_hero(s), until=self.today()))
        finally:
            s.close()

    def goals(self) -> dict:
        s = self._store()
        try:
            return GO.overview(s, self._need_hero(s), self.today())
        finally:
            s.close()

    def goal_action(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    msg = GO.action(s, hid, self.today(), body)
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"message": msg, **GO.overview(s, hid, self.today())}
            finally:
                s.close()

    def coach(self) -> dict:
        s = self._store()
        try:
            return {"tips": CO.tips(s, self._need_hero(s), self.today())}
        finally:
            s.close()

    def records(self) -> dict:
        s = self._store()
        try:
            return RC.overview(s, self._need_hero(s), self.today())
        finally:
            s.close()

    # ------------------------------------------------------------------ défis et habitudes
    def defis(self) -> dict:
        s = self._store()
        try:
            return DF.overview(s, self._need_hero(s), self.today())
        finally:
            s.close()

    def defi_action(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    msg = DF.action(s, hid, self.today(), body)
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"message": msg, **DF.overview(s, hid, self.today())}
            finally:
                s.close()

    # ------------------------------------------------------------------ programmes
    def programs(self) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            return PG.overview(s, hid, self.today())
        finally:
            s.close()

    def program_action(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    if "interests" in body:
                        return {"message": PG.set_interests(s, hid, body.get("interests"))}
                    return {"message": PG.choose(s, hid, self.today(), body.get("stat"), body.get("program"))}
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()

    # ------------------------------------------------------------------ profil, convalescence, sommeil
    def profile(self) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            today = self.today()
            hero = s.hero(hid, until=today)
            stats = []
            for st in C.STATS:
                days = hero.inactive_days(st, today)
                stats.append({"name": st, "rank": hero.rank_of(st), "earned": hero.earned_rank(st),
                              "dormant": hero.is_dormant(st, today), "inactive_days": days,
                              "wake": len([d for d in hero.wake.get(st, []) if 0 <= (today - d).days < C.WAKE_DAYS]),
                              "convalescence": ({"since": hero.convalescence[st][0].isoformat(),
                                                 "reason": hero.convalescence[st][1]} if st in hero.convalescence else None),
                              "trials": T.status(hero, today, st)})
            return {"name": hero.name, "birth_year": hero.birth_year, "age": hero.age(today), "sex": hero.sex,
                    "weight": hero.bodyweight, "adapted": hero.adapted, "conditions": T.health_ids(hero),
                    "quiz_time": HL.quiz_time(T.health_ids(hero)), "hero_class": hero.hero_class,
                    "rank": hero.rank, "level": hero.level, "explain": T.explain(hero, today), "stats": stats,
                    "rules": {"min_age": C.MIN_AGE, "max_age": C.MAX_AGE, "dormant_days": hero.dormant_days,
                              "wake_sessions": C.WAKE_SESSIONS, "wake_days": C.WAKE_DAYS, "sexes": list(C.SEXES)},
                    "minor": hero.age(today) is not None and hero.age(today) < 18}
        finally:
            s.close()

    def update_profile(self, body: dict) -> dict:
        fields = {k: body.get(k) for k in ("birth_year", "sex", "weight", "adapted", "name", "conditions") if k in body}
        if isinstance(fields.get("weight"), str):
            if not fields["weight"].strip():
                fields.pop("weight")                     # champ vide : poids inchangé
            else:
                try:
                    fields["weight"] = float(fields["weight"].replace(",", "."))
                except ValueError:
                    raise ApiError(400, "Poids : nombre attendu")
        if isinstance(fields.get("birth_year"), str):
            by = fields["birth_year"].strip()
            if not by:
                fields.pop("birth_year")                 # champ vide : inchangé
            elif by.isdigit():
                fields["birth_year"] = int(by)
            else:
                raise ApiError(400, "Année de naissance : nombre entier attendu")
        with self.lock:
            s = self._store()
            try:
                try:
                    return {"notes": s.update_profile(self._need_hero(s), self.today(), **fields)}
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()

    def set_convalescence(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                try:
                    return {"message": s.convalescence(self._need_hero(s), self.today(), str(body.get("action", "")),
                                                       body.get("stats"), body.get("reason", ""))}
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()

    # ------------------------------------------------------------------ minuteur de concentration
    def _open_focus(self, s: Store, hid: int):
        """Séance de minuteur en cours (la plus récente non close), ou None. Une séance de plus de
        FOCUS_MAX_MINUTES + 1 h oubliée est close sans XP."""
        row = s.db.execute("SELECT * FROM proofs WHERE hero_id=? AND kind='focus' AND used_by IS NULL "
                           "ORDER BY created DESC LIMIT 1", (hid,)).fetchone()
        if row is None:
            return None
        summary = json.loads(row["summary"])
        if self.clock() - summary["started"] > (C.FOCUS_MAX_MINUTES + 60) * 60:
            s.use_proof(row["token"], 0)
            return None
        return {"token": row["token"], **summary}

    def focus_status(self) -> dict:
        s = self._store()
        try:
            cur = self._open_focus(s, self._need_hero(s))
            return {"running": cur is not None, **({"token": cur["token"], "elapsed_s": round(self.clock() - cur["started"]),
                                                    "label": cur.get("label", ""), "mode": cur.get("mode", "focus"),
                                                    "pattern": cur.get("pattern", "")} if cur else {}),
                    "min_minutes": C.FOCUS_MIN_MINUTES, "max_minutes": C.FOCUS_MAX_MINUTES}
        finally:
            s.close()

    def focus_start(self, body: dict) -> dict:
        label = str(body.get("label", "")).strip()[:60]
        mode = body.get("mode", "focus")
        if mode not in ("focus", "respiration", "mobilite"):
            raise ApiError(400, "Mode inconnu")
        pattern = str(body.get("pattern", ""))[:20]
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                if self._open_focus(s, hid):
                    raise ApiError(409, "Une séance de concentration est déjà en cours")
                token = s.add_proof(hid, "focus", {"started": self.clock(), "day": self.today().isoformat(), "label": label,
                                                   "mode": mode, "pattern": pattern})
                return {"token": token, "elapsed_s": 0}
            finally:
                s.close()

    def focus_stop(self, body: dict) -> dict:
        inter = body.get("interruptions", 0)
        if isinstance(inter, bool) or not isinstance(inter, int) or not 0 <= inter <= 100:
            raise ApiError(400, "Interruptions : nombre entier entre 0 et 100")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                cur = self._open_focus(s, hid)
                if cur is None or cur["token"] != body.get("token"):
                    raise ApiError(404, "Aucune séance en cours")
                minutes = (self.clock() - cur["started"]) / 60
                breath = cur.get("mode") == "respiration"
                mob = cur.get("mode") == "mobilite"
                lo, hi = ((C.BREATH_MIN_MINUTES, C.BREATH_MAX_MINUTES) if breath else
                          (C.MOBILITY_MIN_MINUTES, C.MOBILITY_MAX_MINUTES) if mob else (C.FOCUS_MIN_MINUTES, C.FOCUS_MAX_MINUTES))
                if body.get("cancel") or minutes < lo:
                    s.use_proof(cur["token"], 0)
                    return {"saved": False, "minutes": round(minutes, 1),
                            "notes": ["Séance annulée" if body.get("cancel") else
                                      f"Séance trop courte (moins de {lo} min) : non enregistrée"]}
                minutes = round(min(minutes, hi), 1)
                day = date.fromisoformat(cur["day"])
                before = s.hero(hid, until=day)
                if breath:
                    r = s.record(hid, day, "meditation", proof="app", minutes=minutes, style="respiration")
                elif mob:
                    r = s.record(hid, day, "mobility", proof="app", minutes=minutes)
                else:
                    r = s.record(hid, day, "focus", proof="app", minutes=minutes, interruptions=inter)
                s.use_proof(cur["token"], r.event_id)
                after = s.hero(hid, until=day) if any("Quête accomplie" in n for n in r.notes) else r.after
                notes = list(r.notes)
                if minutes >= hi:
                    notes.insert(0, f"Séance limitée à {hi} min")
                return {"saved": True, "minutes": minutes, "interruptions": inter, "stat": r.stat,
                        "granted": round(r.granted, 1), "notes": notes, "event_id": r.event_id,
                        "celebrations": TT.celebrations(before, after, day)}
            finally:
                s.close()

    # ------------------------------------------------------------------ saisons, calendrier, collection, carte
    def _journal_view(self, what: str, arg=None) -> dict:
        s = self._store()
        try:
            j = SZ.Journal(s, self._need_hero(s), self.today())
            if what == "seasons":
                items = j.seasons()
                return {"current": items[0], "past": items[1:]}
            if what == "calendar":
                return j.calendar(arg)
            if what == "collection":
                return j.collection()
            return j.world_map()
        finally:
            s.close()

    @staticmethod
    def _correction(answers, questions, reveal: bool) -> list[dict]:
        """Correction : les bonnes réponses ne sont montrées que si `reveal` (quiz réussi, quiz du jour).
        Après un échec, on voit seulement quelles questions sont fausses : pas de réponses à apprendre par cœur."""
        out = []
        for a, it in zip(answers, questions):
            yours = it["choices"][a] if isinstance(a, int) and 0 <= a < 4 else None
            out.append({"id": it["id"], "question": it["q"], "ok": a == it["answer"], "yours": yours,
                        "answer": it["choices"][it["answer"]] if reveal else None})
        return out

    def book_quiz_report(self, body: dict) -> dict:
        qid = str(body.get("question_id", ""))
        if BQ.find_question(qid) is None:
            raise ApiError(404, "Question inconnue")
        s = self._store()
        try:
            s.report_question(qid, str(body.get("comment", "")))
        finally:
            s.close()
        return {"ok": True, "message": "Merci : cette question ne sera plus posée."}

    SIMULATED_PROOFS = {"gpx", "app", "téléphone"}      # choisies à la main : acceptées en mode test seulement

    def _check_proof(self, s: Store, hid: int, kind: str, data: dict, proof, day: date) -> tuple[str | None, str | None]:
        """Renvoie (preuve à enregistrer, jeton à consommer). Une trace GPX importée donne un
        jeton à usage unique ; la saisie doit correspondre à son résumé et à sa date."""
        if not proof:
            return None, None
        proof = str(proof)
        if proof.startswith("gpx:"):
            token = proof[4:]
            p = s.proof(hid, token)
            if p is None or p["kind"] != "gpx":
                raise ApiError(400, "Trace GPX introuvable : importe-la de nouveau")
            if p["used_by"] is not None:
                raise ApiError(400, "Cette trace GPX a déjà servi pour une autre saisie")
            if kind not in ("expedition", "endurance"):
                raise ApiError(400, "Une trace GPX prouve une sortie ou une séance d'endurance")
            if not GPX.matches(p["summary"], data):
                raise ApiError(400, "La saisie ne correspond pas à la trace importée (distance, dénivelé ou durée)")
            if day.isoformat() != p["summary"]["day"]:
                raise ApiError(400, f"La trace date du {p['summary']['day']} : saisis-la à cette date")
            return "gpx", token
        if self.test_mode and proof in self.SIMULATED_PROOFS:
            return proof, None
        raise ApiError(400, "Cette preuve n'est pas encore disponible : importe une trace GPX, ou enregistre sans preuve")

    def gpx(self, body: dict) -> dict:
        text = body.get("text")
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    summary = GPX.parse(text)
                except ValueError as e:
                    raise ApiError(400, str(e))
                age = (self.today() - date.fromisoformat(summary["day"])).days
                if age < 0:
                    raise ApiError(400, "Cette trace est datée dans le futur")
                if age > C.BACKDATE_DAYS_GPX:
                    raise ApiError(400, f"Trace du {summary['day']} : une trace s'importe au plus {C.BACKDATE_DAYS_GPX} jours après la sortie")
                return {"token": s.add_proof(hid, "gpx", summary), "summary": summary}
            finally:
                s.close()

    def log(self, body: dict, quiz_checked: bool = False, server_proof: bool = False) -> dict:
        """`quiz_checked` : appel interne après un quiz corrigé par le serveur (score fiable)."""
        kind = body.get("kind")
        if kind not in ACTIVITIES:
            raise ApiError(400, f"Activité inconnue : {kind}")
        data = self._data(body)
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                day = self._entry_day(body, kind, body.get("proof"))
                if kind == "reading" and data.get("quiz") is not None and not (self.test_mode or quiz_checked):
                    raise ApiError(400, "Le score de quiz vient du quiz du livre : saisis ta lecture, puis passe le quiz")
                if kind == "reading" and data.get("work_id") and data["work_id"] not in BQ.bank():
                    raise ApiError(400, "Livre absent de la banque de quiz")
                if kind == "homework" and not (self.test_mode or quiz_checked):
                    raise ApiError(400, "Les devoirs se valident par un quiz de matière (écran Quiz → Matières)")
                if kind == "cards" and not server_proof:
                    raise ApiError(400, "Les cartes se révisent dans l'écran Cartes : ASCEND compte tout seul")
                if kind == "writing" and not server_proof:
                    raise ApiError(400, "Les textes s'écrivent dans l'onglet Écriture du Carnet : ASCEND compte les mots")
                proof, token = (("app", None) if server_proof else self._check_proof(s, hid, kind, data, body.get("proof"), day))
                try:
                    r = s.record(hid, day, kind, proof=proof, **data)
                except ValueError as e:
                    raise ApiError(400, str(e))
                except (TypeError, KeyError) as e:
                    raise ApiError(400, f"Saisie incomplète ou invalide : {e}")
                if token:
                    s.use_proof(token, r.event_id)
                # Les quêtes (et donc la Discipline) peuvent avoir changé : on relit pour l'état « après ».
                after = s.hero(hid, until=day) if any("Quête accomplie" in n for n in r.notes) else r.after
                return {"stat": r.stat, "granted": round(r.granted, 1), "notes": r.notes, "event_id": r.event_id,
                        "celebrations": TT.celebrations(r.before, after, day)}
            finally:
                s.close()

    def journal(self, day_str: str | None) -> dict:
        s = self._store()
        try:
            hid = self._need_hero(s)
            try:
                day = date.fromisoformat(day_str) if day_str else self.today()
            except ValueError:
                raise ApiError(400, "Date attendue au format AAAA-MM-JJ")
            if day > self.today():
                raise ApiError(400, "Pas de journal pour une date future")
            items = s.journal(hid, day)
            for it in items:
                it["label"] = describe(it)
            return {"day": day.isoformat(), "entries": items}
        finally:
            s.close()

    def recent(self, kind: str | None) -> dict:
        """Raccourcis : les 5 dernières saisies DIFFÉRENTES d'un type, pour les reprendre d'un clic."""
        aliases = {"bodyweight": ("bodyweight", "skill"), "skill": ("bodyweight", "skill"),
                   "language": ("language", "english"), "english": ("language", "english")}
        kinds = aliases.get(kind, (kind,))
        s = self._store()
        try:
            hid = self._need_hero(s)
            out, seen = [], set()
            for ev in s.db.execute("SELECT * FROM events WHERE hero_id=? AND type='activity' ORDER BY day DESC, id DESC LIMIT 400",
                                   (hid,)):
                p = json.loads(ev["payload"])
                if p.get("kind") not in kinds:
                    continue
                key = json.dumps(p.get("data"), sort_keys=True)
                if key in seen:
                    continue
                try:
                    from .engine import validate
                    validate(p["kind"], {**p["data"], **({"bedtime": time(0, 0)} if p["kind"] == "sleep" else {})})
                except (ValueError, TypeError, KeyError):
                    continue                              # une ancienne saisie invalide n'est pas proposée
                seen.add(key)
                out.append({"label": describe({"type": "activity", **p}), "kind": p["kind"], "data": p["data"],
                            "proof": p.get("proof")})
                if len(out) >= 5:
                    break
            return {"items": out}
        finally:
            s.close()

    def event(self, event_id: int) -> dict:
        s = self._store()
        try:
            try:
                return s.event(self._need_hero(s), event_id)
            except KeyError:
                raise ApiError(404, "Saisie introuvable")
        finally:
            s.close()

    def delete_event(self, event_id: int) -> dict:
        with self.lock:
            s = self._store()
            try:
                try:
                    s.delete_event(self._need_hero(s), event_id, allow_class=self.test_mode, today=self.today())
                except KeyError:
                    raise ApiError(404, "Saisie introuvable")
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"ok": True}
            finally:
                s.close()

    def update_event(self, event_id: int, body: dict) -> dict:
        kind = body.get("kind")
        if kind not in ACTIVITIES:
            raise ApiError(400, f"Activité inconnue : {kind}")
        data = self._data(body)
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                proof = body.get("proof") or None
                if not self.test_mode:
                    # Hors mode test, une preuve n'est gardée que si la trace liée correspond toujours.
                    linked = s.proof_of_event(hid, event_id)
                    proof = "gpx" if linked and kind in ("expedition", "endurance") and GPX.matches(linked["summary"], data) else None
                elif proof and proof not in self.SIMULATED_PROOFS:
                    proof = None
                if kind == "cards":
                    raise ApiError(400, "Une séance de cartes ne se modifie pas (tu peux l'annuler)")
                if kind == "writing":
                    raise ApiError(400, "Un texte ne se modifie pas ici : annule-le et réécris-le dans l'onglet Écriture")
                if not self.test_mode:
                    try:
                        was = s.event(hid, event_id)
                    except KeyError:
                        raise ApiError(404, "Saisie introuvable")
                    if was.get("kind") in ("writing", "cards"):
                        raise ApiError(400, "Un texte ne se modifie pas ici : annule-le et réécris-le dans l'onglet Écriture")
                    if kind == "homework" or was.get("kind") == "homework":
                        raise ApiError(400, "Un quiz de matière ne se modifie pas : annule-le ou repasse un quiz demain")
                    if was.get("proof") == "app" and was.get("kind") == "focus":
                        raise ApiError(400, "Une séance mesurée par le minuteur ne se modifie pas (tu peux l'annuler)")
                if kind == "reading" and not self.test_mode:
                    # Le score de quiz ne se modifie pas à la main : on garde celui de la saisie d'origine.
                    try:
                        old = s.event(hid, event_id)
                    except KeyError:
                        raise ApiError(404, "Saisie introuvable")
                    data.pop("quiz", None)
                    old_quiz = (old.get("data") or {}).get("quiz") if old.get("kind") == "reading" else None
                    if old_quiz is not None:
                        data["quiz"] = old_quiz
                if kind == "reading" and data.get("work_id") and data["work_id"] not in BQ.bank():
                    raise ApiError(400, "Livre absent de la banque de quiz")
                try:
                    r = s.update_event(hid, event_id, kind, proof=proof, **data)
                except KeyError:
                    raise ApiError(404, "Saisie introuvable")
                except ValueError as e:
                    raise ApiError(400, str(e))
                return {"stat": r.stat, "granted": round(r.granted, 1), "notes": r.notes, "event_id": event_id}
            finally:
                s.close()

    @staticmethod
    def _data(body: dict) -> dict:
        if not isinstance(body.get("data") or {}, dict):
            raise ApiError(400, "Données de saisie invalides")
        data = dict(body.get("data") or {})
        if isinstance(data.get("bedtime"), str):
            try:
                h, m = data["bedtime"].split(":")
                data["bedtime"] = time(int(h), int(m))
            except ValueError:
                raise ApiError(400, "Heure de coucher attendue au format HH:MM")
        return data

    def swap(self, quest_id: int, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    return {"message": s.swap_quest(hid, quest_id, str(body.get("reason", "")), today=self.today())}
                except ValueError as e:
                    raise ApiError(400, str(e))
            finally:
                s.close()

    def rest(self) -> dict:
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                s.rest(hid, self.today())
                neutral = self.today().isoformat() in s.neutral_rest_days(hid)
                return {"ok": True, "neutral": neutral,
                        "message": "Repos enregistré : ta Discipline n'est pas touchée." if neutral else
                        f"Repos enregistré, mais c'est plus de {C.REST_NEUTRAL_PER_WEEK} repos en 7 jours : "
                        "cette journée compte normalement pour la Discipline."}
            finally:
                s.close()

    def _entry_day(self, body: dict, kind: str | None = None, proof: str | None = None) -> date:
        """Jour de la saisie : aujourd'hui, ou jusqu'à BACKDATE_DAYS jours en arrière
        (BACKDATE_DAYS_GPX pour une trace GPX importée)."""
        raw = body.get("day")
        if not raw:
            return self.today()
        try:
            day = date.fromisoformat(str(raw))
        except ValueError:
            raise ApiError(400, "Date attendue au format AAAA-MM-JJ")
        limit = C.BACKDATE_DAYS_GPX if proof and str(proof).startswith("gpx") else C.BACKDATE_DAYS
        if day > self.today():
            raise ApiError(400, "Impossible de saisir une activité dans le futur")
        if (self.today() - day).days > limit:
            raise ApiError(400, f"Une activité se saisit au plus {limit} jours après coup")
        return day

    def assess(self, body: dict) -> dict:
        with self.lock:
            s = self._store()
            try:
                hid = self._need_hero(s)
                try:
                    if "meters" in body:
                        notes = s.cooper(hid, self.today(), float(body["meters"]))
                    else:
                        raw = body.get("results")
                        if not isinstance(raw, dict) or not all(isinstance(v, dict) for v in raw.values()):
                            raise ValueError("Renseigne au moins une famille")
                        results = {f: (v.get("variant"), float(v.get("amount"))) for f, v in raw.items()}
                        notes = s.assess(hid, self.today(), results)
                except ValueError as e:
                    raise ApiError(400, str(e))
                except (KeyError, TypeError) as e:
                    raise ApiError(400, f"Évaluation invalide : {e}")
                return {"notes": notes}
            finally:
                s.close()

    def backup(self, folder: Path | None = None, force: bool = False) -> Path | None:
        s = self._store()
        try:
            return s.backup(folder or self.backup_dir, today=self.today(), force=force)
        finally:
            s.close()

    BACKUP_NAME = re.compile(r"^ascend-\d{4}-\d{2}-\d{2}\.(ascbak|db)$")

    def backups(self) -> dict:
        s = self._store()
        try:
            folder = Path(self.backup_dir)
            files = sorted([p for p in folder.glob("ascend-*") if self.BACKUP_NAME.match(p.name)], reverse=True) \
                if folder.exists() else []
            return {"folder": str(folder), "code_noted": s.get_meta("backup_code_noted") == "1",
                    "files": [{"name": p.name, "day": p.name[7:17], "encrypted": p.suffix == ".ascbak",
                               "size_kb": round(p.stat().st_size / 1024, 1)} for p in files]}
        finally:
            s.close()

    def backup_code(self) -> dict:
        s = self._store()
        try:
            return {"code": s.backup_code()}
        finally:
            s.close()

    def code_noted(self) -> dict:
        s = self._store()
        try:
            s.set_meta("backup_code_noted", "1")
            return {"ok": True}
        finally:
            s.close()

    def backup_now(self) -> dict:
        with self.lock:
            p = self.backup(force=True)
            return {"name": p.name if p else None}

    def restore(self, body: dict) -> dict:
        """Restaure une sauvegarde : vérifie le fichier (et le code s'il est chiffré), garde une
        copie de sécurité de la base actuelle, puis remplace son contenu."""
        import sqlite3 as _sq
        from datetime import datetime as _dt
        from .crypto import decrypt
        name = str(body.get("name", ""))
        if not self.BACKUP_NAME.match(name):
            raise ApiError(400, "Sauvegarde inconnue")
        src = Path(self.backup_dir) / name
        if not src.is_file():
            raise ApiError(404, "Sauvegarde introuvable")
        r = self._restore_bytes(src.read_bytes(), src.suffix == ".ascbak", str(body.get("code", "")))
        r["message"] = f"Sauvegarde du {name[7:17]} restaurée. L'ancienne version est gardée ({r['safety']})."
        return r

    def export_file(self) -> dict:
        """Fichier de transfert chiffré (code de récupération) : pour passer du PC au téléphone et inversement."""
        import base64
        import sqlite3 as _sq
        from .crypto import encrypt
        tmp = Path(self.db_path).parent / ".export.tmp"
        with self.lock:
            s = self._store()
            try:
                self._need_hero(s)
                code = s.backup_code()
                dest = _sq.connect(tmp)
                with dest:
                    s.db.backup(dest)
                dest.close()
                blob = encrypt(tmp.read_bytes(), code)
            finally:
                s.close()
                tmp.unlink(missing_ok=True)
        return {"name": f"ascend-transfert-{self.today().isoformat()}.ascbak", "data": base64.b64encode(blob).decode(),
                "size_kb": round(len(blob) / 1024, 1)}

    def import_file(self, body: dict) -> dict:
        """Importe un fichier de transfert (.ascbak chiffré) : remplace le héros de cet appareil."""
        import base64
        import binascii
        try:
            raw = base64.b64decode(str(body.get("data", "")), validate=True)
        except (binascii.Error, ValueError):
            raise ApiError(400, "Fichier illisible")
        if not raw:
            raise ApiError(400, "Fichier vide")
        r = self._restore_bytes(raw, True, str(body.get("code", "")))
        r["message"] = f"Héros importé. L'ancienne version de cet appareil est gardée ({r['safety']})."
        return r

    def _restore_bytes(self, raw: bytes, encrypted: bool, code: str) -> dict:
        import sqlite3 as _sq
        from datetime import datetime as _dt
        from .crypto import decrypt
        tmp = Path(self.db_path).parent / ".restauration.tmp"
        with self.lock:
            try:
                if encrypted:
                    try:
                        raw = decrypt(raw, code)
                    except ValueError as e:
                        raise ApiError(400, str(e))
                tmp.write_bytes(raw)
                try:
                    con = _sq.connect(tmp)
                    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                    heroes = con.execute("SELECT COUNT(*) FROM hero").fetchone()[0] if "hero" in tables else 0
                except _sq.DatabaseError:
                    raise ApiError(400, "Ce fichier n'est pas une base ASCEND lisible")
                if not {"hero", "events", "quests"} <= tables or heroes == 0:
                    con.close()
                    raise ApiError(400, "Ce fichier n'est pas une sauvegarde ASCEND complète")
                safety = Path(self.db_path).parent / f"avant-restauration-{_dt.now():%Y%m%d-%H%M%S}.db"
                cur = _sq.connect(self.db_path)
                sdb = _sq.connect(safety)
                cur.backup(sdb)          # copie de sécurité de la base actuelle
                sdb.close()
                con.backup(cur)          # remplace le contenu de la base actuelle
                con.close(); cur.close()
                Store(self.db_path).close()   # remet à niveau le schéma si la sauvegarde est ancienne
                return {"ok": True, "safety": safety.name}
            finally:
                tmp.unlink(missing_ok=True)

    def _need_hero(self, s: Store) -> int:
        hid = self.hero_id(s)
        if hid is None:
            raise ApiError(400, "Crée d'abord ton héros")
        return hid



def route_get(app: "App", url) -> tuple[int, object] | None:
    """Routes GET de l'API. None si ce n'est pas une route d'API (fichier statique)."""
    if url.path == "/api/state":
        return 200, (app.state())
    if url.path == "/api/bilan":
        return 200, (app.bilan(parse_qs(url.query).get("week", [None])[0]))
    if url.path == "/api/quests/history":
        return 200, (app.quest_history(parse_qs(url.query).get("days", [None])[0]))
    if url.path == "/api/region":
        return 200, (app.region(parse_qs(url.query).get("stat", ["Force"])[0]))
    if url.path == "/api/hero":
        return 200, (app.hero_sheet())
    if url.path == "/api/cursus":
        return 200, (app.cursus())
    if url.path == "/api/placement":
        return 200, (app.placement_info())
    if url.path == "/api/programs":
        return 200, (app.programs())
    if url.path == "/api/defis":
        return 200, (app.defis())
    if url.path == "/api/chronique":
        q = parse_qs(url.query)
        return 200, (app.chronicle(q.get("kind", [None])[0], q.get("ref", [None])[0]))
    if url.path == "/api/lieux":
        return 200, (app.places())
    if url.path == "/api/lore":
        return 200, (app.lore())
    if url.path == "/api/goals":
        return 200, (app.goals())
    if url.path == "/api/coach":
        return 200, (app.coach())
    if url.path == "/api/records":
        return 200, (app.records())
    if url.path == "/api/revisions":
        return 200, (app.revisions())
    if url.path == "/api/langues":
        return 200, (app.langues())
    if url.path == "/api/cartes":
        return 200, (app.cartes(parse_qs(url.query).get("deck", [None])[0]))
    if url.path == "/api/ecriture":
        return 200, (app.writing_info())
    if url.path == "/api/notes":
        return 200, (app.notes(parse_qs(url.query).get("days", [None])[0]))
    if url.path == "/api/health":
        return 200, (HL.catalog())
    if url.path == "/api/profile":
        return 200, (app.profile())
    if url.path == "/api/focus":
        return 200, (app.focus_status())
    if url.path == "/api/subjects":
        return 200, (app.subjects())
    if url.path == "/api/seasons":
        return 200, (app._journal_view("seasons"))
    if url.path == "/api/collection":
        return 200, (app._journal_view("collection"))
    if url.path == "/api/map":
        return 200, (app._journal_view("map"))
    if url.path == "/api/calendar":
        try:
            days = max(28, min(int(parse_qs(url.query).get("days", ["365"])[0]), 730))
        except ValueError:
            raise ApiError(400, "Nombre de jours invalide")
        return 200, (app._journal_view("calendar", days))
    if url.path == "/api/books":
        return 200, (app.books(parse_qs(url.query).get("q", [None])[0]))
    if url.path == "/api/quiz/status":
        return 200, (app.quiz_status())
    if url.path == "/api/export":
        return 200, app.export_file()
    if url.path == "/api/backups":
        return 200, (app.backups())
    if url.path == "/api/backup-code":
        return 200, (app.backup_code())
    if url.path == "/api/recent":
        return 200, (app.recent(parse_qs(url.query).get("kind", [None])[0]))
    if url.path == "/api/journal":
        return 200, (app.journal(parse_qs(url.query).get("day", [None])[0]))
    parts = url.path.strip("/").split("/")
    if len(parts) == 3 and parts[:2] == ["api", "events"] and parts[2].isdigit():
        return 200, (app.event(int(parts[2])))
    if url.path == "/api/catalog":
        stat = parse_qs(url.query).get("stat", ["Force"])[0]
        return 200, (app.catalog(stat))
    if url.path == "/api/meta":
        return 200, ({
            "reading": list(C.READING_CONTENT), "languages": list(C.LANGUAGE_LEVELS),
            "meditation": list(C.MEDITATION_STYLES), "cotation": list(C.EXPEDITION_COTATION), "place_types": C.PLACE_TYPES,
            "sports": list(C.ENDURANCE_SPORTS), "reasons": Q.SWAP_REASONS,
            "classes": [{"name": n, "weights": w} for n, w in C.CLASSES.items()],
            "rules": {
                "thresholds": C.RANK_THRESHOLDS, "daily": [C.DAILY_FULL_XP, C.DAILY_SOFT_XP],
                "weekly": [C.WEEKLY_FULL_XP, C.WEEKLY_SOFT_XP], "soft_rate": C.SOFT_RATE,
                "daily_overrides": C.DAILY_CAP_OVERRIDES, "verification": C.VERIFICATION_RATES,
                "exempt": sorted(C.VERIFICATION_EXEMPT), "unverified_cap": C.UNVERIFIED_WEEKLY_CAP,
                "progress": [C.MAX_PROGRESS_PER_SESSION, C.MAX_PROGRESS_PER_WEEK, C.MAX_PROGRESS_PER_28D],
                "jump": [C.IMPLAUSIBLE_JUMP, C.JUMP_CONFIRM_SESSIONS, C.JUMP_CONFIRM_DAYS],
                "baseline_days": C.BASELINE_DAYS, "rest_per_week": C.REST_NEUTRAL_PER_WEEK,
                "backdate": [C.BACKDATE_DAYS, C.BACKDATE_DAYS_GPX], "daily_quests": C.DAILY_QUESTS,
                "discipline_days": C.DISCIPLINE_DAYS, "backups_kept": C.BACKUPS_KEPT},
            "lifts": list(K.LIFTS),
            "families": {f: {"stat": i["stat"], "unit": i["unit"],
                             "variants": [{"id": v.id, "name": v.name} for v in i["variants"]]}
                         for f, i in K.FAMILIES.items()}})
    return None


def route_post(app: "App", path: str, body: dict) -> tuple[int, object]:
    """Routes POST de l'API."""
    if path == "/api/hero":
        return 200, (app.create_hero(body))
    if path == "/api/log":
        return 200, (app.log(body))
    if path == "/api/gpx":
        return 200, (app.gpx(body))
    if path == "/api/profile":
        return 200, (app.update_profile(body))
    if path == "/api/placement":
        return 200, (app.placement_submit(body))
    if path == "/api/cursus":
        return 200, (app.cursus_choose(body))
    if path == "/api/cursus/placement/new":
        return 200, (app.placement_subject_new(body))
    if path == "/api/cursus/exam/new":
        return 200, (app.exam_new(body))
    cparts = path.strip("/").split("/")
    if len(cparts) == 5 and cparts[:2] == ["api", "cursus"] and cparts[4] == "answer":
        if cparts[2] == "placement":
            return 200, (app.placement_subject_answer(cparts[3], body))
        if cparts[2] == "exam":
            return 200, (app.exam_answer(cparts[3], body))
    if path == "/api/placement/quiz/new":
        return 200, (app.placement_quiz_new())
    pparts = path.strip("/").split("/")
    if len(pparts) == 5 and pparts[:3] == ["api", "placement", "quiz"] and pparts[4] == "answer":
        return 200, (app.placement_quiz_answer(pparts[3], body))
    if path == "/api/programs":
        return 200, (app.program_action(body))
    if path == "/api/defis":
        return 200, (app.defi_action(body))
    if path == "/api/goals":
        return 200, (app.goal_action(body))
    if path == "/api/revisions/practice/new":
        return 200, (app.revision_practice_new(body))
    rparts = path.strip("/").split("/")
    if len(rparts) == 5 and rparts[:3] == ["api", "revisions", "practice"] and rparts[4] == "answer":
        return 200, (app.revision_practice_answer(rparts[3], body))
    if path == "/api/langues/test/new":
        return 200, (app.langue_test_new(body))
    if path == "/api/langues/vocab":
        return 200, (app.langue_vocab(body))
    lparts = path.strip("/").split("/")
    if len(lparts) == 5 and lparts[:3] == ["api", "langues", "test"] and lparts[4] == "answer":
        return 200, (app.langue_test_answer(lparts[3], body))
    if path == "/api/cartes":
        return 200, (app.cartes_action(body))
    if path == "/api/ecriture":
        return 200, (app.writing_add(body))
    if path == "/api/notes":
        return 200, (app.note_add(body))
    if path == "/api/convalescence":
        return 200, (app.set_convalescence(body))
    if path == "/api/focus/start":
        return 200, (app.focus_start(body))
    if path == "/api/focus/stop":
        return 200, (app.focus_stop(body))
    if path == "/api/subjectquiz/new":
        return 200, (app.subject_quiz_new(body))
    sparts = path.strip("/").split("/")
    if len(sparts) == 4 and sparts[:2] == ["api", "subjectquiz"] and sparts[3] == "answer":
        return 200, (app.subject_quiz_answer(sparts[2], body))
    if path == "/api/bookquiz/new":
        return 200, (app.book_quiz_new(body))
    if path == "/api/bookquiz/report":
        return 200, (app.book_quiz_report(body))
    bparts = path.strip("/").split("/")
    if len(bparts) == 4 and bparts[:2] == ["api", "bookquiz"] and bparts[3] == "answer":
        return 200, (app.book_quiz_answer(bparts[2], body))
    if path == "/api/quiz/new":
        return 200, (app.quiz_new(body))
    qparts = path.strip("/").split("/")
    if len(qparts) == 4 and qparts[:2] == ["api", "quiz"] and qparts[3] == "answer":
        return 200, (app.quiz_answer(qparts[2], body))
    if path == "/api/backup":
        return 200, (app.backup_now())
    if path == "/api/backup-code/noted":
        return 200, (app.code_noted())
    if path == "/api/import":
        return 200, app.import_file(body)
    if path == "/api/restore":
        return 200, (app.restore(body))
    if path == "/api/class":
        return 200, (app.change_class(body))
    if path == "/api/rest":
        return 200, (app.rest())
    if path == "/api/assess":
        return 200, (app.assess(body))
    parts = path.strip("/").split("/")
    if len(parts) == 4 and parts[:2] == ["api", "quests"] and parts[3] == "swap" and parts[2].isdigit():
        return 200, (app.swap(int(parts[2]), body))
    if len(parts) >= 3 and parts[:2] == ["api", "events"] and parts[2].isdigit():
        if len(parts) == 4 and parts[3] == "delete":
            return 200, (app.delete_event(int(parts[2])))
        if len(parts) == 3:
            return 200, (app.update_event(int(parts[2]), body))
    return 404, {"error": "Introuvable"}


def api_call(app: "App", method: str, raw_path: str, body=None) -> tuple[int, object]:
    """Appel d'API sans serveur HTTP : utilisé par le serveur local et par la version mobile
    (le moteur tourne alors dans le navigateur)."""
    url = urlparse(raw_path)
    try:
        if method == "GET":
            r = route_get(app, url)
            return r if r is not None else (404, {"error": "Introuvable"})
        if not isinstance(body, dict):
            raise ApiError(400, "Objet JSON attendu")
        return route_post(app, url.path, body)
    except ApiError as e:
        return e.status, {"error": str(e)}
    except Exception as e:
        import traceback
        traceback.print_exc(file=sys.stderr)
        return 500, {"error": f"Erreur interne ({type(e).__name__}). Envoie une capture de cet écran pour correction."}


def make_handler(app: App, port_ref: list[int]):
    class Handler(BaseHTTPRequestHandler):
        server_version = "ASCEND"

        def log_message(self, fmt, *args):   # silence : pas de journal réseau dans la console
            pass

        def _allowed_host(self) -> bool:
            # Protection contre le « DNS rebinding » : seules les adresses locales sont acceptées.
            host = self.headers.get("Host", "")
            port = port_ref[0]
            return host in (f"127.0.0.1:{port}", f"localhost:{port}")

        def _send(self, status: int, payload, ctype="application/json; charset=utf-8"):
            body = payload if isinstance(payload, bytes) else json.dumps(payload, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if not self._allowed_host():
                return self._send(403, {"error": "Hôte refusé"})
            url = urlparse(self.path)
            try:
                if url.path.startswith("/api/"):
                    status, payload = api_call(app, "GET", self.path)
                    return self._send(status, payload)
                return self._static(url.path)
            except ApiError as e:
                return self._send(e.status, {"error": str(e)})
            except Exception as e:                     # jamais de connexion coupée sans réponse
                return self._internal(e)

        def _internal(self, e: Exception):
            import traceback
            traceback.print_exc(file=sys.stderr)
            return self._send(500, {"error": f"Erreur interne ({type(e).__name__}). Envoie une capture de cet écran pour correction."})

        def do_POST(self):
            # Lire le contenu d'abord : refuser sans le lire fait couper la connexion sous Windows.
            limit = 40_000_000 if urlparse(self.path).path in ("/api/gpx", "/api/import") else 100_000   # GPX, transfert : gros
            try:
                length = min(int(self.headers.get("Content-Length", 0)), limit)
            except ValueError:
                length = 0
            raw = self.rfile.read(length) if length else b""
            if not self._allowed_host():
                return self._send(403, {"error": "Hôte refusé"})
            # Un site extérieur ne peut pas envoyer de JSON ici sans autorisation du navigateur.
            if not self.headers.get("Content-Type", "").startswith("application/json"):
                return self._send(415, {"error": "JSON attendu"})
            origin = self.headers.get("Origin")
            if origin and origin not in (f"http://127.0.0.1:{port_ref[0]}", f"http://localhost:{port_ref[0]}"):
                return self._send(403, {"error": "Origine refusée"})
            try:
                body = json.loads(raw or b"{}")
                if not isinstance(body, dict):
                    raise ApiError(400, "Objet JSON attendu")
                path = urlparse(self.path).path
                status, payload = api_call(app, "POST", self.path, body)
                return self._send(status, payload)
            except json.JSONDecodeError:
                return self._send(400, {"error": "JSON invalide"})
            except ApiError as e:
                return self._send(e.status, {"error": str(e)})
            except Exception as e:
                return self._internal(e)

        def _static(self, path: str):
            name = "index.html" if path in ("", "/") else path.lstrip("/")
            target = (WEB / name).resolve()
            if WEB.resolve() not in target.parents or not target.is_file():
                return self._send(404, {"error": "Introuvable"})
            ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype.endswith("javascript"):
                ctype += "; charset=utf-8"
            return self._send(200, target.read_bytes(), ctype)

    return Handler


class _Server(ThreadingHTTPServer):
    # Sous Windows, « réutiliser l'adresse » permettrait à DEUX serveurs d'écouter le même port :
    # on l'interdit, pour qu'un second lancement échoue proprement.
    allow_reuse_address = sys.platform != "win32"


def serve(app: App, port: int = 0) -> ThreadingHTTPServer:
    """Démarre le serveur sur 127.0.0.1 (port libre si 0) dans un fil séparé.
    Lève OSError si le port est déjà occupé."""
    port_ref = [port]
    httpd = _Server(("127.0.0.1", port), make_handler(app, port_ref))
    port_ref[0] = httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


def _open_window(url: str) -> None:
    """Fenêtre d'application Edge (sans barre d'adresse) si possible, sinon le navigateur par défaut."""
    candidates = [shutil.which("msedge")] + [
        Path(os.environ.get(v, "")) / "Microsoft/Edge/Application/msedge.exe"
        for v in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
    for c in candidates:
        if c and Path(c).is_file():
            subprocess.Popen([str(c), f"--app={url}", "--window-size=1460,900"])
            return
    webbrowser.open(url)


def run(argv: list[str]) -> None:
    import argparse
    p = argparse.ArgumentParser(prog="python -m ascend app", description="Lance l'application ASCEND")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--data", type=Path, default=default_data_dir(), help="dossier de la base de données")
    p.add_argument("--sauvegardes", type=Path, default=None, help="dossier des sauvegardes quotidiennes")
    p.add_argument("--sans-fenetre", action="store_true", help="ne pas ouvrir de fenêtre")
    p.add_argument("--mode-test", action="store_true", help="phase de test : changements de classe illimités")
    a = p.parse_args(argv)
    a.data.mkdir(parents=True, exist_ok=True)
    try:
        probe = _Server(("127.0.0.1", a.port), BaseHTTPRequestHandler)
        probe.server_close()
    except OSError:
        url = f"http://127.0.0.1:{a.port}/"
        print(f"ASCEND est déjà lancé : {url}")
        print("La fenêtre existante est rouverte. Tu peux fermer celle-ci.")
        if not a.sans_fenetre:
            _open_window(url)
        return
    app = App(a.data / "ascend.db", test_mode=a.mode_test, backup_dir=a.sauvegardes or a.data / "sauvegardes")
    saved = app.backup()
    if a.mode_test:
        print("MODE TEST : changements de classe illimités.")
    httpd = serve(app, a.port)
    url = f"http://127.0.0.1:{httpd.server_address[1]}/"
    print(f"ASCEND est lancé : {url}")
    print(f"Données : {a.data / 'ascend.db'}")
    if saved:
        print(f"Sauvegarde du jour : {saved}")
    print("Ferme cette fenêtre ou appuie sur Ctrl+C pour arrêter.")
    if not a.sans_fenetre:
        _open_window(url)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        httpd.shutdown()
