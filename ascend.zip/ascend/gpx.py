"""Import de traces GPX : la première vraie preuve.

Le fichier est lu sur le PC, jamais envoyé ailleurs, et n'est pas conservé : seul le résumé
(distance, dénivelé, durée, date) est gardé, avec un jeton de preuve à usage unique.
Une trace peut toujours être fabriquée, mais il faut au moins un fichier cohérent :
points horodatés dans l'ordre, vitesses plausibles.
"""
import math
import xml.etree.ElementTree as ET
from datetime import datetime

MAX_BYTES = 15_000_000
MIN_POINTS = 20
MAX_SEGMENT_KMH = 250.0        # au-delà : saut de GPS ou trace fabriquée
ELEVATION_STEP_M = 3.0         # lissage : on ignore les variations de moins de 3 m


def _haversine_km(a, b) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * math.asin(min(1.0, math.sqrt(h)))


def _time(text: str | None) -> datetime | None:
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.strip().replace("Z", "+00:00"))
    except ValueError:
        return None


def parse(text: str) -> dict:
    """Résumé d'une trace GPX. Lève ValueError (message clair) si le fichier n'est pas exploitable."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Fichier GPX vide")
    if len(text.encode("utf-8", "ignore")) > MAX_BYTES:
        raise ValueError("Fichier GPX trop gros (15 Mo au plus)")
    head = text[:2000].upper()
    if "<!DOCTYPE" in head or "<!ENTITY" in head:
        raise ValueError("Fichier GPX refusé : il contient des déclarations non autorisées")
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        raise ValueError("Ce fichier n'est pas un GPX valide")
    if not root.tag.lower().endswith("gpx"):
        raise ValueError("Ce fichier n'est pas un GPX")
    pts = []
    for el in root.iter():
        if not (el.tag.endswith("trkpt") or el.tag.endswith("rtept")):
            continue
        try:
            lat, lon = float(el.get("lat")), float(el.get("lon"))
        except (TypeError, ValueError):
            continue
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            continue
        ele = tm = None
        for c in el:
            if c.tag.endswith("ele"):
                try:
                    ele = float(c.text)
                except (TypeError, ValueError):
                    pass
            elif c.tag.endswith("time"):
                tm = _time(c.text)
        pts.append((lat, lon, ele, tm))
    if len(pts) < MIN_POINTS:
        raise ValueError(f"Trace trop courte : {len(pts)} points (il en faut au moins {MIN_POINTS})")
    timed = [p for p in pts if p[3] is not None]
    if len(timed) < MIN_POINTS:
        raise ValueError("Trace sans horodatage : impossible de vérifier la durée et la date")
    dist, gain, fastest = 0.0, 0.0, 0.0
    last_ele = None
    for a, b in zip(timed, timed[1:]):
        seg = _haversine_km(a, b)
        dt = (b[3] - a[3]).total_seconds()
        if dt < 0:
            raise ValueError("Trace incohérente : les heures des points ne sont pas dans l'ordre")
        if dt > 0:
            fastest = max(fastest, seg / (dt / 3600))
        dist += seg
    if fastest > MAX_SEGMENT_KMH:
        raise ValueError(f"Trace incohérente : une portion à {fastest:.0f} km/h")
    for p in timed:
        if p[2] is None:
            continue
        if last_ele is None:
            last_ele = p[2]
        elif abs(p[2] - last_ele) >= ELEVATION_STEP_M:
            gain += max(0.0, p[2] - last_ele)
            last_ele = p[2]
    minutes = (timed[-1][3] - timed[0][3]).total_seconds() / 60
    if minutes <= 0:
        raise ValueError("Trace incohérente : durée nulle")
    start = timed[0][3]
    return {"distance_km": round(dist, 2), "elevation_m": round(gain), "minutes": round(minutes, 1),
            "day": start.date().isoformat(), "points": len(timed),
            "speed_kmh": round(dist / (minutes / 60), 2), "max_speed_kmh": round(fastest, 1)}


def matches(summary: dict, data: dict) -> bool:
    """La saisie correspond-elle bien au résumé de la trace (petite tolérance d'arrondi) ?"""
    def close(a, b, tol):
        return a is not None and b is not None and abs(float(a) - float(b)) <= max(tol * abs(float(b)), 0.05)
    ok = close(data.get("distance_km"), summary["distance_km"], 0.01)
    if "elevation_m" in data:
        ok = ok and close(data.get("elevation_m"), summary["elevation_m"], 0.05)
    if "minutes" in data:
        ok = ok and close(data.get("minutes"), summary["minutes"], 0.02)
    return ok
