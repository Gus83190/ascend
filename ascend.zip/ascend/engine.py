"""Moteur d'XP : transforme une activité réelle en XP, avec explication.

Principes
- La présence vaut très peu ; l'XP vient de l'effort mesuré et surtout de la
  progression par rapport à SA propre référence récente.
- Ce qui n'est pas vérifiable (lecture sans quiz) rapporte presque rien.
- Un plafond quotidien par stat évite de monter en rang en une journée.
- Une progression irréaliste est plafonnée (anti-triche).
"""
from dataclasses import dataclass, field
from datetime import date, time, datetime, timedelta
from statistics import median

from . import config as C
from . import catalog as K
from . import trials as T
from .discipline import DisciplineTracker
from .ranks import rank_for, level_for, global_rank, progress_to_next


@dataclass
class XPResult:
    stat: str
    raw: float
    granted: float
    notes: list[str]


@dataclass
class Hero:
    name: str = "Aria"
    bodyweight: float = 62.0
    stat_xp: dict[str, float] = field(default_factory=lambda: {s: 0.0 for s in C.STATS})
    daily_xp: dict[tuple[date, str], float] = field(default_factory=dict)
    weekly_xp: dict[tuple[tuple[int, int], str], float] = field(default_factory=dict)
    progress_log: dict[str, list[tuple[date, float]]] = field(default_factory=dict)
    refs: dict[str, list[tuple[date, float]]] = field(default_factory=dict)  # historique de référence
    bedtimes: list[tuple[date, int, str | None]] = field(default_factory=list)  # (jour, minutes depuis 18 h, poste)
    discipline: DisciplineTracker = field(default_factory=DisciplineTracker)
    seen_places: set[str] = field(default_factory=set)
    verified_hist: dict[str, list[tuple[date, dict]]] = field(default_factory=dict)  # saisies prouvées
    unverified_dates: dict[str, list[date]] = field(default_factory=dict)           # saisies sans preuve
    unverified_weekly: dict[tuple[tuple[int, int], str], float] = field(default_factory=dict)
    best_sets: dict[tuple[str, str], float] = field(default_factory=dict)        # (famille, variante) → meilleure série
    jump_claims: dict[str, list[tuple[date, float]]] = field(default_factory=dict)  # sauts en attente de confirmation
    assessed: set[str] = field(default_factory=set)   # stats déjà évaluées au départ
    hero_class: str = "Équilibré"
    trials_passed: set[tuple[str, str]] = field(default_factory=set)          # (stat, rang)
    trial_marks: set[tuple[str, str, str]] = field(default_factory=set)       # critères d'épreuve réussis
    sleep_scores: list[tuple[date, float]] = field(default_factory=list)      # note de chaque nuit /100
    works: dict[str, date] = field(default_factory=dict)                      # œuvres validées par quiz
    meditation_days: set[date] = field(default_factory=set)
    validated_books: dict[str, tuple[date, float]] = field(default_factory=dict)   # work_id → (jour, score du quiz)
    # Profil (ajuste les épreuves A/S) : année de naissance, sexe, profil aménagé.
    birth_year: int | None = None
    sex: str | None = None
    adapted: bool = False
    conditions: list[str] = field(default_factory=list)            # profil santé (voir health.py)
    placements: dict[str, dict] = field(default_factory=dict)      # évaluations de départ (questionnaires, quiz)
    subject_levels: dict[str, str] = field(default_factory=dict)   # palier actuel par matière (cursus)
    # Inactivité et convalescence.
    as_of: date | None = None                                       # date de relecture (« aujourd'hui »)
    last_active: dict[str, date] = field(default_factory=dict)      # dernière activité acceptée par stat
    wake: dict[str, list[date]] = field(default_factory=dict)       # séances du test de retour
    convalescence: dict[str, tuple[date, str]] = field(default_factory=dict)   # stat gelée → (début, raison)
    conva_end: dict[str, date] = field(default_factory=dict)        # fin de la dernière convalescence

    @property
    def total_xp(self) -> float:
        return sum(self.stat_xp.values())

    @property
    def level(self) -> int:
        return level_for(self.total_xp)

    def age(self, today: date | None = None) -> int | None:
        today = today or self.as_of or date.today()
        return today.year - self.birth_year if self.birth_year else None

    def inactive_days(self, stat: str, today: date | None = None) -> int | None:
        """Jours sans activité sur la stat (convalescence exclue) ; None si jamais pratiquée."""
        today = today or self.as_of
        if today is None or stat in self.convalescence:
            return None
        last = max((d for d in (self.last_active.get(stat), self.conva_end.get(stat)) if d), default=None)
        return None if last is None else (today - last).days

    def is_dormant(self, stat: str, today: date | None = None) -> bool:
        """Stat « en sommeil » : plus de DORMANT_DAYS jours sans activité, avec un rang au-dessus de E."""
        days = self.inactive_days(stat, today)
        return days is not None and days > self.dormant_days and rank_for(self.stat_xp[stat]) != "E"

    @property
    def dormant_days(self) -> int:
        from . import health as HL
        return HL.dormant_days(T.health_ids(self), C.DORMANT_DAYS)

    def earned_rank(self, stat: str) -> str:
        """Rang acquis (XP + épreuves), sans tenir compte de la mise en sommeil."""
        return T.cap(self, stat, rank_for(self.stat_xp[stat]))

    def rank_of(self, stat: str) -> str:
        """Rang affiché d'une stat : celui de l'XP, plafonné tant que l'épreuve A ou S manque,
        et d'un cran plus bas si la stat est en sommeil (plus de 3 mois sans activité)."""
        shown = self.earned_rank(stat)
        if self.is_dormant(stat):
            shown = C.RANKS[max(0, C.RANKS.index(shown) - 1)]
        return shown

    @property
    def rank(self) -> str:
        """Rang global : moyenne des rangs des stats, pondérée par les coefficients de la classe."""
        weights = C.CLASSES.get(self.hero_class, {})
        total = sum(weights.get(s, 1.0) for s in C.STATS)
        avg = sum(weights.get(s, 1.0) * C.RANKS.index(self.rank_of(s)) for s in C.STATS) / total
        return C.RANKS[int(avg + 1e-9)]


# ------------------------------------------------------------------ outils

def _baseline(hero: Hero, key: str, today: date) -> float | None:
    vals = [v for d, v in hero.refs.get(key, []) if 0 < (today - d).days <= C.BASELINE_DAYS]
    return max(vals) if vals else None


def _progress_bonus(hero: Hero, key: str, value: float, today: date, max_bonus: float,
                    notes: list[str], label: str, scale: float = 1.0) -> float:
    base = _baseline(hero, key, today)
    first, keep = 15.0 * scale, 10.0 * scale
    if base is not None and base <= 0:
        base = None                           # une référence nulle ne sert pas de comparaison
    if value <= 0:
        notes.append(f"{label} : valeur nulle, pas de comparaison")
        return 0.0
    if base is None:
        hero.refs.setdefault(key, []).append((today, value))
        notes.append(f"{label} : première référence enregistrée (+{first:.0f})")
        return first
    delta = value / base - 1
    log_ = hero.progress_log.setdefault(key, [])
    week = sum(x for d, x in log_ if 0 <= (today - d).days < 7)
    month = sum(x for d, x in log_ if 0 <= (today - d).days < 28)
    allowed = min(C.MAX_PROGRESS_PER_SESSION, C.MAX_PROGRESS_PER_WEEK - week, C.MAX_PROGRESS_PER_28D - month)
    credited = max(0.0, min(delta, allowed))
    if delta > credited + 1e-9 and delta > 0.002:
        notes.append(f"{label} : +{delta:.1%} annoncé, +{credited:.1%} crédité (plafonds de progression)")
    # La référence ne monte que de ce qui est crédité : impossible de la gonfler.
    hero.refs.setdefault(key, []).append((today, base * (1 + credited) if delta > 0 else value))
    if credited > 0.002:
        log_.append((today, credited))
        bonus = credited / C.MAX_PROGRESS_PER_SESSION * max_bonus
        notes.append(f"{label} : +{credited:.1%} vs ta meilleure référence (+{bonus:.0f})")
        return bonus
    if delta >= -0.05:
        notes.append(f"{label} : niveau maintenu (+{keep:.0f})")
        return keep
    notes.append(f"{label} : en retrait, pas de bonus")
    return 0.0


def _cap(used: float, raw: float, full: float, soft: float) -> tuple[float, float]:
    take = min(raw, max(0.0, full - used))
    rest = raw - take
    soft_room = max(0.0, soft - max(used + take, full))
    extra = min(rest * C.SOFT_RATE, soft_room)
    granted = take + extra
    return granted, used + granted


def _cap_daily(hero: Hero, stat: str, today: date, raw: float, notes: list[str]) -> float:
    full, soft = C.DAILY_CAP_OVERRIDES.get(stat, (C.DAILY_FULL_XP, C.DAILY_SOFT_XP))
    g1, u1 = _cap(hero.daily_xp.get((today, stat), 0.0), raw, full, soft)
    wk = (today.isocalendar()[0], today.isocalendar()[1])
    g2, u2 = _cap(hero.weekly_xp.get((wk, stat), 0.0), g1, C.WEEKLY_FULL_XP, C.WEEKLY_SOFT_XP)
    hero.daily_xp[(today, stat)] = hero.daily_xp.get((today, stat), 0.0) + g2
    hero.weekly_xp[(wk, stat)] = u2
    if g2 < raw - 0.5:
        why = "quotidien" if g1 < raw - 0.5 else "hebdomadaire"
        notes.append(f"Plafond {why} {stat} : {g2:.0f} XP sur {raw:.0f}")
    return g2


# ------------------------------------------------------------------ calculs par activité

def strength(hero: Hero, today: date, exercise: str, sets: list[tuple[float, int]]):
    notes: list[str] = []
    key = f"1rm:{exercise}"
    base = _baseline(hero, key, today)
    work, rejected = [], 0
    for w, r in sets:
        if r < 3:
            continue
        e1 = w * (1 + min(r, 12) / 30)                       # Epley, 12 reps max
        if base is not None and e1 > base * (1 + C.IMPLAUSIBLE_JUMP):
            rejected += 1
            continue
        work.append((w, r, e1))
    if rejected:
        notes.append(f"{rejected} série(s) jugée(s) irréaliste(s) (+{C.IMPLAUSIBLE_JUMP:.0%} vs ta référence) : non comptées")
    volume = sum(w * r for w, r, _ in work)
    ratio = volume / hero.bodyweight
    if ratio < C.MIN_VOLUME_RATIO:
        notes.append("Volume trop faible pour compter comme séance (pas de XP de présence)")
        return "Force", 0.0, notes
    effort = min(50.0, ratio * 2)
    xp = 8.0 + effort
    notes.append(f"Présence +8, effort (volume {volume:.0f} kg) +{effort:.0f}")
    xp += _progress_bonus(hero, key, max(e for *_, e in work), today, 100.0, notes, f"{exercise} 1RM estimé")
    return "Force", xp, notes


def bodyweight(hero: Hero, today: date, family: str, variant: str, sets: list[float]):
    """Exercice à variantes (Force au poids du corps, Agilité) : une variante du catalogue,
    une liste de séries (répétitions, ou secondes). Toutes les variantes sont ouvertes."""
    notes: list[str] = []
    stat = K.FAMILIES[family]["stat"]
    v = K.variant(family, variant)
    unit = "s" if K.FAMILIES[family]["unit"] == "s" else "rép."
    key = f"pdc:{family}"
    base = _baseline(hero, key, today)
    equiv, counted, claimed, best = 0.0, [], [], 0.0
    for amount in sets:
        cap = K.capacity(family, variant, amount)
        if base is not None and cap > base * (1 + C.IMPLAUSIBLE_JUMP):
            claimed.append((cap, amount))         # saut improbable : compté à moitié, à confirmer
            equiv += amount * v.coef * C.JUMP_PARTIAL_RATE
        else:
            counted.append(cap)
            equiv += amount * v.coef
            best = max(best, amount)              # seules les séries non contestées comptent pour la maîtrise
    k = (family, variant)
    hero.best_sets[k] = max(hero.best_sets.get(k, 0), best)
    if equiv < C.BW_MIN_EQUIV.get(K.FAMILIES[family]["unit"], 10):
        notes.append("Volume trop faible pour compter comme exercice (pas de XP de présence)")
        return stat, 0.0, notes
    effort = min(C.BW_EFFORT_MAX, equiv * C.BW_EFFORT_RATE)
    xp = C.BW_PRESENCE + effort
    notes.append(f"{v.name} {'/'.join(str(int(s)) for s in sets)} {unit} : présence +{C.BW_PRESENCE:.0f}, effort +{effort:.0f}")
    if claimed:
        top_cap, top_amount = max(claimed)
        xp += _confirm_jump(hero, key, today, top_cap, notes, {k: top_amount})
        best = hero.best_sets.get(k, 0)
    if counted:
        xp += _progress_bonus(hero, key, max(counted), today, C.BW_PROGRESS_MAX, notes,
                              f"Capacité {family}", scale=C.BW_BONUS_SCALE)
    if hero.best_sets.get(k, 0) >= v.mastery and best >= v.mastery:
        nxt = suggest(hero, family)
        notes.append(f"Variante maîtrisée ({v.mastery} {unit} d'affilée)" + (f" — suivante suggérée : {nxt.name}" if nxt else ""))
    return stat, xp, notes


def _confirm_jump(hero: Hero, key: str, today: date, cap: float, notes: list[str],
                  pending_best: dict[tuple[str, str], float]) -> float:
    """Un niveau bien au-dessus de l'historique compte à moitié, puis devient la nouvelle
    référence s'il est retrouvé lors de plusieurs séances distinctes."""
    claims = hero.jump_claims.setdefault(key, [])
    claims.append((today, cap))
    days = {d for d, c in claims if 0 <= (today - d).days < C.JUMP_CONFIRM_DAYS and c >= cap * 0.97}
    if len(days) >= C.JUMP_CONFIRM_SESSIONS:
        hero.refs.setdefault(key, []).append((today, cap))
        for fam_var, amount in pending_best.items():
            hero.best_sets[fam_var] = max(hero.best_sets.get(fam_var, 0), amount)
        hero.jump_claims[key] = []
        notes.append(f"Nouveau niveau confirmé sur {len(days)} séances : il devient ta référence")
        return 0.0
    notes.append(f"Niveau bien au-dessus de ton historique : compté à moitié, à confirmer "
                 f"({len(days)}/{C.JUMP_CONFIRM_SESSIONS} séances)")
    return 0.0


def suggest(hero: Hero, family: str) -> "K.Variant | None":
    """Variante à travailler : la première au-dessus de la plus haute maîtrisée. Les variantes
    plus faciles que celle que tu pratiques déjà comptent comme maîtrisées."""
    variants = K.FAMILIES[family]["variants"]
    worked = max((i for i, v in enumerate(variants) if hero.best_sets.get((family, v.id), 0) > 0), default=-1)
    top = -1
    for i, v in enumerate(variants):
        if hero.best_sets.get((family, v.id), 0) >= v.mastery or i < worked:
            top = i
    return variants[top + 1] if top + 1 < len(variants) else None


def mastered(hero: Hero, family: str, variant_id: str) -> bool:
    """Maîtrisée : seuil atteint, ou plus facile qu'une variante déjà pratiquée."""
    variants = K.FAMILIES[family]["variants"]
    worked = max((i for i, v in enumerate(variants) if hero.best_sets.get((family, v.id), 0) > 0), default=-1)
    i = K.index_of(family, variant_id)
    return hero.best_sets.get((family, variant_id), 0) >= variants[i].mastery or i < worked


def assess(hero: Hero, today: date, results: dict[str, tuple[str, float]]) -> list[str]:
    """Évaluation de départ : pour chaque famille, (variante, max en une série).
    Fixe les références et place le héros à un rang de départ dans chaque stat
    concernée (B au maximum : A et S demandent une épreuve). Une fois par stat."""
    notes: list[str] = []
    if not isinstance(results, dict) or not results:
        raise ValueError("Renseigne au moins une famille")
    for family, pair in results.items():
        if family not in K.FAMILIES or not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise ValueError(f"Famille inconnue ou incomplète : {family}")
        try:
            K.variant(family, pair[0])
        except KeyError:
            raise ValueError(f"Variante inconnue pour {family}")
        hi = 600 if K.FAMILIES[family]["unit"] == "s" else 300
        _num({"a": pair[1]}, "a", f"Maximum ({family})", 0, hi)
    stats = {K.FAMILIES[f]["stat"] for f in results}
    if stats <= hero.assessed:
        return ["Évaluation de départ déjà faite"]
    for stat in sorted(stats - hero.assessed):
        levels = []
        for family in K.families_of(stat):
            if family not in results:
                levels.append(0.0)
                continue
            vid, amount = results[family]
            # Référence datée de la veille : la première séance du jour s'y compare déjà.
            hero.refs.setdefault(f"pdc:{family}", []).append((today - timedelta(days=1), K.capacity(family, vid, amount)))
            v = K.variant(family, vid)
            hero.best_sets[(family, vid)] = max(hero.best_sets.get((family, vid), 0), amount)
            # niveau = rang de la variante, + 0,5 si elle est déjà maîtrisée
            levels.append(K.index_of(family, vid) + (0.5 if amount >= v.mastery else 0.0))
            notes.append(f"{family} : {v.name}, {amount:.0f} → référence enregistrée")
        notes.append(f"{stat} : niveau moyen {sum(levels) / len(levels):.1f} → rang de départ "
                     f"{_place(hero, stat, sum(levels) / len(levels), C.ASSESS_START_RANK)}")
    return notes


def _place(hero: Hero, stat: str, value: float, table: list[tuple[str, float]]) -> str:
    """Place le héros au rang de départ que donne `value` (jamais au-dessus de B)."""
    start = "E"
    for rank, lvl in table:
        if value >= lvl:
            start = rank
    hero.stat_xp[stat] = max(hero.stat_xp[stat], float(C.RANK_THRESHOLDS[start]))
    hero.assessed.add(stat)
    return start


def assess_placement(hero: Hero, today: date, stat: str, score: float, detail: str = "") -> list[str]:
    """Évaluation de départ par questionnaire ou quiz (Vitalité, Intelligence, Mental, Expédition)."""
    from . import placement as PL
    if stat not in PL.CAP:
        raise ValueError(f"Pas d'évaluation par questionnaire pour {stat}")
    if stat in hero.assessed:
        return ["Évaluation de départ déjà faite"]
    _num({"s": score}, "s", "Score", 0, 1)
    start = PL.rank_for_score(stat, score)
    hero.stat_xp[stat] = max(hero.stat_xp[stat], float(C.RANK_THRESHOLDS[start]))
    hero.assessed.add(stat)
    hero.placements[stat] = {"day": today.isoformat(), "score": round(score, 3), "rank": start}
    cap = PL.CAP[stat]
    return [f"{stat} : {detail + ' · ' if detail else ''}score {score:.0%} → rang de départ {start}"
            + (f" (au plus {cap} pour une évaluation déclarative)" if cap != "B" else "")]


def assess_cooper(hero: Hero, today: date, meters: float) -> list[str]:
    """Évaluation de départ en Endurance : test de Cooper (distance courue en 12 min)."""
    if "Endurance" in hero.assessed:
        return ["Évaluation de départ déjà faite"]
    _num({"m": meters}, "m", "Distance du test de Cooper (m)", 500, 5000)
    speed = meters / 1000 / 0.2
    hero.refs.setdefault("vit:course:cooper", []).append((today, speed))   # test à part : ne fausse pas les allures
    start = _place(hero, "Endurance", meters, C.COOPER_START_RANK)
    return [f"Test de Cooper : {meters:.0f} m en 12 min ({speed:.1f} km/h) → référence enregistrée",
            f"Endurance : rang de départ {start}"]


def endurance(hero: Hero, today: date, distance_km: float, minutes: float, sport: str = "course"):
    """Endurance : course, marche rapide, vélo ou natation. Chaque sport a son coefficient
    d'intensité et ses propres références d'allure (on ne compare pas un vélo à une course)."""
    notes: list[str] = []
    if sport not in C.ENDURANCE_SPORTS:
        return "Endurance", 0.0, [f"Sport inconnu : {sport}"]
    coef, min_km, min_kmh, max_kmh, (b1, b2) = C.ENDURANCE_SPORTS[sport]
    if minutes < 15:
        return "Endurance", 0.0, ["Moins de 15 min : trop court pour compter"]
    speed = distance_km / (minutes / 60)
    if distance_km < min_km or speed < min_kmh:
        return "Endurance", 0.0, [f"{sport.capitalize()} : allure {speed:.1f} km/h ou distance trop faible pour compter"]
    if speed > max_kmh:
        return "Endurance", 0.0, [f"{sport.capitalize()} : allure {speed:.0f} km/h jugée irréaliste, non comptée"]
    xp = (15 + min(110.0, minutes * 2.0)) * coef
    notes.append(f"{sport.capitalize()} {minutes:.0f} min (intensité ×{coef}) : +{xp:.0f}")
    band = "court" if distance_km < b1 else "moyen" if distance_km < b2 else "long"
    xp += _progress_bonus(hero, f"vit:{sport}:{band}", speed, today, 80.0 * coef, notes,
                          f"Allure {sport} ({band})", scale=coef)
    return "Endurance", xp, notes


def sleep(hero: Hero, today: date, bedtime: time, hours: float, nap_minutes: float = 0,
          shift: str | None = None, parent: bool = False):
    """Vitalité : durée totale sur 24 h (siestes comprises) + régularité du coucher.
    - `shift` : type de poste (« matin », « nuit »…) ; la régularité est jugée par type de poste,
      donc dormir de 8 h à 15 h après une nuit de travail est régulier.
    - `parent` : mode jeune parent, la régularité est mise en pause, seule la durée compte."""
    notes: list[str] = []
    if any(d == today for d, _, _ in hero.bedtimes):
        return "Vitalité", 0.0, ["Une seule nuit compte par jour : celle-ci n'est pas comptée "
                                 "(modifie la première saisie si elle était fausse)"]
    total = hours + nap_minutes / 60
    dur = 50.0 if 7 <= total <= 9 else max(0.0, 50.0 - 25.0 * min(abs(total - 7) if total < 7 else total - 9, 2.0))
    minutes = (bedtime.hour * 60 + bedtime.minute - 1080) % 1440   # recentré sur 18 h
    recent = [m for d, m, s in hero.bedtimes if 0 < (today - d).days <= 14 and s == shift][-7:]
    hero.bedtimes.append((today, minutes, shift))
    if parent:
        reg = dur
        notes.append("Mode jeune parent : régularité en pause, la durée compte double")
    elif len(recent) >= 3:
        dev = min(abs(minutes - median(recent)), 1440 - abs(minutes - median(recent)))
        reg = 50.0 if dev <= 30 else 25.0 if dev <= 60 else 0.0
        poste = f" (poste {shift})" if shift else ""
        notes.append(f"Régularité{poste} : écart {dev:.0f} min → {reg:.0f} pts")
    else:
        reg = 25.0
        notes.append("Régularité : pas encore assez de nuits → 25 pts")
    sieste = f" dont {nap_minutes:.0f} min de sieste" if nap_minutes else ""
    notes.append(f"Durée {total:.1f} h sur 24 h{sieste} → {dur:.0f} pts")
    xp = (dur + reg) * 0.42
    hero.sleep_scores.append((today, dur + reg))
    notes.append(f"Nuit notée {dur + reg:.0f}/100 → +{xp:.0f} XP")
    return "Vitalité", xp, notes


def reading(hero: Hero, today: date, minutes: float, quiz: float | None = None, content: str = "livre",
            oeuvre: str | None = None, work_id: str | None = None):
    """Lecture au sens large : livre, manga, article, journal, revue de presse, livre audio,
    documentaire… Le coefficient tient compte de la densité du contenu.
    `oeuvre` : titre de l'œuvre terminée et validée par un quiz (compte pour l'épreuve A/S).
    `work_id` : œuvre de la banque de quiz. Sans score de quiz, la séance est EN ATTENTE :
    elle est créditée quand le quiz du livre est réussi (dans les 90 jours qui suivent)."""
    notes: list[str] = []
    if content not in C.READING_CONTENT:
        return "Intelligence", 0.0, [f"Type de contenu inconnu : {content}"]
    coef = C.READING_CONTENT[content]
    if quiz is None and work_id:
        done = hero.validated_books.get(work_id)
        if done and 0 <= (done[0] - today).days <= C.BOOK_PENDING_DAYS:
            quiz = done[1]
            notes.append("Lecture confirmée par le quiz du livre (réussi le "
                         f"{done[0].strftime('%d/%m/%Y')}) : séance créditée")
        else:
            full = min(150.0, minutes * 2.0) * coef
            low = full * C.BOOK_QUIZ_PASS / C.BOOK_QUIZ_QUESTIONS
            notes.append(f"En attente : de {low:.0f} à {full:.0f} XP (selon ton score) seront crédités quand tu "
                         f"réussiras le quiz de ce livre, dans les {C.BOOK_PENDING_DAYS} jours "
                         f"(avant les plafonds du jour et de la semaine)")
            return "Intelligence", 0.0, notes
    if quiz is None:
        # Non vérifiable = 0 XP : sinon +1/jour finit par donner un rang sur des années.
        notes.append("Lecture non vérifiée (pas de quiz) : 0 XP, fais le quiz pour la valider")
        return "Intelligence", 0.0, notes
    if quiz < 0.6:
        notes.append(f"Quiz {quiz:.0%} < 60 % : pas d'XP, relis et réessaie")
        return "Intelligence", 0.0, notes
    xp = min(150.0, minutes * 2.0) * (quiz - 0.5) / 0.5 * coef
    notes.append(f"{content.capitalize()} (×{coef}), {minutes:.0f} min, quiz {quiz:.0%} : +{xp:.0f}")
    return "Intelligence", xp, notes


def homework(hero: Hero, today: date, ai_score: float, difficulty: float = 1.0, subject: str | None = None,
             quiz_id: str | None = None, exam: bool = False):
    """Devoir : noté par le quiz de matière (score de 0 à 1), pondéré par le niveau."""
    xp = 70.0 * max(0.0, ai_score - 0.4) / 0.6 * difficulty
    what = (f"Examen de passage de {subject}" if exam else f"Quiz de {subject}") if subject else "Devoir"
    coef = f"{difficulty:g}".replace(".", ",")
    return "Intelligence", xp, [f"{what} réussi à {ai_score:.0%} (difficulté ×{coef}) : +{xp:.0f}"]


def english(hero: Hero, today: date, n: int, score: float, level: str = "B1", language: str = "anglais"):
    """Exercices de langue, valorisés selon le niveau du cadre européen (A1 → C2)."""
    if level not in C.LANGUAGE_LEVELS:
        return "Intelligence", 0.0, [f"Niveau inconnu : {level}"]
    coef = C.LANGUAGE_LEVELS[level]
    xp = n * 2.5 * score * coef if score >= 0.5 else 0.0
    return "Intelligence", xp, [f"{language.capitalize()} niveau {level} (×{coef}) : {n} exercices à {score:.0%} : +{xp:.0f}"]


def focus(hero: Hero, today: date, minutes: float, interruptions: int = 0):
    xp = min(100.0, minutes * 0.9) * (1 - min(0.5, interruptions * 0.1))
    return "Mental", xp, [f"Focus {minutes:.0f} min, {interruptions} interruption(s) : +{xp:.0f}"]


def meditation(hero: Hero, today: date, minutes: float, style: str = "guidée"):
    if style not in C.MEDITATION_STYLES:
        return "Mental", 0.0, [f"Style inconnu : {style}"]
    coef = C.MEDITATION_STYLES[style]
    xp = min(40.0, minutes * 2.0) * coef
    return "Mental", xp, [f"Méditation {style} (×{coef}) {minutes:.0f} min : +{xp:.0f}"]


def journal(hero: Hero, today: date, ai_ok: bool):
    """Journal : l'IA vérifie seulement que l'entrée est réelle et réfléchie ; le texte reste local."""
    if not ai_ok:
        return "Mental", 0.0, ["Entrée de journal trop courte ou vide : pas d'XP"]
    return "Mental", C.JOURNAL_XP, [f"Entrée de journal réfléchie : +{C.JOURNAL_XP:.0f}"]


def discomfort(hero: Hero, today: date, seconds: float, kind: str = "douche froide"):
    """Exposition volontaire à l'inconfort (douche froide…). Déclaratif : XP modeste."""
    xp = min(C.DISCOMFORT_MAX_XP, seconds / 10)
    return "Mental", xp, [f"{kind.capitalize()} {seconds:.0f} s : +{xp:.0f}"]


def expedition(hero: Hero, today: date, distance_km: float, elevation_m: float, place: str | None = None,
               cotation: str = "T2"):
    """Expédition : randonnée (cotation T1 → T6), trek, vélo, ou exploration « urbain »."""
    notes: list[str] = []
    if cotation not in C.EXPEDITION_COTATION:
        return "Expédition", 0.0, [f"Cotation inconnue : {cotation}"]
    coef = C.EXPEDITION_COTATION[cotation]
    xp = min(450.0, (distance_km * 11 + elevation_m * 0.28) * coef)
    notes.append(f"{distance_km:.0f} km, {elevation_m:.0f} m D+, {cotation} (×{coef}) : +{xp:.0f}")
    if place and place not in hero.seen_places:
        hero.seen_places.add(place)
        xp += 30
        notes.append(f"Nouveau lieu « {place} » : +30")
    return "Expédition", xp, notes


def mobility(hero: Hero, today: date, minutes: float, score: float | None = None):
    notes: list[str] = []
    xp = min(110.0, minutes * 4.5)
    notes.append(f"Mobilité {minutes:.0f} min : +{xp:.0f}")
    if score is not None:
        xp += _progress_bonus(hero, "mob", score, today, 30.0, notes, "Test de mobilité")
    return "Agilité", xp, notes


ACTIVITIES = {
    "strength": strength, "bodyweight": bodyweight, "skill": bodyweight, "endurance": endurance, "sleep": sleep, "reading": reading,
    "homework": homework, "english": english, "language": english, "focus": focus, "meditation": meditation,
    "journal": journal, "discomfort": discomfort,
    "expedition": expedition, "mobility": mobility,
}


def _verification_level(hero: Hero, today: date, kind: str, data: dict, proof: str | None) -> str:
    if kind in C.SELF_VERIFIED or proof:
        hero.verified_hist.setdefault(kind, []).append((today, data))
        return "vérifié"
    rule = C.PLAUSIBILITY.get(kind)
    dates = hero.unverified_dates.setdefault(kind, [])
    recent = sum(1 for d in dates if 0 <= (today - d).days < 7)
    dates.append(today)
    if rule is None:
        return "déclaré"
    defaults, max_per_week = rule
    if data.get("cotation") in C.COTATION_NEEDS_PROOF:
        return "déclaré"                              # haute montagne sans trace : on ne peut pas juger
    verified = [v for d, v in hero.verified_hist.get(kind, []) if 0 <= (today - d).days <= C.BASELINE_DAYS]
    for f, ceiling in defaults.items():
        best = max((v.get(f, 0) for v in verified), default=0)
        if data.get(f, 0) > max(ceiling, best * 1.5):
            return "déclaré"
    return "plausible" if recent < max_per_week else "déclaré"


def _apply_verification(hero: Hero, today: date, kind: str, stat: str, raw: float,
                        data: dict, proof: str | None, notes: list[str]) -> float:
    if stat in C.VERIFICATION_EXEMPT or raw <= 0:
        return raw
    level = _verification_level(hero, today, kind, data, proof)
    if level == "vérifié":
        if proof:
            notes.append(f"Preuve : {proof} → XP pleine")
        return raw
    rate = C.PLAUSIBLE_RATE_OVERRIDES.get(stat, C.VERIFICATION_RATES[level]) if level == "plausible" \
        else C.VERIFICATION_RATES[level]
    xp = raw * rate
    why = "cohérent et à une fréquence réaliste" if level == "plausible" else "hors des limites habituelles ou trop fréquent"
    notes.append(f"Sans preuve, {why} : {rate:.0%} de l'XP")
    if stat not in C.UNVERIFIED_CAP_EXEMPT:
        wk = (today.isocalendar()[0], today.isocalendar()[1])
        used = hero.unverified_weekly.get((wk, stat), 0.0)
        allowed = max(0.0, C.UNVERIFIED_WEEKLY_CAP - used)
        if xp > allowed:
            notes.append(f"Plafond hebdomadaire sans preuve atteint ({C.UNVERIFIED_WEEKLY_CAP} XP) : ajoute une preuve pour compter davantage")
            xp = allowed
        hero.unverified_weekly[(wk, stat)] = used + xp
    return xp


# ------------------------------------------------------------------ validation des saisies

KIND_STAT = {"strength": "Force", "bodyweight": None, "skill": None, "endurance": "Endurance", "sleep": "Vitalité",
             "reading": "Intelligence", "homework": "Intelligence", "english": "Intelligence",
             "language": "Intelligence", "focus": "Mental", "meditation": "Mental", "journal": "Mental",
             "discomfort": "Mental", "expedition": "Expédition", "mobility": "Agilité"}


def stat_of(kind: str, data: dict) -> str:
    if kind in ("bodyweight", "skill"):
        return K.FAMILIES.get(data.get("family"), {}).get("stat", "Force")
    return KIND_STAT.get(kind, "Force")


def _num(data: dict, name: str, label: str, lo: float, hi: float, required: bool = True, integer: bool = False):
    v = data.get(name)
    if v is None:
        if required:
            raise ValueError(f"{label} : valeur manquante")
        return
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or v in (float("inf"), float("-inf")):
        raise ValueError(f"{label} : nombre attendu")
    if not lo <= v <= hi:
        raise ValueError(f"{label} : doit être entre {lo:g} et {hi:g}")
    if integer and v != int(v):
        raise ValueError(f"{label} : nombre entier attendu")


def _text(data: dict, name: str, label: str, max_len: int, required: bool = False):
    v = data.get(name)
    if v is None and not required:
        return
    if not isinstance(v, str) or (required and not v.strip()) or len(v) > max_len:
        raise ValueError(f"{label} : texte de {max_len} caractères au plus attendu")


def validate(kind: str, data: dict) -> None:
    """Refuse les saisies impossibles (négatives, infinies, hors bornes, mauvais type) avec un
    message clair. Les bornes sont larges : elles écartent les erreurs, pas les exploits."""
    if kind not in ACTIVITIES:
        raise ValueError(f"Activité inconnue : {kind}")
    if not isinstance(data, dict):
        raise ValueError("Données de saisie invalides")
    if kind == "strength":
        _text(data, "exercise", "Exercice", 60, required=True)
        sets = data.get("sets")
        if not isinstance(sets, (list, tuple)) or not 1 <= len(sets) <= 30:
            raise ValueError("Séries : entre 1 et 30 séries « charge x répétitions »")
        for s in sets:
            if not isinstance(s, (list, tuple)) or len(s) != 2:
                raise ValueError("Séries : chaque série s'écrit « charge x répétitions »")
            _num({"w": s[0], "r": s[1]}, "w", "Charge (kg)", 0, 1000)
            _num({"w": s[0], "r": s[1]}, "r", "Répétitions", 0, 1000, integer=True)
    elif kind in ("bodyweight", "skill"):
        fam = data.get("family")
        if fam not in K.FAMILIES:
            raise ValueError("Famille d'exercice inconnue")
        try:
            K.variant(fam, data.get("variant"))
        except KeyError:
            raise ValueError("Variante inconnue pour cette famille")
        sets = data.get("sets")
        if not isinstance(sets, (list, tuple)) or not 1 <= len(sets) <= 30:
            raise ValueError("Séries : entre 1 et 30 nombres (répétitions ou secondes)")
        hi = 3600 if K.FAMILIES[fam]["unit"] == "s" else 1000
        for s in sets:
            if s is None or isinstance(s, str):
                raise ValueError("Séries : écris des nombres séparés par des virgules (ex. 12, 10, 9)")
            _num({"x": s}, "x", "Série", 0, hi)
    elif kind == "endurance":
        _num(data, "distance_km", "Distance (km)", 0, 500)
        _num(data, "minutes", "Durée (min)", 0, 1440)
    elif kind == "sleep":
        if not isinstance(data.get("bedtime"), time):
            raise ValueError("Heure du coucher attendue (HH:MM)")
        _num(data, "hours", "Durée de la nuit (h)", 0, 24)
        _num(data, "nap_minutes", "Sieste (min)", 0, 600, required=False)
        _text(data, "shift", "Type de poste", 30)
    elif kind == "reading":
        _num(data, "minutes", "Durée (min)", 0, 1440)
        _num(data, "quiz", "Score du quiz", 0, 1, required=False)
        _text(data, "oeuvre", "Œuvre", 120)
        _text(data, "work_id", "Livre", 80)
    elif kind == "homework":
        _num(data, "ai_score", "Note de l'IA", 0, 1)
        _num(data, "difficulty", "Difficulté", 0.5, 3, required=False)
        _text(data, "subject", "Matière", 60)
        _text(data, "quiz_id", "Quiz", 80)
    elif kind in ("english", "language"):
        _num(data, "n", "Nombre d'exercices", 0, 500, integer=True)
        _num(data, "score", "Score", 0, 1)
        _text(data, "language", "Langue", 40)
    elif kind == "focus":
        _num(data, "minutes", "Durée (min)", 0, 1440)
        _num(data, "interruptions", "Interruptions", 0, 100, required=False, integer=True)
    elif kind == "meditation":
        _num(data, "minutes", "Durée (min)", 0, 1440)
    elif kind == "journal":
        if not isinstance(data.get("ai_ok"), bool):
            raise ValueError("Journal : réponse oui ou non attendue")
    elif kind == "discomfort":
        _num(data, "seconds", "Durée (s)", 0, 3600)
        _text(data, "kind", "Type", 40)
    elif kind == "expedition":
        _num(data, "distance_km", "Distance (km)", 0, 500)
        _num(data, "elevation_m", "Dénivelé (m)", 0, 10000)
        _text(data, "place", "Lieu", 80)
    elif kind == "mobility":
        _num(data, "minutes", "Durée (min)", 0, 1440)
        _num(data, "score", "Score", 0, 100, required=False)


def _activity(hero: Hero, stat: str, today: date, notes: list[str]) -> None:
    """Suit l'activité d'une stat : une stat en sommeil se réveille après le test de retour
    (WAKE_SESSIONS séances, jours différents, en WAKE_DAYS jours)."""
    if not hero.is_dormant(stat, today):
        hero.last_active[stat] = max(today, hero.last_active.get(stat, today))
        return
    days = sorted({d for d in hero.wake.get(stat, []) if 0 <= (today - d).days < C.WAKE_DAYS} | {today})
    if len(days) >= C.WAKE_SESSIONS:
        hero.wake.pop(stat, None)
        hero.last_active[stat] = today
        notes.append(f"Test de retour réussi : {stat} se réveille, ton rang est rétabli")
    else:
        hero.wake[stat] = days
        notes.append(f"{stat} en sommeil : test de retour {len(days)} / {C.WAKE_SESSIONS} "
                     f"(séances sur des jours différents, en {C.WAKE_DAYS} jours)")


def log(hero: Hero, today: date, kind: str, proof: str | None = None, **data) -> XPResult:
    """`proof` : nature de la preuve jointe (\"gpx\", \"app\", \"téléphone\"…) ou None.
    Lève ValueError (message clair) si la saisie est impossible."""
    validate(kind, data)
    if proof is not None and (not isinstance(proof, str) or len(proof) > 30):
        raise ValueError("Preuve invalide")
    stat, raw, notes = ACTIVITIES[kind](hero, today, **data)
    raw = max(0.0, raw)                       # jamais d'XP négative
    checked = _apply_verification(hero, today, kind, stat, raw, data, proof, notes)
    granted = _cap_daily(hero, stat, today, checked, notes)
    if raw > 0:
        _activity(hero, stat, today, notes)
    hero.stat_xp[stat] += granted
    notes += T.update(hero, today, kind, data, proof, accepted=raw > 0, stat=stat)
    blk = T.blocker(hero, stat, rank_for(hero.stat_xp[stat]))
    if blk:
        notes.append(f"{stat} : assez d'XP pour le rang {rank_for(hero.stat_xp[stat])}, {blk['text']}")
    return XPResult(stat, raw, granted, notes)


def summary(hero: Hero, today: date) -> str:
    lines = [f"{hero.name} · niveau {hero.level} · rang global {hero.rank} · XP totale {hero.total_xp:,.0f}".replace(",", " ")]
    for s in C.STATS:
        cur, frac, left = progress_to_next(hero.stat_xp[s])
        shown = hero.rank_of(s)
        nxt = "max" if cur == "S" else f"{frac:>4.0%} vers {C.RANKS[C.RANKS.index(cur)+1]}"
        if shown != cur:
            nxt = f"épreuve du rang {'A' if shown == 'B' else 'S'} requise"
        lines.append(f"  {s:<13} {shown}  {hero.stat_xp[s]:>8,.0f} XP  ({nxt})".replace(",", " "))
    lines.append(f"  Discipline    {hero.discipline.value(today):.0f} %   série {hero.discipline.streak(today)} j")
    return "\n".join(lines)
