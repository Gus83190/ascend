"""Parcours de langues A1 → C2 (anglais, espagnol) : vocabulaire à réviser et tests de niveau.

Réussir le test d'un niveau (8 bonnes réponses sur 10) valide ce niveau ET tous ceux d'en dessous :
on peut viser directement son vrai niveau. Un test raté se repasse 3 jours plus tard ; les réponses
ne sont montrées qu'en cas de réussite, et les choix sont mélangés à chaque tirage.
"""
import json
import random
from datetime import date, timedelta

from .langues_data import LANGS

LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]
QUESTIONS = 10
PASS = 8
RETRY_DAYS = 3
SECONDS_PER_Q = 45
DESCRIPTIONS = {
    "A1": "Débutant : se présenter, phrases très simples.",
    "A2": "Élémentaire : vie quotidienne, passé simple, comparaisons.",
    "B1": "Seuil : raconter, donner son avis, conditionnel simple.",
    "B2": "Avancé : débattre, nuances, toutes les grandes structures.",
    "C1": "Autonome : registre soutenu, structures complexes.",
    "C2": "Maîtrise : expressions idiomatiques, finesse proche d'un natif.",
}


def _events(store, hero_id: int, today: date) -> list[tuple[date, dict]]:
    return [(date.fromisoformat(r["day"]), json.loads(r["payload"])) for r in store.db.execute(
        "SELECT day, payload FROM events WHERE hero_id=? AND type='langlevel' AND day<=? ORDER BY day, id",
        (hero_id, today.isoformat()))]


def status(store, hero_id: int, today: date) -> dict:
    evs = _events(store, hero_id, today)
    out = []
    for lang, levels in LANGS.items():
        best = None
        last_fail: dict[str, date] = {}
        history = []
        for d, p in evs:
            if p.get("lang") != lang or p.get("level") not in LEVELS:
                continue
            history.append({"day": d.isoformat(), "level": p["level"], "good": p.get("good"), "total": p.get("total"),
                            "passed": bool(p.get("passed")), "abandoned": bool(p.get("abandoned"))})
            if p.get("passed"):
                if best is None or LEVELS.index(p["level"]) > LEVELS.index(best):
                    best = p["level"]
                last_fail.pop(p["level"], None)
            else:
                last_fail[p["level"]] = d
        rows = []
        for lv in LEVELS:
            validated = best is not None and LEVELS.index(lv) <= LEVELS.index(best)
            nxt = last_fail[lv] + timedelta(days=RETRY_DAYS) if lv in last_fail else None
            rows.append({"level": lv, "desc": DESCRIPTIONS[lv], "validated": validated,
                         "available": not validated and (nxt is None or today >= nxt),
                         "retry": nxt.isoformat() if nxt and today < nxt else None,
                         "vocab": len(levels[lv]["vocab"])})
        out.append({"lang": lang, "label": lang.capitalize(), "level": best, "levels": rows, "history": history[::-1][:10]})
    return {"languages": out, "pass": PASS, "questions": QUESTIONS, "retry_days": RETRY_DAYS}


def check_available(store, hero_id: int, today: date, lang: str, level: str) -> None:
    if lang not in LANGS or level not in LEVELS:
        raise ValueError("Langue ou niveau inconnu")
    row = next(r for x in status(store, hero_id, today)["languages"] if x["lang"] == lang for r in x["levels"] if r["level"] == level)
    if row["validated"]:
        raise ValueError(f"Niveau {level} déjà validé")
    if not row["available"]:
        raise ValueError(f"Test raté récemment : tu pourras le repasser le {date.fromisoformat(row['retry']).strftime('%d/%m')}")


def draw(lang: str, level: str, rnd: random.Random | None = None) -> list[dict]:
    rnd = rnd or random.Random()
    items = rnd.sample(LANGS[lang][level]["test"], QUESTIONS)
    out = []
    for i, (q, choices, a) in enumerate(items):
        order = list(range(len(choices)))
        rnd.shuffle(order)
        out.append({"id": f"{lang}-{level}-{i}", "q": q, "choices": [choices[k] for k in order], "answer": order.index(a)})
    return out


def vocab(lang: str, level: str) -> list[tuple[str, str]]:
    if lang not in LANGS or level not in LEVELS:
        raise ValueError("Langue ou niveau inconnu")
    return list(LANGS[lang][level]["vocab"])
