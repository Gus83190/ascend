"""Bilans : semaine (XP, records, quêtes, Discipline, rangs) et historique des quêtes.

Tout est recalculé à partir du journal brut, comme le reste : un bilan reflète toujours
les saisies actuelles, corrections comprises.
"""
import json
from collections import Counter
from datetime import date, timedelta

from . import config as C
from .engine import XPResult
from .ranks import rank_for


def monday_of(day: date) -> date:
    return day - timedelta(days=day.weekday())


def _sum_by_stat(store, hero_id: int, captured: dict, start: date, end: date) -> tuple[dict, list]:
    """XP accordée par stat entre deux dates (incluses), et les saisies correspondantes."""
    xp = {s: 0.0 for s in C.STATS}
    rows = store.db.execute("SELECT * FROM events WHERE hero_id=? AND day BETWEEN ? AND ? ORDER BY day, id",
                            (hero_id, start.isoformat(), end.isoformat())).fetchall()
    for ev in rows:
        got = captured.get(ev["id"])
        if isinstance(got, XPResult):
            xp[got.stat] += got.granted
    return xp, rows


def week_report(store, hero_id: int, monday: date, today: date) -> dict:
    end = monday + timedelta(days=6)
    until = min(end, today)
    captured: dict = {}
    hero = store.hero(hero_id, until=until, capture=captured)
    xp, rows = _sum_by_stat(store, hero_id, captured, monday, end)
    prev, _ = _sum_by_stat(store, hero_id, captured, monday - timedelta(days=7), monday - timedelta(days=1))
    before, _ = _sum_by_stat(store, hero_id, captured, date(1970, 1, 1), monday - timedelta(days=1))

    kinds, records, trials, rejected = Counter(), [], [], 0
    active_days = set()
    for ev in rows:
        got = captured.get(ev["id"])
        if ev["type"] != "activity" or not isinstance(got, XPResult):
            continue
        kinds[json.loads(ev["payload"])["kind"]] += 1
        active_days.add(ev["day"])
        if got.raw <= 0:
            rejected += 1
        for n in got.notes:
            if "vs ta meilleure référence" in n:
                records.append(n)
            if n.startswith("Épreuve du rang"):
                trials.append(n)

    q = store.db.execute("SELECT status, reason, stat FROM quests WHERE hero_id=? AND day BETWEEN ? AND ?",
                         (hero_id, monday.isoformat(), end.isoformat())).fetchall()
    planned = sum(1 for r in q if r["status"] != "changée")
    done = sum(1 for r in q if r["status"] == "faite")
    swaps = Counter(r["reason"] for r in q if r["status"] == "changée")
    rests = store.db.execute("SELECT COUNT(DISTINCT day) FROM events WHERE hero_id=? AND type='rest' AND day BETWEEN ? AND ?",
                             (hero_id, monday.isoformat(), end.isoformat())).fetchone()[0]

    ranks_up = []
    for s in C.STATS:
        a, b = rank_for(before[s]), rank_for(before[s] + xp[s])
        if a != b:
            ranks_up.append({"stat": s, "from": a, "to": hero.rank_of(s) if b in ("A", "S") else b,
                             "trial_needed": hero.rank_of(s) != b})

    weights = C.CLASSES.get(hero.hero_class, {})
    total, total_prev = sum(xp.values()), sum(prev.values())
    return {
        "monday": monday.isoformat(), "sunday": end.isoformat(),
        "week": f"Semaine {monday.isocalendar()[1]} · du {monday.strftime('%d/%m/%Y')} au {end.strftime('%d/%m/%Y')}",
        "total": round(total), "total_prev": round(total_prev),
        "stats": [{"name": s, "xp": round(xp[s]), "prev": round(prev[s]), "rank": hero.rank_of(s),
                   "weight": weights.get(s, 1.0)} for s in C.STATS],
        "entries": sum(kinds.values()), "active_days": len(active_days), "rejected": rejected,
        "kinds": dict(kinds), "records": records, "trials": trials, "ranks_up": ranks_up,
        "quests": {"planned": planned, "done": done, "swaps": dict(swaps)},
        "rest_days": rests,
        "discipline": hero.discipline.value(until), "streak": hero.discipline.streak(until),
        "hero_class": hero.hero_class, "level": hero.level, "rank": hero.rank,
        "advice": _advice(xp, prev, weights, done, planned, rests, total),
    }


def _advice(xp: dict, prev: dict, weights: dict, done: int, planned: int, rests: int, total: float) -> list[str]:
    """Quelques conseils du Système, factuels et bienveillants (jamais culpabilisants)."""
    out = []
    if total == 0:
        return ["Semaine calme. Une seule séance suffit pour relancer la progression, sans pression."]
    fav = [s for s in C.STATS if weights.get(s, 1.0) > 1.0]
    neglected = [s for s in fav if xp[s] == 0]
    if neglected:
        out.append(f"Tes stats favorites de classe {', '.join(neglected)} n'ont rien reçu cette semaine : elles pèsent davantage dans ton rang global.")
    up = [s for s in C.STATS if xp[s] > prev[s] * 1.2 and xp[s] >= 50]
    if up:
        out.append(f"Belle progression en {', '.join(up)} par rapport à la semaine dernière.")
    zero = [s for s in C.STATS if xp[s] == 0 and s not in neglected]
    if zero and len(zero) <= 3:
        out.append(f"Aucune XP en {', '.join(zero)} : la quête du jour te les proposera plus souvent.")
    if planned and done / planned < 0.5:
        out.append("Moins de la moitié des quêtes faites : n'hésite pas à les changer (manque de temps, météo…) plutôt qu'à les laisser.")
    if rests == 0 and total > 0:
        out.append("Aucun jour de repos déclaré : récupérer fait aussi partie de la progression.")
    return out or ["Semaine équilibrée. Continue comme ça."]


def quest_history(store, hero_id: int, today: date, days: int = 28) -> dict:
    start = today - timedelta(days=days - 1)
    rows = store.db.execute("SELECT * FROM quests WHERE hero_id=? AND day BETWEEN ? AND ? ORDER BY day DESC, id",
                            (hero_id, start.isoformat(), today.isoformat())).fetchall()
    by_day: dict[str, list] = {}
    per_stat: dict[str, Counter] = {s: Counter() for s in C.STATS}
    reasons = Counter()
    for r in rows:
        by_day.setdefault(r["day"], []).append({"id": r["id"], "stat": r["stat"], "title": r["title"],
                                                "status": r["status"], "reason": r["reason"]})
        if r["status"] == "changée":
            reasons[r["reason"]] += 1
            continue
        per_stat[r["stat"]]["planned"] += 1
        if r["status"] == "faite":
            per_stat[r["stat"]]["done"] += 1
    rests = {e["day"] for e in store.db.execute(
        "SELECT DISTINCT day FROM events WHERE hero_id=? AND type='rest' AND day BETWEEN ? AND ?",
        (hero_id, start.isoformat(), today.isoformat()))}
    planned = sum(c["planned"] for c in per_stat.values())
    done = sum(c["done"] for c in per_stat.values())
    return {
        "days": [{"day": d, "rest": d in rests, "quests": qs} for d, qs in by_day.items()],
        "per_stat": [{"stat": s, "planned": c["planned"], "done": c["done"]} for s, c in per_stat.items()],
        "planned": planned, "done": done, "reasons": dict(reasons), "period_days": days,
    }
