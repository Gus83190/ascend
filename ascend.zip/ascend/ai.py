"""Quiz de lecture générés par Claude (API Anthropic, SDK officiel `anthropic`).

Optionnel : sans le SDK (`pip install anthropic`) ni identifiants, l'application fonctionne
et l'écran Quiz explique comment l'activer. Les identifiants sont lus comme le fait le SDK
(variable ANTHROPIC_API_KEY, ou profil `ant auth login`), ou dans un fichier `cle_api.txt`
placé dans le dossier des données d'ASCEND.

Données envoyées : uniquement le titre, l'auteur et la partie lue, avec le consentement du
joueur. Les questions sont générées en JSON validé (sortie structurée) ; les bonnes réponses
restent sur le PC et ne sont jamais envoyées à l'écran avant la correction.
"""
import json
from pathlib import Path

MODEL = "claude-opus-5-5"
N_QUESTIONS = 5

QUIZ_SCHEMA = {
    "type": "object",
    "properties": {
        "known": {"type": "boolean"},
        "reason": {"type": "string"},
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "choices": {"type": "array", "items": {"type": "string"}},
                    "answer": {"type": "integer"},
                },
                "required": ["question", "choices", "answer"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["known", "reason", "questions"],
    "additionalProperties": False,
}

PROMPT = """Tu prépares un quiz de lecture pour vérifier qu'une personne a vraiment lu un passage.

Œuvre : {title}
Auteur : {author}
Partie lue : {part}

Règles :
- Ne génère un quiz que si tu connais précisément cette œuvre ET cette partie. En cas de doute
  (œuvre peu connue, partie floue, risque d'inventer), réponds known=false avec une raison courte
  en français et une liste de questions vide. Mieux vaut refuser que poser une question fausse.
- Sinon, known=true et exactement {n} questions à choix multiples en français, chacune avec
  4 propositions et l'indice (0 à 3) de la bonne réponse dans "answer".
- Les questions portent sur des détails précis de CETTE partie (personnages, lieux, actions,
  objets), pas sur un résumé général que l'on trouve partout.
- Une seule bonne réponse par question, sans ambiguïté ; varie la position de la bonne réponse.
"""


class AIUnavailable(Exception):
    """L'IA n'est pas configurée sur ce PC (SDK absent ou pas d'identifiants)."""


def _client(data_dir: Path | None):
    try:
        import anthropic
    except ImportError:
        raise AIUnavailable("Le module « anthropic » n'est pas installé. Dans un terminal : pip install anthropic")
    key_file = Path(data_dir) / "cle_api.txt" if data_dir else None
    if key_file and key_file.is_file():
        return anthropic, anthropic.Anthropic(api_key=key_file.read_text(encoding="utf-8").strip())
    return anthropic, anthropic.Anthropic()


def status(data_dir: Path | None) -> dict:
    try:
        import anthropic  # noqa: F401
    except ImportError:
        return {"available": False, "reason": "Le module « anthropic » n'est pas installé (pip install anthropic)."}
    return {"available": True, "reason": ""}


def generate_quiz(title: str, author: str, part: str, data_dir: Path | None = None) -> dict:
    """Renvoie {"known": bool, "reason": str, "questions": [{question, choices, answer}]}.
    Lève AIUnavailable si l'IA n'est pas configurée, ValueError si la réponse est inexploitable."""
    anthropic, client = _client(data_dir)
    try:
        response = client.beta.messages.create(
            model=MODEL,
            max_tokens=16000,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",                                   # repli automatique en cas de refus
            output_config={"effort": "low", "format": {"type": "json_schema", "schema": QUIZ_SCHEMA}},
            messages=[{"role": "user", "content": PROMPT.format(title=title, author=author or "inconnu",
                                                                  part=part or "l'œuvre entière", n=N_QUESTIONS)}],
        )
    except anthropic.AuthenticationError:
        raise AIUnavailable("Clé d'API refusée : vérifie ANTHROPIC_API_KEY ou le fichier cle_api.txt.")
    except anthropic.PermissionDeniedError:
        raise AIUnavailable("Cette clé d'API n'a pas accès au modèle.")
    except anthropic.RateLimitError:
        raise ValueError("Trop de demandes en peu de temps : réessaie dans une minute.")
    except anthropic.APIStatusError as e:
        raise ValueError(f"Le service d'IA a répondu une erreur ({e.status_code}) : réessaie plus tard.")
    except anthropic.APIConnectionError:
        raise ValueError("Pas de connexion Internet : le quiz IA a besoin du réseau.")
    except anthropic.AnthropicError as e:   # p. ex. aucun identifiant trouvé
        raise AIUnavailable(f"IA non configurée : {e}")
    if response.stop_reason == "refusal":
        raise ValueError("Le service d'IA a refusé de créer ce quiz.")
    text = next((b.text for b in response.content if b.type == "text"), "")
    return check_quiz(json.loads(text))


def check_quiz(q: dict) -> dict:
    """Vérifie un quiz reçu (même produit en sortie structurée, on ne fait pas confiance aveuglément)."""
    if not isinstance(q, dict) or not isinstance(q.get("known"), bool):
        raise ValueError("Quiz illisible")
    if not q["known"]:
        return {"known": False, "reason": str(q.get("reason") or "Œuvre non reconnue"), "questions": []}
    qs = []
    for item in q.get("questions") or []:
        choices = item.get("choices")
        if (isinstance(item.get("question"), str) and isinstance(choices, list) and len(choices) == 4
                and all(isinstance(c, str) and c for c in choices)
                and isinstance(item.get("answer"), int) and 0 <= item["answer"] < 4):
            qs.append({"question": item["question"], "choices": choices, "answer": item["answer"]})
    if len(qs) < 3:
        raise ValueError("Le quiz reçu est incomplet : réessaie")
    return {"known": True, "reason": "", "questions": qs[:N_QUESTIONS]}
