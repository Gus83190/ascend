"""Défis de plusieurs jours (« donjons ») et habitudes personnelles.

Un défi se réussit en tenant N jours ; chaque jour est validé AUTOMATIQUEMENT par les saisies
(lecture, nuit, méditation…) ou, pour les défis d'abstinence (« sans sucre »), coché à la main.
Les longs défis ont des jokers (un jour manqué toléré par tranche de 14 jours).
Les habitudes sont des cases à cocher libres, avec leur série de jours.
Tout est relu depuis le journal : rien n'est stocké à part.
"""
import json
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Callable

from .engine import XPResult

MAX_ACTIFS = 5
MAX_HABITUDES = 12


@dataclass(frozen=True)
class Defi:
    id: str
    name: str
    stat: str
    days: int
    desc: str
    check: Callable | None = None      # (jour) -> bool ; None = coché à la main

    @property
    def jokers(self) -> int:
        return self.days // 14


def _acts(j, kind, cond=lambda d, p: True):
    return any(k == kind and cond(d, p) for k, d, p in j["acts"])


def _bedtime_ok(d, p):
    h = str(d.get("bedtime", "")).split(":")[0]
    return h.isdigit() and 18 <= int(h) <= 23


CATALOGUE = [
    Defi("lecture30", "30 jours de lecture", "Intelligence", 30, "Lire au moins 15 min chaque jour.",
         lambda j: _acts(j, "reading", lambda d, p: d.get("minutes", 0) >= 15)),
    Defi("nuits14", "14 nuits avant minuit", "Vitalité", 14, "Se coucher avant minuit 14 soirs de suite (saisie Sommeil).",
         lambda j: _acts(j, "sleep", _bedtime_ok)),
    Defi("medit21", "21 jours de méditation", "Mental", 21, "Méditer au moins 10 min par jour (ou une respiration guidée).",
         lambda j: _acts(j, "meditation", lambda d, p: d.get("minutes", 0) >= 10)),
    Defi("pompes30", "30 jours de pompes", "Force", 30, "Une série de pompes (n'importe quelle variante) chaque jour.",
         lambda j: _acts(j, "bodyweight", lambda d, p: d.get("family") == "poussée")
         or _acts(j, "skill", lambda d, p: d.get("family") == "poussée")),
    Defi("froid14", "14 douches froides", "Mental", 14, "Une exposition au froid chaque jour (saisie Inconfort).",
         lambda j: _acts(j, "discomfort")),
    Defi("bouger30", "30 jours en mouvement", "Endurance", 30,
         "Chaque jour : 20 min d'endurance, ou 8 000 pas (bilan bien-être).",
         lambda j: _acts(j, "endurance", lambda d, p: d.get("minutes", 0) >= 20) or (j["wb"].get("steps") or 0) >= 8000),
    Defi("focus10", "10 jours de concentration", "Mental", 10, "Une séance d'au moins 25 min au minuteur chaque jour.",
         lambda j: _acts(j, "focus", lambda d, p: p == "app" and d.get("minutes", 0) >= 25)),
    Defi("eau14", "14 jours d'hydratation", "Vitalité", 14, "Boire au moins 1,5 L d'eau par jour (bilan bien-être).",
         lambda j: (j["wb"].get("water_l") or 0) >= 1.5),
    Defi("legumes14", "14 jours à 5 fruits et légumes", "Vitalité", 14, "5 portions par jour (bilan bien-être).",
         lambda j: (j["wb"].get("fruits_veg") or 0) >= 5),
    Defi("ecrans14", "14 soirées sans écran", "Vitalité", 14, "Pas d'écran dans l'heure avant de dormir (bilan bien-être).",
         lambda j: j["wb"].get("screens_evening") is False),
    Defi("gratitude21", "21 jours de gratitude", "Mental", 21, "Noter 3 choses positives chaque jour (écran Carnet).",
         lambda j: any(len([g for g in n.get("gratitude", []) if g.strip()]) >= 3 for n in j["notes"])),
    Defi("journal30", "30 jours de journal", "Mental", 30, "Écrire une entrée de journal chaque jour (écran Carnet).",
         lambda j: any(len(n.get("text", "").strip()) >= 100 for n in j["notes"])),
    Defi("ecrire14", "14 jours d'écriture", "Intelligence", 14, "Écrire au moins 150 mots chaque jour (Carnet → Écriture).",
         lambda j: _acts(j, "writing", lambda d, p: d.get("words", 0) >= 150)),
    Defi("ecrire30", "30 jours d'écriture", "Intelligence", 30, "Écrire au moins 300 mots chaque jour (Carnet → Écriture).",
         lambda j: _acts(j, "writing", lambda d, p: d.get("words", 0) >= 300)),
    Defi("docu10", "10 jours de documentaires", "Intelligence", 10, "Un documentaire par jour, avec ce que tu en as retenu.",
         lambda j: _acts(j, "documentary", lambda d, p: len(d.get("learned", "")) >= 150)),
    Defi("sucre7", "7 jours sans sucre ajouté", "Vitalité", 7, "Aucun sucre ajouté de la journée. À cocher toi-même chaque soir."),
    Defi("detox7", "7 jours de déconnexion", "Mental", 7, "2 h d'affilée sans téléphone chaque jour. À cocher toi-même."),
    Defi("reveil21", "21 réveils à heure fixe", "Vitalité", 21, "Se lever à la même heure (à 15 min près), week-end compris. À cocher."),
    Defi("alcool30", "30 jours sans alcool", "Vitalité", 30, "Aucune boisson alcoolisée. À cocher toi-même chaque soir."),
]
PAR_ID = {d.id: d for d in CATALOGUE}


# ------------------------------------------------------------------ lecture du journal
def _context(store, hero_id: int, today: date) -> dict:
    """Saisies acceptées, bilans bien-être et notes, regroupés par jour."""
    captured: dict = {}
    hero = store.hero(hero_id, until=today, capture=captured)
    days: dict[str, dict] = {}
    rows = store.db.execute("SELECT id, day, type, payload FROM events WHERE hero_id=? AND day<=? ORDER BY day, id",
                            (hero_id, today.isoformat())).fetchall()
    defis_ev, habits_ev = [], []
    for ev in rows:
        p = json.loads(ev["payload"])
        j = days.setdefault(ev["day"], {"acts": [], "notes": [], "wb": {}, "ticks": set()})
        if ev["type"] == "activity":
            r = captured.get(ev["id"])
            pending = p.get("kind") == "reading" and isinstance(r, XPResult) and any(n.startswith("En attente") for n in r.notes)
            if isinstance(r, XPResult) and (r.raw > 0 or pending):
                j["acts"].append((p["kind"], p.get("data") or {}, p.get("proof")))
            if p.get("kind") == "wellbeing" and isinstance(r, XPResult) and not r.notes[0].startswith("Un seul"):
                j["wb"] = p.get("data") or {}
        elif ev["type"] == "note":
            j["notes"].append(p)
        elif ev["type"] in ("defi", "defi_check"):
            defis_ev.append((date.fromisoformat(ev["day"]), ev["type"], p))
        elif ev["type"] in ("habit", "habit_check"):
            habits_ev.append((date.fromisoformat(ev["day"]), ev["type"], p))
    return {"days": days, "defis": defis_ev, "habits": habits_ev, "hero": hero}


def _day(ctx, d: date) -> dict:
    return ctx["days"].get(d.isoformat(), {"acts": [], "notes": [], "wb": {}, "ticks": set()})


def _runs(ctx) -> list[dict]:
    """Toutes les tentatives de défi (en cours, réussies, ratées, abandonnées)."""
    runs, ticks = [], {}
    for d, typ, p in ctx["defis"]:
        if typ == "defi_check":
            ticks.setdefault(p.get("id"), set()).add(p.get("day", d.isoformat()))
    for d, typ, p in ctx["defis"]:
        if typ != "defi" or p.get("id") not in PAR_ID:
            continue
        if p.get("action") == "start":
            runs.append({"id": p["id"], "start": d, "stopped": None})
        elif p.get("action") == "stop":
            for r in reversed(runs):
                if r["id"] == p["id"] and r["stopped"] is None:
                    r["stopped"] = d
                    break
    for r in runs:
        r["ticks"] = ticks.get(r["id"], set())
    return runs


def _evaluate(run: dict, ctx, today: date) -> dict:
    df = PAR_ID[run["id"]]
    jokers, done, d = df.jokers, 0, run["start"]
    days = []
    state, end = "en cours", None
    last = min(today, run["stopped"]) if run["stopped"] else today
    while d <= last and state == "en cours":
        ok = d.isoformat() in run["ticks"] if df.check is None else bool(df.check(_day(ctx, d)))
        if ok:
            done += 1
            days.append({"day": d.isoformat(), "ok": True})
            if done >= df.days:
                state, end = "réussi", d
        elif d < today:
            days.append({"day": d.isoformat(), "ok": False})
            jokers -= 1
            if jokers < 0:
                state, end = "raté", d
        else:
            days.append({"day": d.isoformat(), "ok": None})     # aujourd'hui, pas encore fait
        d += timedelta(days=1)
    if state == "en cours" and run["stopped"]:
        state, end = "abandonné", run["stopped"]
    today_ok = days[-1]["ok"] if days and days[-1]["day"] == today.isoformat() else None
    return {"id": df.id, "name": df.name, "stat": df.stat, "days": df.days, "desc": df.desc, "manual": df.check is None,
            "start": run["start"].isoformat(), "state": state, "end": end.isoformat() if end else None,
            "done": done, "jokers_left": max(0, jokers), "jokers": df.jokers, "today_ok": today_ok,
            "recent": days[-14:]}


def _habits(ctx, today: date) -> list[dict]:
    habits: dict[str, dict] = {}
    for d, typ, p in ctx["habits"]:
        if typ == "habit":
            if p.get("action") == "add":
                habits[p["id"]] = {"id": p["id"], "name": p.get("name", ""), "since": d, "checks": set()}
            elif p.get("action") == "del":
                habits.pop(p.get("id"), None)
        elif typ == "habit_check" and p.get("id") in habits:
            (habits[p["id"]]["checks"].add if p.get("done", True) else habits[p["id"]]["checks"].discard)(p.get("day"))
    out = []
    for h in habits.values():
        streak, d = 0, today if today.isoformat() in h["checks"] else today - timedelta(days=1)
        while d.isoformat() in h["checks"]:
            streak += 1
            d -= timedelta(days=1)
        week = [{"day": (today - timedelta(days=i)).isoformat(), "done": (today - timedelta(days=i)).isoformat() in h["checks"]}
                for i in range(13, -1, -1)]
        best, cur, d = 0, 0, h["since"]
        while d <= today:
            cur = cur + 1 if d.isoformat() in h["checks"] else 0
            best = max(best, cur)
            d += timedelta(days=1)
        out.append({"id": h["id"], "name": h["name"], "streak": streak, "best": best, "days": week,
                    "total": len(h["checks"])})
    return out


def overview(store, hero_id: int, today: date) -> dict:
    ctx = _context(store, hero_id, today)
    runs = [_evaluate(r, ctx, today) for r in _runs(ctx)]
    active = [r for r in runs if r["state"] == "en cours"]
    won = [r for r in runs if r["state"] == "réussi"]
    catalogue = [{"id": d.id, "name": d.name, "stat": d.stat, "days": d.days, "desc": d.desc, "manual": d.check is None,
                  "jokers": d.jokers, "active": any(a["id"] == d.id for a in active),
                  "won": sum(1 for w in won if w["id"] == d.id)} for d in CATALOGUE]
    return {"active": active, "history": [r for r in runs if r["state"] != "en cours"][::-1][:20],
            "catalogue": catalogue, "trophies": len(won), "habits": _habits(ctx, today),
            "max_active": MAX_ACTIFS, "max_habits": MAX_HABITUDES}


def action(store, hero_id: int, today: date, body: dict) -> str:
    act = body.get("action")
    if act in ("start", "stop", "check") and "habit" not in body:
        did = body.get("id")
        if did not in PAR_ID:
            raise ValueError("Défi inconnu")
        ov = overview(store, hero_id, today)
        running = next((a for a in ov["active"] if a["id"] == did), None)
        if act == "start":
            if running:
                raise ValueError("Ce défi est déjà en cours")
            if len(ov["active"]) >= MAX_ACTIFS:
                raise ValueError(f"{MAX_ACTIFS} défis en même temps au plus : termine ou abandonne-en un")
            store._event(hero_id, today, "defi", {"action": "start", "id": did})
            return f"Défi « {PAR_ID[did].name} » commencé. Premier jour : aujourd'hui."
        if not running:
            raise ValueError("Ce défi n'est pas en cours")
        if act == "stop":
            store._event(hero_id, today, "defi", {"action": "stop", "id": did})
            return f"Défi « {PAR_ID[did].name} » abandonné."
        if PAR_ID[did].check is not None:
            raise ValueError("Ce défi se valide tout seul avec tes saisies")
        if running["today_ok"]:
            raise ValueError("Déjà coché aujourd'hui")
        store._event(hero_id, today, "defi_check", {"id": did, "day": today.isoformat()})
        return "Journée validée. Tiens bon !"
    if act in ("add", "del", "check", "uncheck") and "habit" in body:
        if act == "add":
            name = str(body.get("name", "")).strip()[:40]
            if not name:
                raise ValueError("Donne un nom à ton habitude")
            ov = overview(store, hero_id, today)
            if len(ov["habits"]) >= MAX_HABITUDES:
                raise ValueError(f"{MAX_HABITUDES} habitudes au plus")
            if any(h["name"].lower() == name.lower() for h in ov["habits"]):
                raise ValueError("Cette habitude existe déjà")
            import secrets
            store._event(hero_id, today, "habit", {"action": "add", "id": secrets.token_hex(4), "name": name})
            return f"Habitude « {name} » ajoutée."
        hid_ = str(body.get("habit", ""))
        ov = overview(store, hero_id, today)
        h = next((x for x in ov["habits"] if x["id"] == hid_), None)
        if h is None:
            raise ValueError("Habitude inconnue")
        if act == "del":
            store._event(hero_id, today, "habit", {"action": "del", "id": hid_})
            return f"Habitude « {h['name']} » supprimée."
        day = str(body.get("day") or today.isoformat())
        try:
            dd = date.fromisoformat(day)
        except ValueError:
            raise ValueError("Jour invalide")
        if not 0 <= (today - dd).days <= 1:
            raise ValueError("On ne coche que pour aujourd'hui ou hier")
        store._event(hero_id, today, "habit_check", {"id": hid_, "day": dd.isoformat(), "done": act == "check"})
        return "Coché." if act == "check" else "Décoché."
    raise ValueError("Action inconnue")
