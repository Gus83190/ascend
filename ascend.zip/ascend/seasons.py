"""Saisons (3 mois), calendrier d'activité, collection et carte.

Tout est calculé à partir du journal (une seule relecture), rien n'est stocké à part.
"""
import json
from datetime import date, timedelta

from . import config as C
from . import titles as TT
from . import trials as T
from .engine import XPResult
from .ranks import progress_to_next

MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
          "novembre", "décembre"]
SEASON_NAMES = {1: "Saison de l'Éveil", 2: "Saison de la Forge", 3: "Saison du Zénith", 4: "Saison des Cendres"}


def bounds(day: date) -> tuple[date, date]:
    q = (day.month - 1) // 3
    start = date(day.year, 3 * q + 1, 1)
    end = date(day.year + (q == 3), (3 * q + 3) % 12 + 1, 1) - timedelta(days=1)
    return start, end


def season_id(day: date) -> str:
    return f"{day.year}-S{(day.month - 1) // 3 + 1}"


def season_name(day: date) -> str:
    start, end = bounds(day)
    return f"{SEASON_NAMES[(day.month - 1) // 3 + 1]} {day.year} ({MONTHS[start.month - 1]} → {MONTHS[end.month - 1]})"


# Objectifs de saison : (id, libellé, cible). Les valeurs sont calculées par `_measure`.
OBJECTIVES = [
    ("xp", "Gagner 2 000 XP", 2000),
    ("quests", "Réussir toutes tes quêtes du jour, 30 jours", 30),
    ("books", "Valider 3 livres par quiz", 3),
    ("subjects", "Réussir 3 quiz de matière (4 bonnes réponses ou plus)", 3),
    ("nights", "25 bonnes nuits (note de 75 ou plus)", 25),
    ("outing", "Une sortie de 10 km ou plus (expédition ou endurance)", 1),
    ("focus", "10 h de concentration au minuteur", 600),
]


class Journal:
    """Une relecture complète du journal, réutilisée par tous les calculs de l'écran."""

    def __init__(self, store, hero_id: int, today: date):
        self.store, self.hid, self.today = store, hero_id, today
        self.captured: dict = {}
        self.hero = store.hero(hero_id, until=today, capture=self.captured)
        self.events = [dict(r) for r in store.db.execute(
            "SELECT id, day, type, payload FROM events WHERE hero_id=? AND day<=? ORDER BY day, id",
            (hero_id, today.isoformat()))]
        for ev in self.events:
            ev["p"] = json.loads(ev["payload"])
        self.quest_days = {r["day"]: (r["planned"], r["done"]) for r in store.db.execute(
            "SELECT day, SUM(status!='changée') AS planned, SUM(status='faite') AS done FROM quests "
            "WHERE hero_id=? AND day<=? GROUP BY day", (hero_id, today.isoformat()))}
        self.rests = store.neutral_rest_days(hero_id)
        row = store.db.execute("SELECT created FROM hero WHERE id=?", (hero_id,)).fetchone()
        self.created = date.fromisoformat(row["created"][:10]) if row else today

    # -------------------------------------------------------------- saisons
    def _measure(self, start: date, end: date) -> dict[str, float]:
        end = min(end, self.today)
        inside = [e for e in self.events if start.isoformat() <= e["day"] <= end.isoformat()]
        xp = sum(self.captured[e["id"]].granted for e in inside
                 if isinstance(self.captured.get(e["id"]), XPResult))
        quests = sum(1 for d, (planned, done) in self.quest_days.items()
                     if start.isoformat() <= d <= end.isoformat() and planned and done >= planned)
        books = len({e["p"].get("work_id") for e in inside if e["type"] == "bookquiz" and e["p"].get("passed")})
        ok = [(e["p"].get("kind"), e["p"].get("data") or {}, e["p"].get("proof")) for e in inside
              if e["type"] == "activity" and isinstance(self.captured.get(e["id"]), XPResult)
              and self.captured[e["id"]].raw > 0]
        subjects = sum(1 for k, d, _ in ok if k == "homework" and d.get("quiz_id")
                       and d.get("ai_score", 0) >= C.BOOK_QUIZ_PASS / C.BOOK_QUIZ_QUESTIONS - 1e-9)
        nights = sum(1 for d, sc in self.hero.sleep_scores if start <= d <= end and sc >= 75)
        outing = sum(1 for k, d, _ in ok if k in ("expedition", "endurance") and d.get("distance_km", 0) >= 10)
        focus = sum(d.get("minutes", 0) for k, d, proof in ok if k == "focus" and proof == "app")
        return {"xp": xp, "quests": quests, "books": books, "subjects": subjects, "nights": nights,
                "outing": outing, "focus": focus}

    def season(self, day: date) -> dict:
        start, end = bounds(day)
        values = self._measure(start, end)
        objectives = []
        for oid, lab, target in OBJECTIVES:
            v = values[oid]
            objectives.append({"id": oid, "label": lab, "value": round(v), "target": target, "done": v >= target})
        done = sum(o["done"] for o in objectives)
        return {"id": season_id(day), "name": season_name(day), "start": start.isoformat(), "end": end.isoformat(),
                "days_left": max(0, (end - self.today).days) if start <= self.today <= end else 0,
                "current": start <= self.today <= end, "objectives": objectives, "done": done,
                "seal_at": C.SEASON_SEAL, "seal": done >= C.SEASON_SEAL}

    def seasons(self) -> list[dict]:
        """Saison en cours puis les précédentes depuis la création du héros (8 au plus)."""
        out, d = [], self.today
        first = min([self.created] + [date.fromisoformat(e["day"]) for e in self.events[:1]])
        while len(out) < 8:
            out.append(self.season(d))
            start, _ = bounds(d)
            if start <= first:
                break
            d = start - timedelta(days=1)
        return out

    # -------------------------------------------------------------- calendrier
    def calendar(self, days: int = 365) -> dict:
        start = self.today - timedelta(days=days - 1)
        per: dict[str, dict] = {}
        for e in self.events:
            if e["day"] < start.isoformat():
                continue
            r = self.captured.get(e["id"])
            item = per.setdefault(e["day"], {"xp": 0.0, "entries": 0})
            if isinstance(r, XPResult):
                item["xp"] += r.granted
                item["entries"] += 1
            elif e["type"] == "bookquiz":
                item["entries"] += 1
        out = []
        for i in range(days):
            d = (start + timedelta(days=i)).isoformat()
            planned, done = self.quest_days.get(d, (0, 0))
            item = per.get(d, {"xp": 0.0, "entries": 0})
            out.append({"day": d, "xp": round(item["xp"]), "entries": item["entries"], "planned": planned or 0,
                        "done": done or 0, "rest": d in self.rests})
        active = [x for x in out if x["entries"]]
        streak = 0
        for x in reversed(out):
            if x["entries"] or x["rest"]:
                streak += 1
            elif x["day"] != self.today.isoformat():
                break
        return {"days": out, "active_days": len(active), "total_xp": sum(x["xp"] for x in out),
                "best_day": max(out, key=lambda x: x["xp"]) if active else None, "streak": streak}

    # -------------------------------------------------------------- collection
    def collection(self) -> dict:
        h = self.hero
        skins = []
        for st in C.STATS:
            got = C.RANKS.index(h.earned_rank(st))
            skins.append({"stat": st, "ranks": [{"rank": rk, "unlocked": C.RANKS.index(rk) <= got,
                                                  "name": f"Tenue {rk} · {st}" if rk != "S" else f"Légende · {st}"}
                                                 for rk in C.RANKS[1:]]})
        earned_avg = global_rank_earned(h)
        auras = [{"rank": rk, "name": AURAS[rk], "manga": AURAS_MANGA[rk], "unlocked": C.RANKS.index(rk) <= C.RANKS.index(earned_avg)}
                 for rk in C.RANKS[1:]]
        seals = [{"id": s["id"], "name": s["name"], "done": s["done"], "unlocked": s["seal"], "current": s["current"]}
                 for s in self.seasons()]
        return {"titles": TT.collection(h, self.today, self.title_counters()), "skins": skins, "auras": auras, "seals": seals}

    def title_counters(self) -> dict:
        """Compteurs des titres liés aux autres écrans (voir titles.EXTRA_TITLES)."""
        from . import cartes as CA
        from . import defis as DF
        from . import goals as GO
        from . import langues as LG
        from .engine import XPResult
        acts = [(e, e["p"]) for e in self.events if e["type"] == "activity"
                and isinstance(self.captured.get(e["id"]), XPResult) and self.captured[e["id"]].raw > 0]
        notes = [e["p"] for e in self.events if e["type"] == "note"]
        out = {"notes": len(notes),
               "gratitude_days": len({e["day"] for e in self.events if e["type"] == "note"
                                      and len([g for g in e["p"].get("gratitude", []) if g.strip()]) >= 3}),
               "words": sum((p.get("data") or {}).get("words", 0) for e, p in acts if p.get("kind") == "writing"),
               "longest_run": max([(p.get("data") or {}).get("distance_km", 0) for e, p in acts if p.get("kind") == "endurance"], default=0),
               "exp_km": sum((p.get("data") or {}).get("distance_km", 0) for e, p in acts if p.get("kind") == "expedition"),
               "mobility": sum(1 for e, p in acts if p.get("kind") == "mobility")}
        try:
            out["defis"] = DF.overview(self.store, self.hid, self.today)["trophies"]
            out["goals"] = sum(g["state"] == "atteint" for g in GO.overview(self.store, self.hid, self.today)["goals"])
            out["cards_learned"] = sum(CA.overview(self.store, self.hid, self.today)["boxes"][4:])
            lv = [x["level"] for x in LG.status(self.store, self.hid, self.today)["languages"] if x["level"]]
            out["lang_level"] = max((LG.LEVELS.index(v) + 1 for v in lv), default=0)
        except Exception:                                   # un compteur en défaut ne doit pas casser l'écran
            pass
        # Programme de force avec charges suivi 12 semaines sans être arrêté avant.
        lift, starts = 0, {}
        for e in self.events:
            if e["type"] != "program" or e["p"].get("stat") != "Force":
                continue
            d = date.fromisoformat(e["day"])
            for k, s in list(starts.items()):
                lift = max(lift, (d - s).days // 7)
                starts.pop(k)
            if e["p"].get("program") in ("fullbody", "5x5", "hautbas"):
                starts[e["p"]["program"]] = d
        for s in starts.values():
            lift = max(lift, (self.today - s).days // 7)
        out["lift_weeks"] = lift
        return out

    # -------------------------------------------------------------- carte
    def world_map(self) -> dict:
        h = self.hero
        regions = []
        for st in C.STATS:
            raw, frac, left = progress_to_next(h.stat_xp[st])
            regions.append({
                "stat": st, "name": REGION_NAMES[st], "rank": h.rank_of(st), "xp": round(h.stat_xp[st]),
                "frac": round(frac, 3) if h.rank_of(st) == raw else 1.0, "explored": h.stat_xp[st] > 0,
                "dormant": h.is_dormant(st), "convalescence": st in h.convalescence,
                "trial_needed": (T.blocker(h, st, raw) or {}).get("rank"), "need": (T.blocker(h, st, raw) or {}).get("text")})
        return {"regions": regions, "places": sorted(h.seen_places), "rank": h.rank, "level": h.level}


AURAS = {"D": "Liseré de bronze", "C": "Liseré d'argent", "B": "Liseré d'or", "A": "Liseré de platine", "S": "Couronne de laurier"}
AURAS_MANGA = {"D": "Étincelle", "C": "Brasier", "B": "Foudre", "A": "Tempête", "S": "Couronne d'astres"}
REGION_NAMES = {"Force": "Les Forges", "Endurance": "La Grande Route", "Agilité": "Les Cimes Agiles",
                "Vitalité": "Le Val Serein", "Intelligence": "La Bibliothèque", "Mental": "Le Sanctuaire",
                "Expédition": "Les Terres Sauvages"}


def global_rank_earned(h) -> str:
    """Rang global sans la mise en sommeil (pour les auras : un cosmétique gagné reste gagné)."""
    weights = C.CLASSES.get(h.hero_class, {})
    total = sum(weights.get(s, 1.0) for s in C.STATS)
    avg = sum(weights.get(s, 1.0) * C.RANKS.index(h.earned_rank(s)) for s in C.STATS) / total
    return C.RANKS[int(avg + 1e-9)]
