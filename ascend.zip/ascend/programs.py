"""Programmes d'entraînement proposés après l'évaluation de départ.

Le joueur choisit les stats qui l'intéressent ; pour chaque stat évaluée, ASCEND propose trois
programmes de 6 semaines d'intensité croissante (Découverte, Progression, Intensif), calculés
d'après son rang, ses variantes d'exercices en cours et son profil santé.
Le suivi est automatique : les objectifs de la semaine se remplissent avec les saisies.
"""
import json
from datetime import date, timedelta

from . import catalog as K
from . import config as C
from . import quests as Q
from .engine import XPResult

WEEKS = 6
LEVELS = [("decouverte", "Découverte"), ("progression", "Progression"), ("intensif", "Intensif")]


def _lvl(hero, stat: str) -> int:
    return C.RANKS.index(hero.earned_rank(stat))


def _r5(x: float) -> int:
    return max(5, int(5 * round(x / 5)))


def _scale(hero, stat: str) -> float:
    return max(0.3, Q.health_scale(hero, stat))


def plan(hero, stat: str, level: int) -> dict:
    """Programme `level` (0, 1, 2) pour une stat : objectifs hebdomadaires et conseils."""
    lv = _lvl(hero, stat)
    k = (1.0, 1.25, 1.5)[level]
    objs: list[dict] = []
    tips: list[str] = []
    if stat in ("Force", "Agilité"):
        n = ((2, 3, 4) if stat == "Force" else (2, 3, 5))[level]
        objs.append({"id": "sessions", "label": f"{n} séances de {stat.lower()} par semaine (jours différents)", "target": n,
                     "kinds": ["bodyweight", "skill"] + (["strength"] if stat == "Force" else []), "stat": stat})
        for fam in Q.families_for(hero, stat):
            qq = Q._variant_quest(hero, fam, scale=k)
            tips.append(qq.title.replace("3 séries", f"{3 + level} séries"))
    elif stat == "Endurance":
        n = (2, 3, 4)[level]
        m = _r5((20 + 6 * lv) * k * _scale(hero, stat))
        objs.append({"id": "runs", "label": f"{n} sorties d'endurance de {m} min ou plus", "target": n,
                     "kinds": ["endurance"], "min_minutes": m})
        tips += [f"Allure facile : tu dois pouvoir parler en courant (ou marcher vite)",
                 "Une sortie par semaine un peu plus longue que les autres" if level else "Alterne marche et course si besoin"]
        if level == 2:
            tips.append("Une séance de fractionné : 6 × 1 min rapide / 1 min lente")
    elif stat == "Vitalité":
        n = (4, 5, 6)[level]
        objs.append({"id": "nights", "label": f"{n} bonnes nuits (note de 75 ou plus)", "target": n, "nights": True})
        tips += ["Couche-toi à la même heure (à 30 min près), même le week-end",
                 "Pas d'écran dans la dernière demi-heure" if level else "Coupe les écrans 15 min avant de dormir",
                 "Saisis chaque nuit : la régularité compte autant que la durée"]
    elif stat == "Intelligence":
        days, m = (4, 5, 6)[level], _r5((15, 25, 40)[level] * _scale(hero, stat))
        nq = (1, 2, 3)[level]
        objs.append({"id": "reading", "label": f"Lire {m} min ou plus, {days} jours par semaine", "target": days,
                     "kinds": ["reading"], "min_minutes": m, "pending_ok": True})
        objs.append({"id": "subjects", "label": f"{nq} quiz de matière par semaine", "target": nq, "kinds": ["homework"],
                     "quiz": True})
        tips += ["Choisis un livre de la banque : son quiz valide toutes tes séances d'un coup",
                 "Un livre par mois" if level < 2 else "Deux livres par mois"]
    elif stat == "Mental":
        ns, m = (3, 4, 5)[level], _r5((25, 45, 60)[level] * _scale(hero, stat))
        nd, mm = (3, 5, 7)[level], (5, 10, 15)[level]
        objs.append({"id": "focus", "label": f"{ns} séances au minuteur de {m} min ou plus", "target": ns, "kinds": ["focus"],
                     "min_minutes": m, "proof": "app"})
        objs.append({"id": "meditation", "label": f"Méditer {mm} min, {nd} jours par semaine", "target": nd,
                     "kinds": ["meditation"], "min_minutes": mm})
        tips += ["Téléphone dans une autre pièce pendant le minuteur", "Méditation guidée si tu débutes"]
    elif stat == "Expédition":
        n = (1, 1, 2)[level]
        km = max(3, round((5 + 2 * lv) * (1.0, 1.4, 1.6)[level] * _scale(hero, stat)))
        objs.append({"id": "outings", "label": f"{n} sortie{'s' if n > 1 else ''} de {km} km ou plus par semaine",
                     "target": n, "kinds": ["expedition", "endurance"], "min_km": km})
        tips += ["Importe ta trace GPX : XP pleine et épreuves possibles", "Découvre un nouveau lieu chaque mois (+30 XP)"]
    name = LEVELS[level][1]
    return {"id": LEVELS[level][0], "name": f"{stat} · {name}", "level": level, "weeks": WEEKS, "objectives": objs,
            "tips": tips, "summary": " · ".join(o["label"] for o in objs)}


def _count(obj: dict, acts: list[tuple[date, str, dict, str | None]], hero, start: date, end: date) -> int:
    if obj.get("nights"):
        return sum(1 for d, sc in hero.sleep_scores if start <= d <= end and sc >= 75)
    days = set()
    n = 0
    for d, kind, data, proof in acts:
        if not start <= d <= end or kind not in obj.get("kinds", []):
            continue
        if obj.get("stat") and kind in ("bodyweight", "skill") and K.FAMILIES.get(data.get("family"), {}).get("stat") != obj["stat"]:
            continue
        if data.get("minutes", 1e9) < obj.get("min_minutes", 0) or data.get("distance_km", 1e9) < obj.get("min_km", 0):
            continue
        if obj.get("proof") and proof != obj["proof"]:
            continue
        if obj.get("quiz") and not data.get("quiz_id"):
            continue
        if obj["id"] in ("sessions", "reading", "meditation"):
            days.add(d)
        else:
            n += 1
    return max(n, len(days))


def _accepted(store, hero_id: int, today: date, since: date):
    """Saisies acceptées depuis `since` (une séance de lecture en attente de son quiz compte aussi)."""
    captured: dict = {}
    hero = store.hero(hero_id, until=today, capture=captured)
    acts = []
    for ev in store.db.execute("SELECT id, day, payload FROM events WHERE hero_id=? AND type='activity' AND day>=? AND day<=?",
                               (hero_id, since.isoformat(), today.isoformat())):
        r = captured.get(ev["id"])
        p = json.loads(ev["payload"])
        pending = p.get("kind") == "reading" and isinstance(r, XPResult) and any(n.startswith("En attente") for n in r.notes)
        if isinstance(r, XPResult) and (r.raw > 0 or pending):
            acts.append((date.fromisoformat(ev["day"]), p["kind"], p.get("data") or {}, p.get("proof")))
    return hero, acts


def _current(store, hero_id: int) -> dict[str, dict]:
    cur: dict[str, dict] = {}
    for ev in store.db.execute("SELECT day, payload FROM events WHERE hero_id=? AND type='program' ORDER BY day, id", (hero_id,)):
        p = json.loads(ev["payload"])
        if p.get("program"):
            cur[p["stat"]] = {"program": p["program"], "level": p.get("level", 0), "start": date.fromisoformat(ev["day"])}
        else:
            cur.pop(p.get("stat"), None)
    return cur


def interests(store, hero_id: int) -> list[str]:
    raw = store.get_meta(f"interests:{hero_id}")
    try:
        got = json.loads(raw) if raw else []
    except ValueError:
        got = []
    return [s for s in got if s in C.STATS]


def set_interests(store, hero_id: int, stats) -> str:
    if not isinstance(stats, list) or any(s not in C.STATS for s in stats):
        raise ValueError("Choisis des stats parmi les 7")
    store.set_meta(f"interests:{hero_id}", json.dumps(sorted(set(stats), key=C.STATS.index), ensure_ascii=False))
    return "Stats choisies : " + (", ".join(sorted(set(stats), key=C.STATS.index)) or "aucune")


def choose(store, hero_id: int, today: date, stat, program) -> str:
    if stat not in C.STATS:
        raise ValueError("Stat inconnue")
    hero = store.hero(hero_id, until=today)
    if program in (None, ""):
        if stat not in _current(store, hero_id):
            raise ValueError("Pas de programme en cours pour cette stat")
        store._event(hero_id, today, "program", {"stat": stat, "program": None})
        return f"Programme {stat} arrêté"
    ids = [lid for lid, _ in LEVELS]
    if program not in ids:
        raise ValueError("Programme inconnu")
    if stat not in hero.assessed:
        raise ValueError(f"Passe d'abord l'évaluation de départ en {stat}")
    if stat in hero.convalescence:
        raise ValueError(f"{stat} est en convalescence : reprends un programme quand tu seras rétabli(e)")
    p = plan(hero, stat, ids.index(program))
    store._event(hero_id, today, "program", {"stat": stat, "program": program, "level": ids.index(program), "name": p["name"]})
    return f"Programme « {p['name']} » commencé : {WEEKS} semaines. Les objectifs se remplissent avec tes saisies."


def overview(store, hero_id: int, today: date) -> dict:
    cur = _current(store, hero_id)
    since = min([c["start"] for c in cur.values()], default=today) - timedelta(days=today.weekday())
    hero, acts = _accepted(store, hero_id, today, since)
    wanted = interests(store, hero_id)
    out = []
    monday = today - timedelta(days=today.weekday())
    for stat in C.STATS:
        item = {"stat": stat, "interested": stat in wanted, "assessed": stat in hero.assessed, "rank": hero.rank_of(stat),
                "convalescence": stat in hero.convalescence, "options": [], "current": None}
        if stat in hero.assessed:
            item["options"] = [plan(hero, stat, i) for i in range(3)]
        if stat in cur:
            c = cur[stat]
            p = plan(hero, stat, c["level"])
            weeks = []
            first = c["start"] - timedelta(days=c["start"].weekday())
            for w in range(WEEKS):
                ws = first + timedelta(weeks=w)
                if ws > monday:
                    break
                we = ws + timedelta(days=6)
                objs = [{"label": o["label"], "value": _count(o, acts, hero, max(ws, c["start"]), min(we, today)),
                         "target": o["target"]} for o in p["objectives"]]
                for o in objs:
                    o["done"] = o["value"] >= o["target"]
                weeks.append({"start": ws.isoformat(), "objectives": objs, "done": all(o["done"] for o in objs),
                              "current": ws == monday})
            finished = (monday - first).days >= WEEKS * 7
            won = sum(w["done"] for w in weeks)
            item["current"] = {"id": c["program"], "name": p["name"], "level": c["level"], "start": c["start"].isoformat(),
                               "week": min(WEEKS, len(weeks)), "weeks": weeks, "tips": p["tips"], "finished": finished,
                               "won": won, "next": (LEVELS[c["level"] + 1][1] if finished and won >= 4 and c["level"] < 2 else None)}
        out.append(item)
    return {"stats": out, "interests": wanted, "weeks": WEEKS}
