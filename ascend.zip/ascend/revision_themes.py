"""Thèmes de révision par matière : chaque question est rangée dans un thème par mots-clés.

Pour chaque thème : identifiant, libellé, ce qu'il couvre (affiché sur la fiche) et une expression
régulière cherchée dans la question ET la bonne réponse. Le premier thème qui correspond l'emporte ;
sinon la question va dans le dernier thème de la matière (« notions générales »).
"""
import re

T = {
    "maths": [
        ("proba", "Probabilités et statistiques", "Moyenne, médiane, écart-type, probabilités d'événements, lois (binomiale, normale…), espérance et variance.",
         r"probabilit|statisti|moyenne|médiane|écart|variance|espérance|loi (binomiale|normale|de poisson|exponentielle|uniforme)|aléatoire|\bdé\b|martingale|markov|brownien|bienaymé|grands nombres|central limite|événement|binomiale"),
        ("lineaire", "Algèbre linéaire et structures", "Matrices, déterminants, valeurs propres, espaces vectoriels, groupes, anneaux et corps.",
         r"matrice|déterminant|valeur(s)? propre|vectoriel|endomorphisme|\brang\b|trace|groupe|anneau|\bcorps\b|idéal|galois|ℤ/|linéaire|base orthonormée|nilpotent|diagonalis"),
        ("analyse", "Fonctions et analyse", "Fonctions, dérivées, primitives, intégrales, limites, suites et séries, équations différentielles.",
         r"fonction|dérivée|primitive|intégr|limite|suite|série|continu|taylor|développement limité|\bln\b|ln\(|eˣ|e\^|exponentielle|logarithme|asymptote|y' |équation différentielle|holomorphe|résidus|fourier|cauchy|bolzano|rolle|valeurs intermédiaires|bornes atteintes|dirac"),
        ("topo", "Topologie et analyse fonctionnelle", "Espaces métriques et normés, compacité, complétude, Hilbert et Banach, mesure et intégration.",
         r"compact|hilbert|banach|tribu|mesure|lebesgue|topolog|baire|zorn|hahn|riesz|stone|point fixe|opérateur|distribution|variété|stokes|groupe fondamental|espace complet"),
        ("geometrie", "Géométrie et trigonométrie", "Figures, aires et volumes, Pythagore et Thalès, vecteurs, droites, trigonométrie.",
         r"triangle|cercle|angle|aire|périmètre|volume|pythagore|thalès|vecteur|droite|parallèle|cosinus|sinus|tangente|\bcos\b|\bsin\b|rectangle|carré|cube|sphère|rayon|diagonale|polygone|coordonnées|produit scalaire|module|complexe|conjugué"),
        ("algebre", "Algèbre et équations", "Calcul littéral, équations et inéquations, polynômes, factorisation, systèmes.",
         r"équation|inéquation|polynôme|factoris|développ|identité remarquable|système|\bx\b|x²|solution|racine|discriminant|second degré"),
        ("nombres", "Nombres et calcul", "Opérations, fractions, pourcentages, puissances, nombres premiers, PGCD, proportionnalité.",
         r"combien font|fraction|pourcentage|%|puissance|premier|pgcd|ppcm|divis|proportionn|arrondi|décimal|entier|factorielle|\d"),
        ("general", "Notions générales de mathématiques", "Raisonnement, logique et notions transversales.", r"."),
    ],
    "francais": [
        ("grammaire", "Grammaire et conjugaison", "Nature et fonction des mots, temps et modes, accords, phrase complexe.",
         r"nature|fonction|sujet|complément|conjug|temps|mode|subjonctif|conditionnel|indicatif|imparfait|participe|pluriel|accord|déterminant|adverbe|adjectif|pronom|verbe|proposition|homonyme|synonyme|antonyme|orthographe"),
        ("figures", "Figures de style et poésie", "Comparaison, métaphore, anaphore, oxymore…, versification, formes poétiques.",
         r"figure|métaphore|comparaison|anaphore|oxymore|litote|hyperbole|euphémisme|chiasme|zeugma|hypotypose|personnification|alexandrin|syllabe|sonnet|vers|rime|strophe|poè|poésie|recueil"),
        ("theatre", "Théâtre", "Genres et règles du théâtre, tragédie, comédie, grandes pièces et auteurs.",
         r"théâtre|tragédie|comédie|scène|acte|pièce|molière|racine|corneille|beaumarchais|marivaux|beckett|ionesco|trois unités|drame"),
        ("mouvements", "Mouvements et histoire littéraire", "Moyen Âge, Renaissance, classicisme, Lumières, romantisme, réalisme, naturalisme, surréalisme…",
         r"mouvement|romantis|réalis|naturalis|surréalis|symbolis|classicis|lumières|pléiade|renaissance|moyen âge|chanson de geste|nouveau roman|existential|baroque|humanis"),
        ("theorie", "Théorie littéraire et linguistique", "Narratologie, sémiologie, critique littéraire, linguistique.",
         r"narrat|focalisation|genette|barthes|saussure|jakobson|greimas|propp|bakhtine|kristeva|todorov|intertext|signifi|linguist|critique|lecteur|lecture|autobiograph|autofiction|pacte|champ littéraire|déconstruction|new criticism"),
        ("oeuvres", "Grandes œuvres et auteurs", "Qui a écrit quoi : romans, essais et auteurs majeurs de la littérature française.",
         r"qui a écrit|auteur|roman|conte|écrivain|fable|essai"),
        ("general", "Notions générales de français", "Culture littéraire et notions transversales.", r"."),
    ],
    "histoire": [
        ("antiquite", "Antiquité", "Mésopotamie, Égypte, Grèce et Rome, naissance des religions monothéistes.",
         r"égypt|pyramide|grec|grèce|athènes|sparte|rome|romain|césar|gaule|gaulois|vercingétorix|sumérien|cunéiforme|antique|antiquité|hérodote|thucydide|empire romain|476|judaïsme|mahomet|islam"),
        ("moyenage", "Moyen Âge", "Francs et Carolingiens, féodalité, croisades, guerre de Cent Ans, Église médiévale.",
         r"clovis|charlemagne|carolingien|capétien|féodal|seigneur|vassal|croisade|cent ans|jeanne d'arc|médiéval|moyen âge|peste noire|bouvines|verdun|843|800|1095|1453|constantinople|village médiéval|église"),
        ("modernes", "Temps modernes (XVIe-XVIIIe siècle)", "Renaissance, Réformes, grandes découvertes, monarchie absolue, Lumières, traite atlantique.",
         r"renaissance|réforme|luther|calvin|colomb|découverte|imprimerie|gutenberg|louis xiv|versailles|absolut|richelieu|fronde|nantes|saint-barthélemy|westphalie|trente|henri iv|traite|esclav|1776|indépendance américaine|washington|glorieuse"),
        ("revolution", "Révolution et XIXe siècle", "Révolution française, Empire, révolutions du XIXe siècle, industrialisation, colonisation, IIIe République.",
         r"révolution|bastille|1789|terreur|robespierre|napoléon|empire|empereur|code civil|austerlitz|waterloo|vienne|1830|1848|commune|république|industriel|vapeur|bismarck|risorgimento|sécession|meiji|colonis|berlin \(1884|dreyfus|ferry|1905|laïcité"),
        ("guerres", "Guerres mondiales et entre-deux-guerres", "Première et Seconde Guerre mondiale, totalitarismes, crise de 1929, Shoah, Résistance.",
         r"1914|1918|1916|1917|verdun|tranchée|armistice|versailles|1919|sdn|société des nations|1929|krach|mussolini|hitler|nazi|staline|front populaire|1936|munich|1938|1939|1940|vichy|pétain|de gaulle|18 juin|débarquement|1944|1945|shoah|stalingrad|hiroshima|résistance|kolkhoz|collectivisation"),
        ("contemporain", "Monde depuis 1945", "Guerre froide, décolonisation, construction européenne, Ve République, monde actuel.",
         r"guerre froide|urss|otan|varsovie|mur de berlin|1989|1991|cuba|kennedy|décolonis|algérie|indochine|diên|vietnam|suez|bandung|mao|chine|ve république|1958|mai 68|trente glorieuses|choc pétrolier|europ|maastricht|traité de rome|onu|apartheid|mandela|gorbatchev|perestroïka|marshall|yalta|corée|inde"),
        ("historio", "Historiographie et méthodes", "Écoles historiques, grands historiens, méthodes et sources de l'histoire.",
         r"historien|annales|braudel|bloch|febvre|duby|le goff|furet|foucault|certeau|veyne|hobsbawm|thompson|anderson|said|subaltern|connectée|pomeranz|wallerstein|ginzburg|nora|tocqueville|paxton|ariès|kantorowicz|seignobos|quantitative|sérielle|microhistoire|mentalités"),
        ("general", "Notions générales d'histoire", "Repères chronologiques et notions transversales.", r"."),
    ],
    "geo": [
        ("reperes", "Repères du monde et de la France", "Continents, océans, fleuves, montagnes, capitales, pays et régions.",
         r"capitale|fleuve|océan|mer\b|montagne|sommet|continent|pays le plus|plus grand|plus long|désert|lac|détroit|île|région|département|équateur|méridien|parallèle|tropique|boussole|chaîne"),
        ("milieux", "Milieux, climats et risques", "Climats, relief, littoraux, risques naturels et environnement, changement climatique.",
         r"climat|mousson|niño|effet de serre|albédo|bassin versant|partage des eaux|risque|aléa|résilien|vulnérab|estuaire|delta|littoral|isthme|érosion|environnement|durable|transition énergétique|anthropocène|justice environnementale|biodiversité"),
        ("villes", "Villes et territoires", "Urbanisation, métropoles, périurbanisation, gentrification, inégalités territoriales.",
         r"ville|urbain|urbanis|métropol|mégalopole|mégapole|conurbation|périurban|gentrification|quartier|exode rural|rente foncière|alonso|burgess|ségrégation|smart city|décroissance urbaine|diagonale du vide|enclav|justice spatiale|polycentr"),
        ("mondialisation", "Mondialisation, échanges et puissances", "Flux, ports, canaux, firmes transnationales, développement, Union européenne, géopolitique.",
         r"mondialisation|port|canal|conteneur|ftn|firme|zee|maritime|schengen|union européenne|ultrapériphér|nords|suds|développement|idh|pétrole|opep|rente|géopolitique|heartland|rimland|mahan|ratzel|lebensraum|frontière|puissance"),
        ("theorie", "Théories, modèles et outils du géographe", "Modèles spatiaux, cartographie, SIG, grands géographes et courants.",
         r"modèle|théorie|loi de|zipf|christaller|thünen|tobler|ravenstein|zelinsky|butler|perroux|myrdal|krugman|gravitaire|carte|cartograph|échelle|anamorphose|projection|sig|raster|vecteur|mnt|ndvi|krigeage|acp|maup|moran|géoréférenc|géographe|vidal|reclus|lacoste|hérodote|brunet|chorème|bertin|berque|frémont|lefebvre|harvey|sassen|gottmann|wallerstein|hägerstrand|courant|tournant|quantitative|représentations"),
        ("general", "Notions générales de géographie", "Vocabulaire et notions transversales.", r"."),
    ],
    "pc": [
        ("electricite", "Électricité et magnétisme", "Tension, intensité, résistance, loi d'Ohm, circuits, induction, électromagnétisme.",
         r"tension|intensité|résistance|ohm|ampère|volt|circuit|série|dérivation|courant|charge électrique|coulomb|faraday|maxwell|magnét|induct|électromot|pile|\bwatt\b|puissance"),
        ("mecanique", "Mécanique et énergie", "Forces, vitesse, lois de Newton, énergies cinétique et potentielle, travail.",
         r"force|newton|vitesse|accélération|poids|pesanteur|\bg\b|énergie cinétique|potentielle|travail|mouvement|chute|trajectoire|lagrang|moindre action|joule|kwh|énergie"),
        ("ondes", "Ondes, lumière et optique", "Son, lumière, fréquence et longueur d'onde, réfraction, spectre.",
         r"onde|lumière|son\b|fréquence|période|hertz|longueur d'onde|réfraction|snell|réflexion|optique|photon|spectre|rayonnement|célérité|corps noir|wien|stefan|photoélectrique"),
        ("matiere", "Matière, atomes et chimie", "Atomes, molécules, réactions chimiques, mole, pH, oxydoréduction, cinétique.",
         r"atome|molécule|électron|proton|neutron|noyau|isotope|ion|mole\b|avogadro|masse molaire|réaction|réactif|catalyseur|ph\b|acide|base|oxyd|formule chimique|h₂o|co₂|liaison|orbital|chimie|combustion|arrhenius|nernst|cinétique|rmn|fusion|solidification|vaporisation|liquéfaction|état|température d'ébullition|bout"),
        ("thermo", "Thermodynamique et physique statistique", "Principes de la thermodynamique, gaz parfaits, entropie, transitions de phase.",
         r"thermodynamique|entropie|gaz parfait|pv = nrt|boltzmann|enthalpie|chaleur|température|partition|transition de phase|ising|boyle"),
        ("moderne", "Physique moderne (quantique, relativité, particules)", "Mécanique quantique, relativité, particules élémentaires, cosmologie.",
         r"quantique|schrödinger|planck|heisenberg|broglie|dirac|relativ|einstein|e = mc|fermion|boson|pauli|higgs|quark|électrofaible|chromodynamique|intrication|bell|noether|renormalis|cosmolog|λcdm|fond diffus|hawking|bcs|supraconduct|condensat|spin"),
        ("general", "Notions générales de physique-chimie", "Notions transversales et culture scientifique.", r"."),
    ],
    "svt": [
        ("genetique", "Génétique et biologie moléculaire", "ADN, gènes, transcription et traduction, mutations, hérédité, épigénétique, biotechnologies.",
         r"adn|arn|gène|chromosome|allèle|mutation|transcription|traduction|codon|intron|épissage|ribosome|polymérase|réplication|mendel|hérédit|épigén|méthylation|opéron|crispr|pcr|séquenç|snp|gwas|génome|rna-seq|alphafold|blast|télomér|sirna"),
        ("cellule", "Cellule et métabolisme", "Organites, respiration cellulaire, photosynthèse, enzymes, division cellulaire.",
         r"cellule|organite|mitochondr|chloroplaste|photosynthèse|chlorophylle|respiration cellulaire|glycolyse|krebs|calvin|atp|enzyme|michaelis|mitose|méiose|apoptose|autophagie|protéasome|membrane|thylakoïde|stroma|souche|ips|organoïde"),
        ("corps", "Corps humain et santé", "Organes et fonctions, nutrition, système nerveux, hormones, immunité, vaccins.",
         r"cœur|sang|poumon|alvéole|rein|foie|estomac|organe|digest|hormone|insuline|glucagon|glycémie|pancréas|neurone|potentiel d'action|synapse|neurotransmetteur|acétylcholine|immun|anticorps|antigène|lymphocyte|globule|vaccin|antibiotique|cmh|plasmocyte|os|crâne|santé|microbiote|essai clinique|immunothérapie|r0|épidémi|sir\b"),
        ("evolution", "Évolution et biodiversité", "Sélection naturelle, dérive génétique, phylogénie, spéciation, histoire du vivant.",
         r"évolution|darwin|sélection naturelle|dérive|hardy|weinberg|phylogén|clade|spéciation|horloge moléculaire|neutraliste|kimura|équilibres ponctués|gould|endosymbio|margulis|biodiversité|espèce"),
        ("ecologie", "Écologie et écosystèmes", "Chaînes alimentaires, écosystèmes, cycles biogéochimiques, dynamique des populations.",
         r"écosystème|chaîne alimentaire|producteur|consommateur|décomposeur|cycle de l'azote|cycle du carbone|lotka|volterra|logistique|capacité de charge|shannon|clé de voûte|population"),
        ("terre", "Géologie et planète Terre", "Structure de la Terre, roches, tectonique des plaques, volcans et séismes.",
         r"plaque|tectonique|dorsale|subduction|croûte|manteau|noyau terrestre|roche|granite|calcaire|volcan|séisme|magma"),
        ("general", "Notions générales de SVT", "Notions transversales et culture biologique.", r"."),
    ],
    "anglais": [
        ("linguistics", "Linguistics and theory", "Linguistique, sociolinguistique, acquisition des langues, théories critiques.",
         r"linguist|phoneme|morpheme|vowel|chomsky|labov|krashen|hymes|sapir|speech act|code-switching|world englishes|lingua franca|corpus|collocation|hedging|received pronunciation|cefr|subaltern|bhabha|spivak|said|foucault|anderson"),
        ("culture", "Literature and culture", "Littérature anglophone, histoire et civilisation du monde anglophone.",
         r"who wrote|wrote|novel|poem|shakespeare|period|magna carta|constitution|declaration|norman|1066|speech|civil rights|literature|author"),
        ("grammar", "Grammar and tenses", "Temps, modaux, voix passive, discours indirect, conditionnels, structures.",
         r"tense|complete|choose|passive|reported|modal|wish|had\b|have\b|has\b|were\b|was\b|did\b|gerund|infinitive|conditional|neither|since|for\b|comparative|plural|third person|which (sentence|form)|correct form"),
        ("vocab", "Vocabulary and idioms", "Vocabulaire courant, faux amis, expressions idiomatiques, phrasal verbs.",
         r"means|mean|meaning|signifie|false friend|faux ami|phrasal|idiom|opposite|«.*»|word"),
        ("general", "General English", "Notions générales d'anglais.", r"."),
    ],
    "espagnol": [
        ("gramatica", "Grammaire et conjugaison", "Ser/estar, temps du passé, subjonctif, impératif, gérondif, prépositions.",
         r"complète|conjugue|temps|subjonctif|impératif|gérondif|participe|ser\b|estar|por|para|hay|ojalá|pluriel|féminin|leísmo|voseo|seseo"),
        ("cultura", "Culture et littérature hispaniques", "Littérature, histoire et civilisation de l'Espagne et de l'Amérique latine.",
         r"qui a écrit|écrivain|poète|prix|peintre|guerre|franco|transición|siècle d'or|boom|génération|roman|capitale|civilisation|incas|aztèque|cuba|révolution|cinéaste|langue|académie|essai"),
        ("vocabulario", "Vocabulaire et expressions", "Vocabulaire courant et expressions idiomatiques.",
         r"signifie|se dit|comment dit-on|«"),
        ("general", "Notions générales d'espagnol", "Notions transversales.", r"."),
    ],
    "philo": [
        ("antique", "Philosophie antique", "Socrate, Platon, Aristote, stoïciens et épicuriens.",
         r"socrate|platon|aristote|épicure|stoï|sénèque|épictète|marc aurèle|caverne|banquet|vertu|juste milieu|cause finale|plotin"),
        ("connaissance", "Connaissance, raison et science", "Rationalisme, empirisme, Kant, épistémologie, philosophie des sciences.",
         r"descartes|cogito|pense, donc|empiris|hume|locke|berkeley|leibniz|monade|kant|critique de la raison|raison pure|popper|kuhn|bachelard|feyerabend|lakatos|falsifi|paradigme|obstacle|gettier|connaissance|science|ockham|raison suffisante"),
        ("morale", "Morale et politique", "Impératif catégorique, utilitarisme, contrat social, justice, liberté.",
         r"morale|impératif|utilitar|bonheur|contrat social|rousseau|hobbes|léviathan|machiavel|prince|tocqueville|mill|liberté|justice|rawls|nozick|sen\b|voile|tramway|devoir|volonté générale|singer|habermas|honneth|reconnaissance"),
        ("existence", "Existence, conscience et langage", "Existentialisme, phénoménologie, philosophie de l'esprit et du langage.",
         r"sartre|camus|beauvoir|existential|absurde|kierkegaard|nietzsche|schopenhauer|heidegger|husserl|phénoménolog|dasein|levinas|ricœur|gadamer|herméneut|conscience|esprit|chambre chinoise|chauve-souris|nagel|chalmers|searle|wittgenstein|tractatus|jeux de langage|frege|austin|grice|quine|kripke|langage"),
        ("contemporaine", "Philosophie contemporaine", "Structuralisme, déconstruction, pensée française et analytique récente.",
         r"deleuze|derrida|badiou|rancière|butler|foucault|lyotard|baudrillard|technique|jonas|ellul|parfit|putnam|nozick"),
        ("general", "Notions générales de philosophie", "Notions transversales.", r"."),
    ],
    "eco": [
        ("macro", "Macroéconomie et politiques économiques", "PIB, croissance, chômage, inflation, politiques budgétaire et monétaire, cycles.",
         r"pib|croissance|chômage|inflation|récession|keynes|multiplicateur|is-lm|phillips|laffer|budgétaire|monétaire|taux directeur|banque centrale|bce|taylor|trappe|stagnation|équivalence ricardienne|dsge|lucas|solow|monétarisme|anticipations"),
        ("micro", "Microéconomie et marchés", "Offre et demande, élasticité, coûts, concurrence et monopoles, externalités.",
         r"offre|demande|élasticité|coût marginal|monopole|oligopole|concurrence|externalité|pigou|coase|bien public|valeur ajoutée|prix"),
        ("international", "Commerce international et finance", "Avantages comparatifs, change, balance commerciale, crises financières.",
         r"ricardo|avantages comparatifs|heckscher|échange|commerce|balance|change|mundell|parité|subprimes|crise financière|black-scholes|efficience|fama|options"),
        ("theorie", "Théories, jeux et économie comportementale", "Théorie des jeux, information, comportements, grands économistes.",
         r"nash|prisonnier|pareto|akerlof|aléa moral|sélection adverse|contrats|kahneman|thaler|simon|rationalité|arrow|schumpeter|smith|richesse des nations|économiste|théorie|instrumentale|différences de différences|randomisés|duflo|lorenz|gini|herfindahl|idh|mmt|modern monetary"),
        ("general", "Notions générales d'économie", "Notions transversales.", r"."),
    ],
    "droit": [
        ("constit", "Droit constitutionnel et institutions", "Constitution, Parlement, président, Conseil constitutionnel, QPC.",
         r"constitution|conseil constitutionnel|assemblée|sénat|député|sénateur|président|premier ministre|49|qpc|parlement|loi\b|mandat|préambule|charte de l'environnement"),
        ("civil", "Droit civil et des contrats", "Contrats, responsabilité civile, propriété, personnes, prescription.",
         r"contrat|consentement|dol|force majeure|imprévision|responsabilité civile|propriété|majorité civile|prescription|code civil|ordonnance|2016|société anonyme"),
        ("penal", "Droit pénal et justice", "Infractions, peines, principes du procès pénal, juridictions.",
         r"pénal|infraction|crime|délit|contravention|peine|innocence|non bis|in dubio|assises|tribunal|juridiction|prud'hommes|cassation|jurisprudence|légalité des délits"),
        ("admin", "Droit administratif et européen", "Actes administratifs, Conseil d'État, droit de l'Union, droits fondamentaux.",
         r"administrat|conseil d'état|blanco|nicolo|excès de pouvoir|européen|union|cedh|convention européenne|strasbourg|costa|van gend|primauté|effet direct|subsidiarité|rgpd|cnil|conventionnalité"),
        ("theorie", "Théorie du droit et droit international", "Grands juristes, philosophie du droit, droit international.",
         r"kelsen|hart|dworkin|jusnatural|positivisme|réalisme|posner|économique du droit|duguit|hauriou|carbonnier|schmitt|cour pénale|internationale|jus cogens|vienne|soft law|la haye"),
        ("general", "Notions générales de droit", "Notions transversales.", r"."),
    ],
    "culture": [
        ("arts", "Arts : peinture, sculpture, architecture", "Grands peintres, mouvements artistiques, sculpteurs et architectes.",
         r"peint|tableau|sculpt|architect|impression|cubis|surréalis|pop art|dada|bauhaus|art nouveau|musée|joconde|guernica|picasso|gaudí|rodin|le corbusier|warhol|duchamp|delacroix|géricault|klimt"),
        ("musique", "Musique et cinéma", "Compositeurs, œuvres musicales, réalisateurs et films.",
         r"compos|symphonie|opéra|musique|jazz|piano|beethoven|mozart|vivaldi|ravel|stravinsky|réalis|film|cinéma|nouvelle vague|studio|kurosawa|chaplin|kubrick"),
        ("sciences", "Sciences et inventions", "Grands scientifiques, découvertes et inventions.",
         r"scientifique|découvert|invent|einstein|curie|fleming|pénicilline|relativité|heisenberg|moore|web|nobel|ampoule|planète"),
        ("societe", "Société, idées et institutions", "Sociologie, grands penseurs, organisations internationales, actualité du monde.",
         r"sociolog|durkheim|weber|bourdieu|mauss|lévi-strauss|anthropolog|onu|oms|unesco|otan|parlement européen|union européenne|laïcité|giec|accord de paris|théorie|école de francfort|habermas|latour|rawls|sen\b|huntington|fukuyama|bauman|beck|goffman|becker|elias|boudon|foucault|benjamin|panofsky|piketty|tirole|kuhn|popper|arendt|beauvoir"),
        ("quotidien", "Culture générale du quotidien", "Monnaies, sports, fêtes, littérature populaire et repères courants.",
         r"monnaie|sport|football|jeux olympiques|badminton|fête|noël|joueurs|minutes|coq|tintin|petit prince|arc-en-ciel|araignée|baleine|tour eiffel|bissextile|note de musique|hexagone|continent|fleuve|écrit"),
        ("general", "Notions générales de culture", "Repères transversaux.", r"."),
    ],
    "info": [
        ("algo", "Algorithmique et complexité", "Tris, recherche, graphes, complexité, programmation dynamique, calculabilité.",
         r"complexit|tri|dichotom|algorithme|dijkstra|kruskal|bellman|prim|graphe|parcours|dynamique|glouton|np|turing|arrêt|automate|récursi|o\(|tas|arbre|pile|file"),
        ("donnees", "Bases de données et données", "SQL, modèle relationnel, clés, normalisation, transactions.",
         r"sql|base de données|clé primaire|relationnel|forme normale|acid|transaction|select|table"),
        ("systemes", "Systèmes, réseaux et sécurité", "Systèmes d'exploitation, réseaux et protocoles, cryptographie, systèmes distribués.",
         r"réseau|tcp|udp|ip|dns|osi|protocole|http|système d'exploitation|ordonnanceur|processus|interblocage|chiffre|crypt|rsa|hachage|cap|consensus|raft|paxos|distribué|mapreduce|blockchain|octet|bit|binaire|hexadécimal|html"),
        ("ia", "Intelligence artificielle et apprentissage", "Apprentissage automatique, réseaux de neurones, évaluation des modèles.",
         r"neurone|apprentissage|surapprentissage|overfitting|dropout|transformer|attention|gradient|k-means|roc|renforcement|cnn|modèle|confidentialité différentielle"),
        ("prog", "Programmation et logiciel", "Langages, paradigmes, compilation, gestion de versions, preuve de programmes.",
         r"langage|programm|compilat|git|objet|fonctionnel|variable|booléen|python|haskell|coq|curry|preuve|vérification formelle|quantique|shor|grover"),
        ("general", "Notions générales d'informatique", "Notions transversales.", r"."),
    ],
}

RESOURCES = {
    "maths": ["Khan Academy (fr.khanacademy.org)", "Lumni (lumni.fr)", "Bibmath (bibmath.net)"],
    "francais": ["Lumni (lumni.fr)", "Le Robert, dictionnaire en ligne", "Gallica, BnF (gallica.bnf.fr)"],
    "histoire": ["Lumni (lumni.fr)", "L'Histoire par l'image (histoire-image.org)", "Encyclopædia Universalis ou Wikipédia"],
    "geo": ["Géoconfluences, ENS Lyon (geoconfluences.ens-lyon.fr)", "Lumni (lumni.fr)", "Le dessous des cartes (Arte)"],
    "pc": ["Khan Academy (fr.khanacademy.org)", "Lumni (lumni.fr)", "Culture Sciences Physique / Chimie, ENS Lyon"],
    "svt": ["Lumni (lumni.fr)", "Planet-Vie, ENS (planet-vie.ens.fr)", "Khan Academy, biologie"],
    "anglais": ["BBC Learning English", "Cambridge Dictionary", "British Council LearnEnglish"],
    "espagnol": ["Diccionario de la RAE (dle.rae.es)", "Centro Virtual Cervantes", "Lumni (lumni.fr)"],
    "philo": ["Stanford Encyclopedia of Philosophy (en anglais)", "Lumni, philosophie", "France Culture, émissions de philosophie"],
    "eco": ["Melchior (melchior.fr)", "Ses-ENS (ses.ens-lyon.fr)", "Banque de France, ABC de l'économie"],
    "droit": ["Légifrance (legifrance.gouv.fr)", "Vie-publique.fr", "Fiches d'orientation Dalloz"],
    "culture": ["Wikipédia", "Lumni (lumni.fr)", "France Culture"],
    "info": ["France-IOI (france-ioi.org)", "OpenClassrooms", "Interstices, Inria (interstices.info)"],
}

_COMPILED = {s: [(tid, lab, desc, re.compile(rx, re.I)) for tid, lab, desc, rx in themes] for s, themes in T.items()}


def theme_of(subject: str, question: dict) -> str:
    text = question["q"] + " " + question["choices"][question["answer"]]
    for tid, _lab, _desc, rx in _COMPILED.get(subject, []):
        if rx.search(text):
            return tid
    return "general"


def theme_info(subject: str, tid: str) -> dict:
    for t, lab, desc, _rx in _COMPILED.get(subject, []):
        if t == tid:
            return {"id": t, "label": lab, "desc": desc}
    return {"id": "general", "label": "Notions générales", "desc": "Notions transversales."}
