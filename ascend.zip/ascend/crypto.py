"""Chiffrement des sauvegardes, avec la bibliothèque standard uniquement.

Construction (chiffrer puis authentifier) :
- clé dérivée du code de récupération par scrypt (sel aléatoire de 16 octets) ;
- flux de chiffrement : HMAC-SHA256(clé, nonce ‖ compteur), combiné par XOR ;
- intégrité : HMAC-SHA256 sur l'en-tête, le nonce et le texte chiffré (un code faux ou un
  fichier abîmé est détecté avant toute restauration).

À remplacer par AES-GCM (bibliothèque « cryptography ») avant une version publique.
"""
import hashlib
import hmac
import os
import secrets

MAGIC = b"ASCBAK1"
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # sans 0/O ni 1/I/L : plus facile à recopier


def new_code() -> str:
    raw = "".join(secrets.choice(ALPHABET) for _ in range(20))
    return "-".join(raw[i:i + 4] for i in range(0, 20, 4))


def _norm(code: str) -> bytes:
    return "".join(c for c in str(code).upper() if c.isalnum()).encode()


def _keys(code: str, salt: bytes) -> tuple[bytes, bytes]:
    k = hashlib.scrypt(_norm(code), salt=salt, n=2 ** 14, r=8, p=1, dklen=64, maxmem=64 * 1024 * 1024)
    return k[:32], k[32:]


def _stream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hmac.new(key, nonce + counter.to_bytes(8, "big"), hashlib.sha256).digest()
        counter += 1
    return bytes(out[:length])


def encrypt(data: bytes, code: str) -> bytes:
    salt, nonce = os.urandom(16), os.urandom(16)
    k_enc, k_mac = _keys(code, salt)
    ct = bytes(a ^ b for a, b in zip(data, _stream(k_enc, nonce, len(data))))
    tag = hmac.new(k_mac, MAGIC + salt + nonce + ct, hashlib.sha256).digest()
    return MAGIC + salt + nonce + tag + ct


def decrypt(blob: bytes, code: str) -> bytes:
    if not blob.startswith(MAGIC) or len(blob) < len(MAGIC) + 64:
        raise ValueError("Ce fichier n'est pas une sauvegarde ASCEND chiffrée")
    i = len(MAGIC)
    salt, nonce, tag, ct = blob[i:i + 16], blob[i + 16:i + 32], blob[i + 32:i + 64], blob[i + 64:]
    k_enc, k_mac = _keys(code, salt)
    if not hmac.compare_digest(tag, hmac.new(k_mac, MAGIC + salt + nonce + ct, hashlib.sha256).digest()):
        raise ValueError("Code de récupération incorrect, ou fichier abîmé")
    return bytes(a ^ b for a, b in zip(ct, _stream(k_enc, nonce, len(ct))))
