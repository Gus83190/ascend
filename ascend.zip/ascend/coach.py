"""Coach par règles : 3 ou 4 conseils du jour, calculés à partir du journal (aucune IA, rien n'est envoyé).

Chaque règle donne (priorité, texte, lien). On garde les plus prioritaires, sans doublon de lien.
"""
from datetime import date, timedelta

from . import config as C
from . import defis as DF
from . import programs as PG

LINKS = {"Force": "saisie.html", "Agilité": "saisie.html", "Endurance": "saisie.html", "Vitalité": "saisie.html",
         "Intelligence": "quiz.html", "Mental": "minuteur.html", "Expédition": "saisie.html"}


def tips(store, hero_id: int, today: date, limit: int = 4) -> list[dict]:
    hero = store.hero(hero_id, until=today)
    wanted = PG.interests(store, hero_id) or [s for s in C.STATS if s in hero.assessed]
    out: list[tuple[int, str, str, str]] = []          # (priorité, type, texte, lien)

    # 1. Stats qui s'endorment (rang perdu après DORMANT_DAYS jours sans activité)
    for st in wanted:
        days = hero.inactive_days(st, today)
        if days is None or st in hero.convalescence:
            continue
        left = hero.dormant_days - days
        if hero.is_dormant(st, today):
            out.append((95, "alerte", f"{st} est en sommeil : 3 séances en 14 jours la réveillent.", LINKS[st]))
        elif left <= 14:
            out.append((85, "alerte", f"{st} s'endort dans {max(0, left)} jour(s) : une séance suffit à l'éviter.", LINKS[st]))
        elif days >= 7:
            out.append((40 + min(days, 30), "rappel", f"{days} jours sans {st}. Une petite séance aujourd'hui ?", LINKS[st]))

    # 2. Sommeil : moyenne des 7 dernières nuits
    recent = [sc for d, sc in hero.sleep_scores if today - timedelta(days=7) < d <= today]
    if len(recent) >= 3:
        avg = sum(recent) / len(recent)
        if avg < 60:
            out.append((80, "conseil", f"Tes nuits sont courtes ou irrégulières (note moyenne {avg:.0f}/100). "
                        "Ce soir : écrans coupés 30 min avant, coucher à heure fixe.", "saisie.html"))
        elif avg >= 85:
            out.append((20, "bravo", f"Belle semaine de sommeil ({avg:.0f}/100 en moyenne). Continue !", "records.html"))

    # 3. Humeur basse plusieurs jours
    moods = [w.get("mood") for d, w in hero.wellbeing.items() if today - timedelta(days=3) < d <= today and w.get("mood")]
    if len(moods) >= 2 and sum(moods) / len(moods) <= 2:
        out.append((90, "conseil", "Ton humeur est basse ces derniers jours. 5 minutes de respiration guidée, "
                    "ou quelques lignes dans ton carnet, peuvent aider. Si ça dure, parles-en à quelqu'un.", "minuteur.html#respiration"))

    # 4. Défis en cours pas encore validés aujourd'hui
    try:
        ov = DF.overview(store, hero_id, today)
    except Exception:                                     # un défi ne doit jamais casser l'accueil
        ov = {"active": []}
    for a in ov["active"]:
        if not a["today_ok"]:
            how = "coche-le" if a["manual"] else "il se valide avec ta saisie"
            out.append((75 if a["done"] else 60, "défi", f"Défi « {a['name']} » : jour {a['done'] + 1}/{a['days']}, {how}.", "defis.html"))

    # 5. Programme : objectifs de la semaine en retard (à partir du vendredi)
    if today.weekday() >= 4:
        try:
            prog = PG.overview(store, hero_id, today)
        except Exception:
            prog = {"stats": []}
        for s in prog["stats"]:
            cur = s.get("current")
            if not cur or cur["finished"]:
                continue
            wk = next((w for w in cur["weeks"] if w["current"]), None)
            if wk and not wk["done"]:
                late = [o for o in wk["objectives"] if not o["done"]]
                o = late[0]
                out.append((70, "programme", f"{cur['name']} : encore {o['target'] - o['value']} pour « {o['label']} » "
                            f"avant dimanche.", "programmes.html"))

    # 6. Bilan bien-être du jour (seulement si la Vitalité l'intéresse)
    if "Vitalité" in wanted and today not in hero.wellbeing:
        out.append((25, "rappel", "Pense à ton bilan bien-être du jour (eau, pas, humeur) : 1 minute, et tes courbes se remplissent.",
                    "saisie.html"))

    # 7. Rien d'urgent : un encouragement
    if not out:
        out.append((10, "bravo", "Tout est à jour. Une quête du jour, un défi ou une page de carnet pour aller plus loin ?", "defis.html"))

    out.sort(key=lambda x: -x[0])
    seen, res = set(), []
    for prio, kind, text, link in out:
        key = (kind, link)
        if key in seen and kind != "défi":
            continue
        seen.add(key)
        res.append({"kind": kind, "text": text, "link": link})
        if len(res) >= limit:
            break
    return res
