"""Évaluations de départ des stats sans test physique : Vitalité, Intelligence, Mental, Expédition.

- Vitalité et Expédition : questionnaire d'habitudes (déclaratif → rang de départ C au plus).
- Mental : questionnaire + test de mémoire des chiffres fait dans l'application (C au plus).
- Intelligence : quiz chronométré de 12 questions (collège et lycée), corrigé par le moteur (B au plus).
Comme pour la Force, l'évaluation ne se fait qu'une fois par stat : elle fixe le point de départ.
"""
import random

from . import bookquiz as BQ

# Rang de départ selon le score (0 à 1). Le plafond dépend de la fiabilité du test.
TABLE = [("D", 0.35), ("C", 0.6), ("B", 0.85)]
CAP = {"Vitalité": "C", "Expédition": "C", "Mental": "C", "Intelligence": "B"}
STATS = list(CAP)

# (id, question, [(réponse, points 0 à 3)])
QUESTIONNAIRES: dict[str, list[tuple[str, str, list[tuple[str, int]]]]] = {
    "Vitalité": [
        ("heures", "Combien d'heures dors-tu en moyenne par nuit ?",
         [("Moins de 6 h", 0), ("6 à 7 h", 1), ("7 à 9 h", 3), ("Plus de 9 h", 2)]),
        ("regularite", "Ton heure de coucher change-t-elle d'un jour à l'autre ?",
         [("Beaucoup (plus de 2 h d'écart)", 0), ("Un peu (1 à 2 h)", 1), ("Peu (moins d'1 h)", 2), ("Presque toujours la même heure", 3)]),
        ("repos", "Te réveilles-tu en te sentant reposé(e) ?",
         [("Presque jamais", 0), ("Rarement", 1), ("Souvent", 2), ("Presque toujours", 3)]),
        ("ecrans", "Utilises-tu un écran dans l'heure avant de dormir ?",
         [("Tous les soirs", 0), ("Souvent", 1), ("Parfois", 2), ("Jamais ou presque", 3)]),
        ("reveils", "Te réveilles-tu pendant la nuit ?",
         [("Plusieurs fois par nuit", 0), ("Une fois par nuit", 1), ("Quelques fois par semaine", 2), ("Rarement", 3)]),
        ("sport", "Combien de fois par semaine fais-tu une activité physique ?",
         [("Jamais", 0), ("1 à 2 fois", 1), ("3 à 4 fois", 2), ("5 fois ou plus", 3)]),
        ("eau", "Combien bois-tu d'eau par jour ?",
         [("Moins d'1 litre", 0), ("1 à 1,5 litre", 1), ("1,5 à 2 litres", 2), ("Plus de 2 litres", 3)]),
    ],
    "Expédition": [
        ("distance", "Quelle est ta plus longue randonnée ou sortie à pied en un jour ?",
         [("Moins de 5 km", 0), ("5 à 15 km", 1), ("15 à 25 km", 2), ("Plus de 25 km", 3)]),
        ("denivele", "Quel est le plus grand dénivelé positif que tu as fait en un jour ?",
         [("Moins de 300 m", 0), ("300 à 800 m", 1), ("800 à 1 500 m", 2), ("Plus de 1 500 m", 3)]),
        ("cotation", "Quel est le terrain le plus difficile que tu as parcouru ?",
         [("Chemins faciles (T1)", 0), ("Sentiers de montagne (T2)", 1), ("Sentiers raides, pierriers (T3)", 2),
          ("Passages alpins, mains utiles (T4 ou plus)", 3)]),
        ("frequence", "À quelle fréquence sors-tu explorer (nature ou ville) ?",
         [("Moins d'une fois par mois", 0), ("Une fois par mois", 1), ("2 à 3 fois par mois", 2), ("Chaque semaine", 3)]),
        ("orientation", "Sais-tu t'orienter seul(e) (carte, boussole, trace GPX) ?",
         [("Pas du tout", 0), ("Avec une application, sur des sentiers balisés", 1), ("Oui, sur la plupart des itinéraires", 2),
          ("Oui, même hors sentier", 3)]),
        ("bivouac", "As-tu déjà fait une sortie de plusieurs jours (trek, bivouac) ?",
         [("Jamais", 0), ("Une fois", 1), ("Quelques fois", 2), ("Régulièrement", 3)]),
    ],
    "Mental": [
        ("session", "Combien de temps arrives-tu à travailler concentré(e), sans téléphone ?",
         [("Moins de 15 min", 0), ("15 à 30 min", 1), ("30 min à 1 h", 2), ("Plus d'1 h", 3)]),
        ("meditation", "Médites-tu ?",
         [("Jamais", 0), ("Parfois", 1), ("Chaque semaine", 2), ("Chaque jour", 3)]),
        ("ecran", "Combien de temps passes-tu sur les écrans de loisir par jour ?",
         [("Plus de 5 h", 0), ("3 à 5 h", 1), ("1 à 3 h", 2), ("Moins d'1 h", 3)]),
        ("stress", "Face au stress, comment réagis-tu le plus souvent ?",
         [("Je suis vite débordé(e)", 0), ("Ça me bloque un moment", 1), ("Je m'en sors la plupart du temps", 2),
          ("J'ai des outils qui marchent (respiration, sport…)", 3)]),
        ("habitude", "Tiens-tu une habitude difficile dans la durée (sport, douche froide, réveil tôt) ?",
         [("Jamais", 0), ("Quelques jours", 1), ("Quelques semaines", 2), ("Depuis des mois", 3)]),
    ],
}
SPAN_POINTS = [(4, 0), (5, 1), (6, 2), (7, 2.5), (8, 3)]       # empan de chiffres → points (0 à 3)
INTEL_QUESTIONS = 12


def public(stat: str) -> list[dict]:
    return [{"id": qid, "question": q, "choices": [c for c, _ in opts]} for qid, q, opts in QUESTIONNAIRES.get(stat, [])]


def score_questionnaire(stat: str, answers: dict) -> float:
    """Score 0 à 1. `answers` : {id de question: index de la réponse}. Lève ValueError si incomplet."""
    qs = QUESTIONNAIRES[stat]
    if not isinstance(answers, dict):
        raise ValueError("Réponds à toutes les questions")
    total = 0.0
    for qid, _, opts in qs:
        a = answers.get(qid)
        if isinstance(a, bool) or not isinstance(a, int) or not 0 <= a < len(opts):
            raise ValueError("Réponds à toutes les questions")
        total += opts[a][1]
    return total / (3 * len(qs))


def span_points(span) -> float:
    if isinstance(span, bool) or not isinstance(span, int) or not 2 <= span <= 15:
        raise ValueError("Test de mémoire des chiffres : résultat invalide")
    return max((p for s, p in SPAN_POINTS if span >= s), default=0)


def score_mental(answers: dict, span) -> float:
    """Mental : 2/3 questionnaire, 1/3 test de mémoire des chiffres."""
    return score_questionnaire("Mental", answers) * 2 / 3 + span_points(span) / 3 / 3


def rank_for_score(stat: str, score: float) -> str:
    start = "E"
    for rank, lvl in TABLE:
        if score >= lvl:
            start = rank
    ranks = ["E", "D", "C", "B", "A", "S"]
    return ranks[min(ranks.index(start), ranks.index(CAP[stat]))]


def draw_intelligence(excluded: set[str], seed=None) -> list[dict]:
    """12 questions : moitié collège, moitié lycée, matières mélangées (réponses mélangées)."""
    rnd = random.Random(seed)
    subj = BQ.subjects()
    out = []
    for level in ("collège", "lycée"):
        pool = [q for w in subj.values() if w["type"] == level for q in w["questions"] if q["id"] not in excluded]
        for q in rnd.sample(pool, INTEL_QUESTIONS // 2):
            order = list(range(4))
            rnd.shuffle(order)
            out.append({"id": q["id"], "q": q["q"], "choices": [q["choices"][i] for i in order],
                        "answer": order.index(q["answer"]), "level": level})
    rnd.shuffle(out)
    return out


def score_intelligence(good_college: int, good_lycee: int) -> float:
    """Les questions de lycée comptent davantage (×1,5)."""
    n = INTEL_QUESTIONS // 2
    return (good_college + 1.5 * good_lycee) / (n + 1.5 * n)
