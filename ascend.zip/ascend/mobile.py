"""Version mobile : le moteur ASCEND tourne dans le navigateur du téléphone (Pyodide).

Pas de serveur : les écrans appellent `call()` directement. La base SQLite vit dans le
stockage du navigateur (IndexedDB), sur le téléphone uniquement.
"""
import json
from datetime import date
from pathlib import Path

from .server import App, api_call

_app: App | None = None


def start(db_path: str, today_iso) -> None:
    """`today_iso` : fonction JavaScript qui renvoie la date LOCALE du téléphone (AAAA-MM-JJ)."""
    global _app
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    _app = App(Path(db_path), today=lambda: date.fromisoformat(str(today_iso())))


def call(method: str, path: str, body_json: str | None) -> str:
    if _app is None:
        return json.dumps({"status": 503, "payload": {"error": "Moteur pas encore prêt"}})
    try:
        body = json.loads(body_json) if body_json else None
    except ValueError:
        return json.dumps({"status": 400, "payload": {"error": "JSON invalide"}})
    status, payload = api_call(_app, method, path, body)
    return json.dumps({"status": status, "payload": payload}, ensure_ascii=False)
