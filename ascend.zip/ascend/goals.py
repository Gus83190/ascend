"""Objectifs personnels : « courir 100 km avant juin », « rang C en Mental », « lire 6 livres »…

La progression se calcule toute seule à partir des saisies ACCEPTÉES depuis le jour où l'objectif
a été fixé (sauf les rangs et la charge maximale, qui regardent le niveau actuel). Un objectif
« libre » se coche à la main. Tout est relu depuis le journal (événements « goal »).
"""
import json
import secrets
from datetime import date

from . import catalog as K
from . import config as C
from . import programs as PG

MAX_GOALS = 10

# id → (libellé, unité, aide)
METRICS = {
    "run_km": ("Kilomètres d'endurance", "km", "course, vélo, natation… cumulés"),
    "exp_km": ("Kilomètres d'expédition", "km", "randonnées et sorties cumulées"),
    "exp_dplus": ("Dénivelé positif", "m", "cumulé sur tes expéditions"),
    "reading_h": ("Heures de lecture", "h", "cumulées"),
    "books": ("Livres validés par quiz", "livres", "quiz réussis"),
    "focus_h": ("Heures de concentration", "h", "au minuteur"),
    "medit_n": ("Séances de méditation", "séances", "respiration comprise"),
    "force_days": ("Jours de musculation", "jours", "Force au poids du corps ou avec charges"),
    "steps_days": ("Jours à 10 000 pas", "jours", "bilan bien-être"),
    "orm": ("Charge maximale (1RM estimée)", "kg", "sur un exercice avec charges"),
    "rank": ("Rang dans une stat", "rang", "le rang affiché sur ta fiche"),
    "manual": ("Objectif libre", "", "tu le coches toi-même quand c'est fait"),
}


def _events(store, hero_id: int, today: date) -> dict[str, dict]:
    goals: dict[str, dict] = {}
    for ev in store.db.execute("SELECT day, payload FROM events WHERE hero_id=? AND type='goal' AND day<=? ORDER BY day, id",
                               (hero_id, today.isoformat())):
        p, d = json.loads(ev["payload"]), date.fromisoformat(ev["day"])
        if p.get("action") == "add" and p.get("metric") in METRICS:
            goals[p["id"]] = {**p, "start": d, "done_day": None}
        elif p.get("id") in goals:
            if p.get("action") == "del":
                goals.pop(p["id"])
            elif p.get("action") == "done":
                goals[p["id"]]["done_day"] = d
    return goals


def _value(g: dict, hero, acts) -> float:
    m, start = g["metric"], g["start"]
    since = [(d, k, data) for d, k, data, _ in acts if d >= start]
    if m == "run_km":
        return sum(data.get("distance_km", 0) for d, k, data in since if k == "endurance")
    if m == "exp_km":
        return sum(data.get("distance_km", 0) for d, k, data in since if k == "expedition")
    if m == "exp_dplus":
        return sum(data.get("elevation_m", 0) for d, k, data in since if k == "expedition")
    if m == "reading_h":
        return sum(data.get("minutes", 0) for d, k, data in since if k == "reading") / 60
    if m == "books":
        return sum(1 for d in hero.works.values() if d >= start)
    if m == "focus_h":
        return sum(data.get("minutes", 0) for d, k, data in since if k == "focus") / 60
    if m == "medit_n":
        return sum(1 for d, k, data in since if k == "meditation")
    if m == "force_days":
        return len({d for d, k, data in since if k == "strength" or
                    (k in ("bodyweight", "skill") and data.get("family") in ("poussée", "tirage", "jambes", "gainage"))})
    if m == "steps_days":
        return len({d for d, k, data in since if k == "wellbeing" and (data.get("steps") or 0) >= 10000})
    if m == "orm":
        ex = K.norm_lift(g.get("param", ""))
        best = 0.0
        for d, k, data, _ in acts:
            if k == "strength" and K.norm_lift(data.get("exercise", "")) == ex:
                for w, r in data.get("sets", []):
                    if w > 0 and 1 <= r <= 12:
                        best = max(best, w * (1 + r / 30))
        return best
    if m == "rank":
        return C.RANKS.index(hero.rank_of(g["param"])) if g.get("param") in C.STATS else 0
    return 1.0 if g.get("done_day") else 0.0


def overview(store, hero_id: int, today: date) -> dict:
    goals = _events(store, hero_id, today)
    since = min([g["start"] for g in goals.values()], default=today)
    if any(g["metric"] == "orm" for g in goals.values()):
        since = date(2000, 1, 1)                        # la charge maximale regarde tout l'historique
    hero, acts = PG._accepted(store, hero_id, today, since)
    out = []
    for g in goals.values():
        val = _value(g, hero, acts)
        target = g["target"]
        reached = val >= target or bool(g.get("done_day"))
        deadline = date.fromisoformat(g["deadline"]) if g.get("deadline") else None
        state = "atteint" if reached else ("dépassé" if deadline and today > deadline else "en cours")
        label, unit, _ = METRICS[g["metric"]]
        if g["metric"] == "rank":
            shown, tshown = C.RANKS[int(val)], C.RANKS[int(target)]
        else:
            shown, tshown = f"{val:.1f}".rstrip("0").rstrip(".").replace(".", ","), f"{target:g}".replace(".", ",")
        days_left = (deadline - today).days if deadline else None
        pace = None
        if state == "en cours" and deadline and days_left and g["metric"] not in ("rank", "manual", "orm"):
            pace = round((target - val) / max(1, days_left) * 7, 1)       # à faire par semaine
        out.append({"id": g["id"], "title": g["title"], "metric": g["metric"], "metric_label": label, "unit": unit,
                    "param": g.get("param"), "value": round(val, 2), "target": target, "shown": shown, "target_shown": tshown,
                    "pct": 100 if reached else round(100 * min(1.0, val / target), 0) if target else 0,
                    "start": g["start"].isoformat(), "deadline": g.get("deadline"), "days_left": days_left,
                    "state": state, "per_week": pace, "manual": g["metric"] == "manual"})
    order = {"en cours": 0, "dépassé": 1, "atteint": 2}
    out.sort(key=lambda x: (order[x["state"]], x["deadline"] or "9999"))
    return {"goals": out, "metrics": [{"id": k, "label": v[0], "unit": v[1], "help": v[2]} for k, v in METRICS.items()],
            "stats": C.STATS, "ranks": C.RANKS, "max": MAX_GOALS}


def action(store, hero_id: int, today: date, body: dict) -> str:
    act = body.get("action")
    goals = _events(store, hero_id, today)
    if act == "add":
        title = str(body.get("title", "")).strip()[:80]
        metric = body.get("metric")
        if metric not in METRICS:
            raise ValueError("Choisis ce que tu veux mesurer")
        if len(goals) >= MAX_GOALS:
            raise ValueError(f"{MAX_GOALS} objectifs au plus : supprime-en un")
        param = None
        if metric == "rank":
            param = body.get("param")
            if param not in C.STATS:
                raise ValueError("Choisis la stat")
            if body.get("target") not in C.RANKS[1:]:
                raise ValueError("Choisis le rang visé (D à S)")
            target = float(C.RANKS.index(body["target"]))
        elif metric == "manual":
            target = 1.0
        else:
            try:
                target = float(str(body.get("target", "")).replace(",", "."))
            except ValueError:
                raise ValueError("Valeur visée : un nombre")
            if not 0 < target <= 100000:
                raise ValueError("Valeur visée : un nombre positif")
            if metric == "orm":
                param = str(body.get("param", "")).strip()[:60]
                if not param:
                    raise ValueError("Indique l'exercice (ex. squat)")
        if not title:
            title = (f"Rang {body['target']} en {param}" if metric == "rank" else
                     f"{METRICS[metric][0]} : {target:g} {METRICS[metric][1]}".replace(".", ",").strip())
        deadline = body.get("deadline") or None
        if deadline:
            try:
                dl = date.fromisoformat(deadline)
            except ValueError:
                raise ValueError("Date limite invalide")
            if dl <= today:
                raise ValueError("La date limite doit être dans le futur")
            if (dl - today).days > 3 * 366:
                raise ValueError("Date limite : 3 ans au plus")
        store._event(hero_id, today, "goal", {"action": "add", "id": secrets.token_hex(4), "title": title, "metric": metric,
                                              "param": param, "target": target, "deadline": deadline})
        return f"Objectif « {title} » fixé."
    gid = body.get("id")
    if gid not in goals:
        raise ValueError("Objectif inconnu")
    if act == "del":
        store._event(hero_id, today, "goal", {"action": "del", "id": gid})
        return "Objectif supprimé."
    if act == "done":
        if goals[gid]["metric"] != "manual":
            raise ValueError("Cet objectif se mesure tout seul avec tes saisies")
        if goals[gid]["done_day"]:
            raise ValueError("Déjà atteint")
        store._event(hero_id, today, "goal", {"action": "done", "id": gid})
        return "Bravo, objectif atteint !"
    raise ValueError("Action inconnue")
