"""Collection de lieux et carnet de sortie (Expédition), relus depuis les saisies acceptées."""
from datetime import date

from . import config as C
from . import programs as PG

COT_ORDER = list(C.EXPEDITION_COTATION)


def collection(store, hero_id: int, today: date) -> dict:
    hero, acts = PG._accepted(store, hero_id, today, date(2000, 1, 1))
    places: dict[str, dict] = {}
    log = []
    for d, kind, data, proof in acts:
        if kind != "expedition":
            continue
        name = str(data.get("place") or "").strip()
        entry = {"day": d.isoformat(), "place": name or None, "km": data.get("distance_km", 0), "dplus": data.get("elevation_m", 0),
                 "cotation": data.get("cotation"), "weather": data.get("weather"), "companions": data.get("companions"),
                 "note": data.get("note"), "gpx": proof == "gpx", "type": data.get("place_type")}
        log.append(entry)
        if not name:
            continue
        key = name.lower()
        p = places.setdefault(key, {"name": name, "first": d.isoformat(), "last": d.isoformat(), "visits": 0, "km": 0.0,
                                    "dplus_max": 0, "cotation": None, "type": None})
        p["visits"] += 1
        p["last"] = d.isoformat()
        p["km"] += entry["km"] or 0
        p["dplus_max"] = max(p["dplus_max"], entry["dplus"] or 0)
        if entry["cotation"] in COT_ORDER and (p["cotation"] is None or COT_ORDER.index(entry["cotation"]) > COT_ORDER.index(p["cotation"])):
            p["cotation"] = entry["cotation"]
        if entry["type"] in C.PLACE_TYPES:
            p["type"] = entry["type"]
    items = sorted(places.values(), key=lambda p: p["first"], reverse=True)
    for p in items:
        p["km"] = round(p["km"], 1)
        p["type_label"] = C.PLACE_TYPES.get(p["type"], "Non précisé")
    by_type: dict[str, int] = {}
    for p in items:
        by_type[p["type_label"]] = by_type.get(p["type_label"], 0) + 1
    return {"places": items, "count": len(items), "by_type": by_type,
            "types": C.PLACE_TYPES, "logbook": [e for e in reversed(log) if e["note"] or e["weather"] or e["companions"]][:60],
            "outings": len(log), "km": round(sum(e["km"] or 0 for e in log), 1), "dplus": round(sum(e["dplus"] or 0 for e in log))}
