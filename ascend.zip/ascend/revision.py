"""Fiches de révision : les thèmes où l'on s'est trompé, et un entraînement sur D'AUTRES questions.

- Chaque quiz de matière, examen ou test de placement enregistre les questions ratées (événement
  « mistakes »). Pour un examen ou un placement, les réponses restent cachées : ces questions-là
  ne sont jamais proposées à l'entraînement (on ne doit pas pouvoir apprendre la réponse par cœur).
- Une fiche = un thème (revision_themes) avec ses erreurs récentes, ce qu'il couvre, des ressources
  fiables et un entraînement de 6 questions du même thème, corrigées, sans XP.
- Un entraînement réussi (5/6 ou plus) marque le thème comme revu, jusqu'à la prochaine erreur.
"""
import json
import random
from datetime import date, timedelta

from . import bookquiz as BQ
from . import config as C
from . import cursus as CU
from . import revision_themes as RT

WINDOW_DAYS = 60            # erreurs prises en compte
PRACTICE_QUESTIONS = 6
PRACTICE_PASS = 5
PRACTICE_PER_DAY = 1        # un entraînement par thème et par jour


def _question(qid: str) -> dict | None:
    tier, _, idx = qid.partition("#")
    w = BQ.subjects().get(tier)
    if w is None or not idx.isdigit() or int(idx) >= len(w["questions"]):
        return None
    return w["questions"][int(idx)]


def record(store, hero_id: int, day: date, chain: str, wrong: list[str], source: str, hidden: bool) -> None:
    wrong = [q for q in wrong if _question(q)]
    if wrong and chain in C.SUBJECT_CHAINS:
        store._event(hero_id, day, "mistakes", {"chain": chain, "wrong": wrong, "source": source, "hidden": hidden})


def _events(store, hero_id: int, today: date):
    since = (today - timedelta(days=WINDOW_DAYS)).isoformat()
    return [(date.fromisoformat(r["day"]), r["type"], json.loads(r["payload"])) for r in store.db.execute(
        "SELECT day, type, payload FROM events WHERE hero_id=? AND type IN ('mistakes', 'revision_practice') "
        "AND day>? AND day<=? ORDER BY day, id", (hero_id, since, today.isoformat()))]


def hidden_ids(store, hero_id: int, today: date) -> set[str]:
    return {q for _d, t, p in _events(store, hero_id, today) if t == "mistakes" and p.get("hidden") for q in p["wrong"]}


def overview(store, hero_id: int, today: date) -> dict:
    themes: dict[tuple[str, str], dict] = {}
    for d, typ, p in _events(store, hero_id, today):
        chain = p.get("chain")
        if typ == "mistakes":
            for qid in p.get("wrong", []):
                q = _question(qid)
                if q is None:
                    continue
                tid = RT.theme_of(chain, q)
                th = themes.setdefault((chain, tid), {"errors": 0, "last": d, "practices": [], "revised": None})
                th["errors"] += 1
                th["last"] = d
        elif typ == "revision_practice":
            th = themes.setdefault((chain, p.get("theme")), {"errors": 0, "last": d, "practices": [], "revised": None})
            th["practices"].append({"day": d.isoformat(), "good": p.get("good"), "total": p.get("total")})
            if p.get("good", 0) >= PRACTICE_PASS:
                th["revised"] = d
                th["errors"] = 0                       # revu : on repart de zéro jusqu'à la prochaine erreur
    out = []
    for (chain, tid), th in themes.items():
        info = RT.theme_info(chain, tid)
        done_today = sum(1 for p in th["practices"] if p["day"] == today.isoformat())
        out.append({"chain": chain, "subject": C.SUBJECT_CHAINS[chain], "theme": tid, "label": info["label"],
                    "desc": info["desc"], "errors": th["errors"], "last": th["last"].isoformat(),
                    "revised": th["revised"].isoformat() if th["revised"] else None,
                    "practices": th["practices"][-5:][::-1], "practice_available": done_today < PRACTICE_PER_DAY,
                    "resources": RT.RESOURCES.get(chain, [])})
    todo = sorted((t for t in out if t["errors"] > 0), key=lambda t: (-t["errors"], t["last"]), reverse=False)
    done = sorted((t for t in out if t["errors"] == 0 and t["revised"]), key=lambda t: t["revised"], reverse=True)
    return {"todo": todo, "done": done[:20], "pass": PRACTICE_PASS, "questions": PRACTICE_QUESTIONS}


def draw_practice(store, hero_id: int, today: date, chain: str, theme: str, rnd: random.Random | None = None) -> list[dict]:
    """6 questions du thème, au palier actuel et en dessous, sans les questions ratées à réponse cachée."""
    if chain not in C.SUBJECT_CHAINS:
        raise ValueError("Matière inconnue")
    st = CU.chain_state(store, hero_id, today, chain)
    if not st.get("current"):
        raise ValueError("Passe d'abord le test de placement de cette matière")
    current = st["current"]["level"]
    excluded = hidden_ids(store, hero_id, today) | set(store.reported_questions())
    pool_cur, pool_low = [], []
    for w in CU.chain_quizzes(chain):
        if CU.LEVELS.index(w["type"]) > CU.LEVELS.index(current):
            continue
        for q in w["questions"]:
            if q["id"] in excluded or RT.theme_of(chain, q) != theme:
                continue
            (pool_cur if w["type"] == current else pool_low).append((w["type"], q))
    rnd = rnd or random.Random()
    rnd.shuffle(pool_cur)
    rnd.shuffle(pool_low)
    picked = (pool_cur + pool_low)[:PRACTICE_QUESTIONS]
    if len(picked) < 3:
        raise ValueError("Pas encore assez de questions sur ce thème pour t'entraîner")
    return [CU._shuffle(q, rnd, lvl) for lvl, q in picked]
