"""Profil santé : handicaps et maladies qui changent ce qu'on peut raisonnablement attendre.

Chaque situation a des EFFETS, appliqués partout dans l'application :
- facteurs physiques (haut, bas, cardio, souplesse, équilibre, coordination, outing) : cibles des
  épreuves A/S, volume des quêtes et des programmes ;
- focus, works (livres), nights (bonnes nuits), meditation : cibles des épreuves de régularité ;
- quiz_time : temps par question des quiz (livres, matières, évaluation) ;
- dormant_days : délai avant qu'une stat s'endorme (maladies qui évoluent par poussées).

Plusieurs situations cochées : pour chaque effet, on garde la valeur la plus favorable
(pas de cumul : deux situations « −40 % » ne donnent pas −80 %).
Ces ajustements sont indicatifs et ne remplacent pas l'avis d'un médecin.
"""
from . import bookquiz as BQ

CATEGORIES = {
    "moteur": "Mobilité et moteur",
    "sens": "Vue et audition",
    "apprentissage": "Apprentissage et attention",
    "mental": "Santé mentale",
    "chronique": "Maladies chroniques",
    "sommeil": "Sommeil",
}

PHYS = ("haut", "bas", "cardio", "souplesse", "équilibre", "coordination", "outing")


def _all_phys(f: float, **extra) -> dict:
    return {**{d: f for d in PHYS}, **extra}


# id: (nom, catégorie, alias de recherche, effets, explication)
CONDITIONS: dict[str, tuple[str, str, list[str], dict, str]] = {
    # ---- mobilité et moteur
    "fauteuil": ("Utilisation d'un fauteuil roulant", "moteur", ["paraplégie", "paralysie", "handisport"],
                 {"haut": 0.8, "bas": 0.0, "cardio": 0.5, "souplesse": 0.5, "équilibre": 0.0, "coordination": 0.5, "outing": 0.3},
                 "Épreuves jambes et équilibre remplacées par le haut du corps ; sorties raccourcies."),
    "amputation_mi": ("Amputation d'un membre inférieur", "moteur", ["prothèse", "jambe"],
                      {"bas": 0.4, "cardio": 0.6, "équilibre": 0.4, "coordination": 0.6, "outing": 0.5, "souplesse": 0.8},
                      "Jambes, course et équilibre allégés."),
    "amputation_ms": ("Amputation d'un membre supérieur", "moteur", ["prothèse", "bras", "main"],
                      {"haut": 0.4, "coordination": 0.5, "souplesse": 0.8},
                      "Haut du corps et coordination allégés."),
    "hemiplegie": ("Hémiplégie / séquelles d'AVC", "moteur", ["avc", "accident vasculaire"],
                   _all_phys(0.5, focus=0.8, dormant_days=180), "Toutes les cibles physiques à moitié, concentration allégée."),
    "imc": ("Paralysie cérébrale (IMC)", "moteur", ["infirmité motrice cérébrale", "paralysie"],
            _all_phys(0.5, quiz_time=1.25), "Cibles physiques à moitié, plus de temps aux quiz."),
    "sep": ("Sclérose en plaques", "moteur", ["sep", "poussées"],
            _all_phys(0.6, focus=0.8, dormant_days=180), "Cibles allégées ; une stat met 6 mois à s'endormir (poussées)."),
    "myopathie": ("Myopathie / maladie neuromusculaire", "moteur", ["dystrophie", "neuromusculaire"],
                  _all_phys(0.4, dormant_days=180), "Cibles physiques fortement allégées."),
    "arthrose": ("Arthrose / arthrite", "moteur", ["rhumatisme", "polyarthrite", "articulations"],
                 {"haut": 0.7, "bas": 0.7, "cardio": 0.8, "souplesse": 0.6, "coordination": 0.8, "outing": 0.7, "dormant_days": 150},
                 "Articulations ménagées : souplesse et charges allégées."),
    "dos": ("Douleurs de dos chroniques / hernie discale", "moteur", ["lombalgie", "hernie", "scoliose", "sciatique"],
            {"haut": 0.8, "bas": 0.7, "souplesse": 0.6, "outing": 0.8}, "Jambes et souplesse allégées."),
    "spondylarthrite": ("Spondylarthrite ankylosante", "moteur", ["spa", "rhumatisme inflammatoire"],
                        {"souplesse": 0.5, "bas": 0.8, "haut": 0.8, "cardio": 0.8, "outing": 0.8, "dormant_days": 180},
                        "Souplesse fortement allégée, poussées prises en compte."),
    # ---- vue et audition
    "malvoyance": ("Malvoyance", "sens", ["vue", "basse vision"],
                   {"équilibre": 0.7, "coordination": 0.7, "outing": 0.7, "quiz_time": 1.5, "works": 0.7},
                   "Plus de temps aux quiz, sorties et équilibre allégés."),
    "cecite": ("Cécité", "sens", ["aveugle", "non-voyant", "braille"],
               {"équilibre": 0.5, "coordination": 0.5, "outing": 0.5, "cardio": 0.8, "quiz_time": 2.0, "works": 0.6},
               "Deux fois plus de temps aux quiz (lecteur d'écran), sorties et équilibre allégés."),
    "surdite": ("Surdité / malentendance", "sens", ["sourd", "malentendant", "audition", "lsf"],
                {"équilibre": 0.9}, "Peu d'effets sur les épreuves ; dis-nous si quelque chose te gêne."),
    # ---- apprentissage et attention
    "dyslexie": ("Dyslexie", "apprentissage", ["dys", "lecture", "dysorthographie"],
                 {"quiz_time": 1.5, "works": 0.6}, "50 % de temps en plus aux quiz, moins de livres demandés aux épreuves."),
    "dyscalculie": ("Dyscalculie", "apprentissage", ["dys", "calcul", "maths"],
                    {"quiz_time": 1.4}, "Plus de temps aux quiz."),
    "dyspraxie": ("Dyspraxie", "apprentissage", ["dys", "tac", "coordination"],
                  {"coordination": 0.5, "équilibre": 0.7, "quiz_time": 1.3}, "Coordination et équilibre allégés, plus de temps aux quiz."),
    "dysphasie": ("Dysphasie", "apprentissage", ["dys", "langage"],
                  {"quiz_time": 1.4, "works": 0.8}, "Plus de temps aux quiz."),
    "tdah": ("TDAH (trouble de l'attention)", "apprentissage", ["hyperactivité", "attention", "tda"],
             {"focus": 0.6, "meditation": 0.7, "quiz_time": 1.25, "works": 0.8},
             "Concentration : cibles à 60 % (sessions plus courtes), plus de temps aux quiz."),
    "tsa": ("Autisme (TSA)", "apprentissage", ["asperger", "tsa", "autiste"],
            {"quiz_time": 1.25, "coordination": 0.8}, "Plus de temps aux quiz."),
    "di": ("Déficience intellectuelle", "apprentissage", ["handicap mental"],
           {"quiz_time": 2.0, "works": 0.5, "focus": 0.6}, "Deux fois plus de temps aux quiz, objectifs de lecture allégés."),
    # ---- santé mentale
    "depression": ("Dépression", "mental", ["déprime", "humeur"],
                   {"focus": 0.7, "meditation": 0.7, "works": 0.8, "nights": 0.8, "cardio": 0.9, "dormant_days": 180},
                   "Régularité demandée allégée ; une stat met 6 mois à s'endormir."),
    "anxiete": ("Troubles anxieux", "mental", ["anxiété", "angoisse", "panique", "phobie"],
                {"focus": 0.8, "nights": 0.85, "quiz_time": 1.2}, "Un peu plus de temps aux quiz, régularité allégée."),
    "bipolarite": ("Troubles bipolaires", "mental", ["bipolaire"],
                   {"focus": 0.8, "nights": 0.75, "meditation": 0.8, "dormant_days": 180}, "Sommeil et régularité allégés."),
    "tspt": ("Stress post-traumatique (TSPT)", "mental", ["trauma", "ptsd"],
             {"focus": 0.8, "nights": 0.75, "meditation": 0.8}, "Sommeil et concentration allégés."),
    "toc": ("TOC", "mental", ["trouble obsessionnel"], {"focus": 0.85, "quiz_time": 1.2}, "Un peu plus de temps aux quiz."),
    "tca": ("Troubles du comportement alimentaire", "mental", ["anorexie", "boulimie", "tca"],
            _all_phys(0.7, nights=0.85), "Effort physique modéré : cibles à 70 %. Parles-en à ton médecin."),
    "schizophrenie": ("Schizophrénie", "mental", ["psychose"],
                      {"focus": 0.7, "nights": 0.8, "quiz_time": 1.3, "dormant_days": 180}, "Concentration et sommeil allégés."),
    # ---- maladies chroniques
    "asthme": ("Asthme", "chronique", ["respiration", "bronches"],
               {"cardio": 0.85, "outing": 0.85}, "Course et sorties un peu allégées."),
    "bpco": ("BPCO / insuffisance respiratoire", "chronique", ["poumons", "respiratoire"],
             {"cardio": 0.5, "outing": 0.5, "haut": 0.8, "bas": 0.8, "dormant_days": 150}, "Effort d'endurance fortement allégé."),
    "cardiaque": ("Maladie cardiaque", "chronique", ["cœur", "coeur", "insuffisance cardiaque", "arythmie"],
                  _all_phys(0.6, cardio=0.5, outing=0.5, dormant_days=150), "Efforts allégés ; demande l'accord de ton cardiologue."),
    "diabete": ("Diabète", "chronique", ["diabète type 1", "diabète type 2", "insuline"],
                {"cardio": 0.9, "outing": 0.85}, "Effets légers : pense à ta glycémie pendant l'effort."),
    "epilepsie": ("Épilepsie", "chronique", ["crises"],
                  {"équilibre": 0.8, "outing": 0.7, "nights": 0.85, "focus": 0.85}, "Sorties et équilibre allégés (sécurité)."),
    "fibromyalgie": ("Fibromyalgie", "chronique", ["douleurs chroniques"],
                     _all_phys(0.5, focus=0.8, nights=0.7, dormant_days=180), "Cibles physiques à moitié, sommeil allégé."),
    "endometriose": ("Endométriose", "chronique", ["règles douloureuses"],
                     _all_phys(0.75, dormant_days=150), "Cibles physiques allégées, poussées prises en compte."),
    "crohn": ("Maladie de Crohn / MICI", "chronique", ["rectocolite", "mici", "intestin"],
              _all_phys(0.7, dormant_days=180), "Cibles allégées, poussées prises en compte."),
    "cancer": ("Cancer (en traitement ou en rémission)", "chronique", ["chimiothérapie", "radiothérapie", "rémission"],
               _all_phys(0.4, focus=0.7, nights=0.7, works=0.7, dormant_days=240), "Tout est allégé : ton rythme d'abord."),
    "covid_long": ("Covid long / fatigue chronique", "chronique", ["encéphalomyélite", "sfc", "fatigue"],
                   _all_phys(0.4, focus=0.6, nights=0.7, dormant_days=240), "Effort fortement allégé ; évite les « rechutes » d'après-effort."),
    "sed": ("Syndrome d'Ehlers-Danlos", "chronique", ["sed", "hypermobilité"],
            {"haut": 0.6, "bas": 0.6, "cardio": 0.7, "souplesse": 1.0, "équilibre": 0.7, "coordination": 0.7, "outing": 0.6,
             "dormant_days": 180}, "Charges allégées (articulations), souplesse inchangée."),
    "migraine": ("Migraines chroniques", "chronique", ["céphalée", "maux de tête"],
                 {"focus": 0.8, "nights": 0.85, "dormant_days": 150}, "Concentration allégée."),
    "obesite": ("Obésité", "chronique", ["surpoids"],
                {"haut": 0.8, "bas": 0.7, "cardio": 0.7, "coordination": 0.8, "outing": 0.8}, "Course et jambes allégées au départ."),
    "drepanocytose": ("Drépanocytose", "chronique", ["anémie"],
                      _all_phys(0.6, dormant_days=180), "Effort allégé, hydrate-toi bien."),
    # ---- sommeil
    "insomnie": ("Insomnie chronique", "sommeil", ["sommeil", "insomniaque"],
                 {"nights": 0.6, "focus": 0.9}, "Bonnes nuits demandées aux épreuves : 60 %."),
    "apnee": ("Apnée du sommeil", "sommeil", ["ronflement", "ppc"],
              {"nights": 0.7, "cardio": 0.9}, "Bonnes nuits demandées aux épreuves : 70 %."),
    "narcolepsie": ("Narcolepsie / hypersomnie", "sommeil", ["somnolence"],
                    {"nights": 0.6, "focus": 0.7, "outing": 0.8}, "Sommeil et concentration allégés."),
    "travail_nuit": ("Travail de nuit / horaires décalés", "sommeil", ["poste", "3x8", "nuit"],
                     {"nights": 0.8}, "Bonnes nuits demandées : 80 % (ta régularité est jugée par type de poste)."),
    # ---- ancien réglage (« profil aménagé » coché avant le choix détaillé)
    "autre_physique": ("Autre situation physique", "moteur", ["handicap", "aménagé"],
                       _all_phys(0.6), "Cibles physiques à 60 %."),
    "autre_cognitif": ("Autre situation (apprentissage, attention, mémoire)", "apprentissage", ["handicap", "aménagé"],
                       {"quiz_time": 1.5, "focus": 0.7, "works": 0.7}, "Plus de temps aux quiz, objectifs allégés."),
}

DEFAULTS = {"quiz_time": 1.0, "dormant_days": 90}


def effects(ids) -> dict:
    """Effets combinés (valeur la plus favorable pour chaque effet)."""
    out: dict[str, float] = {}
    for cid in ids or ():
        if cid not in CONDITIONS:
            continue
        for k, v in CONDITIONS[cid][3].items():
            if k in ("quiz_time", "dormant_days"):
                out[k] = max(out.get(k, v), v)
            else:
                out[k] = min(out.get(k, v), v)
    return out


def factor(ids, dim: str) -> float:
    return effects(ids).get(dim, 1.0)


def quiz_time(ids) -> float:
    return effects(ids).get("quiz_time", 1.0)


def dormant_days(ids, default: int) -> int:
    return int(max(default, effects(ids).get("dormant_days", default)))


def catalog() -> dict:
    """Pour l'écran Profil : onglets par catégorie, recherche par nom et alias."""
    return {"categories": [{"id": k, "name": v} for k, v in CATEGORIES.items()],
            "conditions": [{"id": cid, "name": n, "category": cat, "search": BQ.norm(" ".join([n, *al])), "note": note}
                           for cid, (n, cat, al, eff, note) in CONDITIONS.items()]}


def describe(ids) -> list[str]:
    return [f"{CONDITIONS[c][0]} : {CONDITIONS[c][4]}" for c in ids if c in CONDITIONS]
