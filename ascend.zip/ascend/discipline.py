"""Discipline : transversale, jamais saisie à la main.

Part des quêtes prévues effectivement accomplies sur 28 jours, avec un poids
plus fort pour les jours récents. Les jours de repos déclarés sont neutres
(ni points ni pénalité) : se reposer n'abaisse pas la Discipline.
"""
from dataclasses import dataclass, field
from datetime import date

from . import config as C


@dataclass
class DisciplineTracker:
    days: dict[date, tuple[int, int, bool]] = field(default_factory=dict)

    def record_day(self, d: date, planned: int, done: int, rest: bool = False) -> None:
        self.days[d] = (planned, min(done, planned) if planned else 0, rest)

    def value(self, today: date) -> float:
        num = den = 0.0
        for d, (planned, done, rest) in self.days.items():
            age = (today - d).days
            if age < 0 or age >= C.DISCIPLINE_DAYS or rest or planned == 0:
                continue
            w = C.DISCIPLINE_DECAY ** age
            num += w * (done / planned)
            den += w
        return 0.0 if den == 0 else round(100 * num / den, 1)

    def streak(self, today: date, grace_per_week: int = 1) -> int:
        """Jours consécutifs 'tenus' (repos inclus), avec un jour de grâce par semaine."""
        streak, grace_used, week_marker = 0, 0, None
        d = today
        while True:
            rec = self.days.get(d)
            if rec is None:
                break
            planned, done, rest = rec
            ok = rest or planned == 0 or done >= planned
            wk = d.isocalendar()[:2]
            if wk != week_marker:
                week_marker, grace_used = wk, 0
            if ok:
                streak += 1
            elif grace_used < grace_per_week and done > 0:
                grace_used += 1
                streak += 1
            else:
                break
            d = date.fromordinal(d.toordinal() - 1)
        return streak
