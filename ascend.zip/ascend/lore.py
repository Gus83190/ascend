"""Histoire du héros (version provisoire) : un chapitre se débloque à chaque palier de niveau.

`{nom}` et `{classe}` sont remplacés par ceux du héros. Les textes sont originaux et pourront être
réécrits plus tard sans toucher au reste : seul le niveau requis compte pour le déblocage.
"""

CHAPTERS = [
    (1, "L'Éveil", [
        "{nom} ouvre les yeux au pied d'une tour si haute que son sommet se perd dans les nuages. Personne ne sait qui l'a bâtie. "
        "Les anciens l'appellent simplement l'Ascension.",
        "Une voix sans visage résonne : « Chaque effort réel te fera monter d'une marche. Le mensonge ne pèse rien ici. » "
        "Sur le sol, une plaque gravée porte un seul mot : {classe}."]),
    (3, "Le Premier Palier", [
        "Les premières marches sont rudes. Les jambes brûlent, le souffle manque. Mais à chaque séance, la pierre sous les pieds "
        "de {nom} devient un peu plus familière.",
        "Au premier palier, une lanterne s'allume d'elle-même. La voix murmure : « La régularité est une flamme. Nourris-la chaque jour. »"]),
    (6, "Les Sept Portes", [
        "Le couloir s'ouvre sur sept portes. Sur chacune, un symbole : un poing, un cœur qui bat, une plume, une feuille, un œil, "
        "une flamme calme, une boussole.",
        "{nom} comprend que la Tour ne se gravit pas d'un seul côté. Force, Endurance, Agilité, Vitalité, Intelligence, Mental, "
        "Expédition : chaque porte mène plus haut, mais aucune ne mène au sommet seule."]),
    (10, "Le Gardien de Bronze", [
        "Un colosse de bronze barre l'escalier. Il ne combat pas : il observe. « Beaucoup arrivent ici en courant, puis s'arrêtent. "
        "Ceux qui passent sont ceux qui reviennent, même les jours sans envie. »",
        "Il s'écarte. Sur son armure, {nom} aperçoit des centaines de noms gravés, et des centaines de places encore vides."]),
    (15, "La Bibliothèque Suspendue", [
        "Des livres flottent dans l'air comme des oiseaux endormis. Quand {nom} en saisit un, ses pages s'illuminent, "
        "puis interrogent : « M'as-tu vraiment lu ? »",
        "Ici, on ne monte qu'avec ce qu'on a compris. La bibliothèque garde le souvenir de chaque lecture, et l'oubli n'a pas sa place."]),
    (20, "Le Jardin des Souffles", [
        "Un jardin silencieux, au milieu de la Tour. L'air y est si calme qu'on entend son propre cœur. "
        "Une vieille femme y respire, lentement, depuis on ne sait combien d'années.",
        "« Tu cherches toujours à monter plus vite, {nom}. Assieds-toi. Celui qui maîtrise son souffle maîtrise sa montée. »"]),
    (30, "Les Terres Oubliées", [
        "Une fenêtre de la Tour donne sur des terres que personne n'a cartographiées : forêts, crêtes, villes en ruine. "
        "{nom} comprend que l'Ascension ne se fait pas seulement entre ces murs.",
        "Chaque lieu découvert dehors ajoute une pierre à l'escalier. La carte du héros commence à se dessiner."]),
    (40, "Le Miroir", [
        "Une salle vide, un seul miroir. Le reflet de {nom} n'imite pas ses gestes : il le regarde, avec les yeux de ses débuts.",
        "« Te souviens-tu de la première marche ? » Le reflet sourit, puis s'efface. Le chemin parcouru est plus long qu'il n'y paraît."]),
    (55, "La Tempête", [
        "Le vent se lève dans la Tour. Les marches tremblent, les lanternes vacillent. Des grimpeurs redescendent, épuisés.",
        "{nom} s'accroche. Les jours difficiles font partie de l'Ascension ; ce ne sont pas eux qui comptent, mais le jour d'après."]),
    (70, "Le Conseil des Rangs", [
        "Au soixante-dixième palier, six silhouettes attendent, chacune marquée d'une lettre : E, D, C, B, A, S.",
        "« Les rangs ne se donnent pas, {nom}. Ils se prouvent. » Les épreuves s'ouvrent devant le héros, plus exigeantes que jamais."]),
    (85, "Au-dessus des Nuages", [
        "La Tour dépasse enfin les nuages. Le monde, en bas, paraît minuscule et immense à la fois.",
        "{nom} n'est plus la personne qui s'est éveillée au pied de l'escalier. Le corps, l'esprit et la volonté ont changé."]),
    (100, "Le Sommet (provisoire)", [
        "Au sommet, il n'y a ni trône ni trésor. Seulement une porte ouverte sur un autre escalier, plus haut encore.",
        "La voix revient, une dernière fois : « L'Ascension ne finit pas, {nom}. Elle continue avec toi. » "
        "(La suite de l'histoire sera écrite plus tard.)"]),
]


def chapters(hero) -> dict:
    lvl, out = hero.level, []
    for i, (need, title, paras) in enumerate(CHAPTERS):
        unlocked = lvl >= need
        out.append({"n": i + 1, "title": title, "level": need, "unlocked": unlocked,
                    "text": [p.format(nom=hero.name, classe=hero.hero_class) for p in paras] if unlocked else []})
    nxt = next((c for c in out if not c["unlocked"]), None)
    return {"level": lvl, "chapters": out, "unlocked": sum(c["unlocked"] for c in out),
            "next": {"title": nxt["title"], "level": nxt["level"]} if nxt else None, "provisional": True}
