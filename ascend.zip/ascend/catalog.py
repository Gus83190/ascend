"""Catalogue des exercices à variantes (Force au poids du corps, Agilité).

Chaque famille indique la stat qu'elle fait progresser (`stat`).

Toutes les variantes sont accessibles dès le premier jour : l'échelle ne verrouille
rien, elle donne seulement une VALEUR à chaque variante.

`coef` = valeur d'une répétition (ou d'une seconde de maintien) en « équivalent
variante de référence » : une pompe archer vaut environ 2,5 pompes classiques.
`unit` = "reps" (répétitions) ou "s" (secondes de maintien, pour le gainage).
Une variante est « maîtrisée » quand une série atteint `mastery` répétitions / secondes.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Variant:
    id: str
    name: str
    coef: float
    mastery: int


FAMILIES: dict[str, dict] = {
    "poussée": {"stat": "Force", "unit": "reps", "variants": [
        Variant("mur", "Pompes contre un mur ou une table", 0.3, 20),
        Variant("genoux", "Pompes sur les genoux", 0.6, 20),
        Variant("classique", "Pompes classiques", 1.0, 20),
        Variant("declinee", "Pompes déclinées (pieds surélevés)", 1.3, 15),
        Variant("diamant", "Pompes diamant", 1.4, 15),
        Variant("archer", "Pompes archer", 2.5, 10),
        Variant("pseudo_planche", "Pompes pseudo-planche", 3.0, 10),
        Variant("un_bras", "Pompes sur un bras", 5.0, 5),
    ]},
    "jambes": {"stat": "Force", "unit": "reps", "variants": [
        Variant("squat", "Squat au poids du corps", 0.6, 30),
        Variant("fente", "Fentes alternées", 0.8, 20),
        Variant("squat_saute", "Squats sautés", 1.0, 20),
        Variant("bulgare", "Squat bulgare (pied arrière sur une chaise)", 1.4, 15),
        Variant("shrimp", "Shrimp squat", 2.0, 10),
        Variant("pistol_assiste", "Pistol squat assisté", 2.5, 10),
        Variant("pistol", "Pistol squat", 4.0, 10),
    ]},
    "tirage": {"stat": "Force", "unit": "reps", "variants": [
        Variant("rowing_table", "Rowing sous une table", 0.5, 20),
        Variant("australienne", "Traction australienne (barre basse)", 0.8, 20),
        Variant("negative", "Tractions négatives (descente lente)", 1.2, 10),
        Variant("traction", "Tractions strictes", 2.0, 15),
        Variant("archer", "Tractions archer", 3.5, 8),
        Variant("un_bras_assiste", "Traction à un bras assistée", 4.5, 5),
        Variant("un_bras", "Traction à un bras", 7.0, 3),
    ]},
    "gainage": {"stat": "Force", "unit": "s", "variants": [
        Variant("planche_genoux", "Planche sur les genoux", 0.4, 60),
        Variant("planche", "Planche", 0.7, 90),
        Variant("laterale", "Planche latérale", 0.9, 60),
        Variant("hollow", "Hollow body", 1.2, 60),
        Variant("l_sit", "L-sit", 2.0, 30),
        Variant("dragon_flag", "Dragon flag (négatif)", 3.0, 15),
        Variant("front_lever_tuck", "Front lever groupé", 3.5, 15),
    ]},
    # ---------------------------------------------------------------- Agilité
    "souplesse": {"stat": "Agilité", "unit": "s", "variants": [   # secondes tenues dans la position
        Variant("flexion_tibias", "Flexion avant, mains aux tibias", 0.4, 60),
        Variant("orteils", "Toucher les orteils, jambes tendues", 0.7, 60),
        Variant("paumes_sol", "Paumes à plat au sol", 1.0, 60),
        Variant("pancake", "Pancake (écart assis, buste vers l'avant)", 1.4, 60),
        Variant("ecart_assiste", "Grand écart assisté (sur des livres ou coussins)", 2.0, 60),
        Variant("grand_ecart", "Grand écart complet", 3.5, 30),
    ]},
    "équilibre": {"stat": "Agilité", "unit": "s", "variants": [
        Variant("unipodal", "Sur une jambe, yeux ouverts", 0.4, 60),
        Variant("unipodal_ferme", "Sur une jambe, yeux fermés", 0.9, 30),
        Variant("coussin", "Sur une jambe, sur un coussin", 1.2, 60),
        Variant("arabesque", "Arabesque (buste à l'horizontale)", 1.5, 30),
        Variant("ATR_mur", "Équilibre sur les mains contre un mur", 2.5, 60),
        Variant("ATR", "Équilibre sur les mains libre", 5.0, 15),
    ]},
    "coordination": {"stat": "Agilité", "unit": "s", "variants": [   # secondes sans faute
        Variant("corde_joints", "Corde à sauter, pieds joints", 0.4, 120),
        Variant("corde_course", "Corde à sauter, pas de course", 0.6, 120),
        Variant("corde_croises", "Corde à sauter, bras croisés", 1.2, 60),
        Variant("double_under", "Doubles sauts à la corde", 2.5, 30),
        Variant("triple_under", "Triples sauts à la corde", 5.0, 10),
    ]},
    "explosivité": {"stat": "Agilité", "unit": "reps", "variants": [
        Variant("sauts_joints", "Sauts sur place pieds joints", 0.4, 20),
        Variant("sauts_groupes", "Sauts groupés (genoux à la poitrine)", 1.0, 15),
        Variant("burpees", "Burpees", 1.2, 20),
        Variant("longueur", "Sauts en longueur sans élan", 1.5, 10),
        Variant("burpees_groupes", "Burpees avec saut groupé", 2.0, 15),
        Variant("pompes_claquees", "Pompes claquées", 2.5, 10),
        Variant("saut_muret", "Saut sur un muret haut (≥ 75 cm)", 3.0, 10),
    ]},
}


def families_of(stat: str) -> list[str]:
    return [f for f, info in FAMILIES.items() if info["stat"] == stat]

# Répétitions / secondes au-delà desquelles une série n'augmente plus la capacité :
# on progresse alors en passant à la variante suivante, pas en allongeant la série.
CAPACITY_CAP = {"reps": 30, "s": 120}
CAPACITY_DIVISOR = {"reps": 30, "s": 60}


def variant(family: str, variant_id: str) -> Variant:
    for v in FAMILIES[family]["variants"]:
        if v.id == variant_id:
            return v
    raise KeyError(f"Variante inconnue : {family}/{variant_id}")


def capacity(family: str, variant_id: str, amount: float) -> float:
    """Capacité d'une série, comparable entre variantes (même principe que la 1RM estimée)."""
    unit = FAMILIES[family]["unit"]
    a = min(amount, CAPACITY_CAP[unit])
    return variant(family, variant_id).coef * (1 + a / CAPACITY_DIVISOR[unit])


def index_of(family: str, variant_id: str) -> int:
    return [v.id for v in FAMILIES[family]["variants"]].index(variant_id)


# ------------------------------------------------------------------ Force avec charges
# Exercices courants (nom canonique → variantes d'écriture). Un nom libre reste accepté, mais il est
# toujours ramené en minuscules sans espaces doublés : « Squat » et « squat » sont le même exercice.
LIFTS: dict[str, list[str]] = {
    "squat": ["squat barre", "back squat", "squat arrière"],
    "squat avant": ["front squat"],
    "développé couché": ["developpe couche", "dc", "bench", "bench press", "développé-couché"],
    "développé incliné": ["developpe incline", "incline bench"],
    "soulevé de terre": ["souleve de terre", "sdt", "deadlift"],
    "soulevé de terre roumain": ["sdt roumain", "romanian deadlift", "rdl"],
    "développé militaire": ["developpe militaire", "militaire", "overhead press", "ohp"],
    "rowing barre": ["rowing", "barbell row"],
    "rowing haltère": ["rowing haltere", "dumbbell row"],
    "tractions lestées": ["tractions lestees", "weighted pull-up"],
    "dips lestés": ["dips lestes", "weighted dips"],
    "hip thrust": ["hip-thrust"],
    "fentes haltères": ["fentes halteres", "fentes", "lunges"],
    "presse à cuisses": ["presse a cuisses", "presse", "leg press"],
    "tirage vertical": ["tirage poulie haute", "lat pulldown"],
    "curl biceps": ["curl", "curl barre", "curl haltères"],
    "extension triceps": ["barre au front", "skull crusher"],
    "élévations latérales": ["elevations laterales", "lateral raise"],
    "kettlebell swing": ["swing", "kb swing"],
}
_LIFT_ALIASES = {a: k for k, al in LIFTS.items() for a in [k, *al]}


def norm_lift(name: str) -> str:
    n = " ".join(str(name).strip().lower().split())
    return _LIFT_ALIASES.get(n, n)
