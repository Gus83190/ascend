"""Banque de QCM de lecture ASCEND.

Questions originales écrites pour ASCEND (aucun passage des œuvres n'est cité), rangées dans
`quiz_bank/*.json`. Chaque œuvre :
  {"id": "harry-potter-1", "title": "...", "author": "...", "type": "roman|jeunesse|fantasy|sf|
   classique|manga|bd|essai", "part": "tomes 1 à 3" (optionnel), "aliases": [...],
   "questions": [{"q": "...", "choices": [4 propositions], "answer": 0..3}, ...]}

Un quiz tire BOOK_QUIZ_QUESTIONS questions au hasard (hors questions signalées) ; il faut
BOOK_QUIZ_PASS bonnes réponses pour valider le livre.
"""
import json
import random
import unicodedata
from functools import lru_cache
from pathlib import Path

from . import config as C

BANK_DIR = Path(__file__).parent / "quiz_bank"
TYPES = {"roman": "Roman", "jeunesse": "Jeunesse", "fantasy": "Fantasy", "sf": "Science-fiction",
         "classique": "Classique", "manga": "Manga", "bd": "BD", "essai": "Essai", "policier": "Policier"}
CONTENT_OF_TYPE = {"manga": "manga", "bd": "manga", "essai": "essai"}   # coefficient de lecture associé


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode()
    return " ".join("".join(c if c.isalnum() else " " for c in text.lower()).split())


@lru_cache(maxsize=1)
def bank() -> dict[str, dict]:
    works: dict[str, dict] = {}
    for f in sorted(BANK_DIR.glob("*.json")):
        for w in json.loads(f.read_text(encoding="utf-8")):
            check_work(w)
            if w["id"] in works:
                raise ValueError(f"Œuvre en double dans la banque : {w['id']}")
            for i, q in enumerate(w["questions"]):
                q["id"] = f"{w['id']}#{i}"
            works[w["id"]] = w
    return works


def check_work(w: dict, types=None) -> None:
    """Contrôle de qualité d'une fiche (lancé au chargement et par les tests)."""
    types = TYPES if types is None else types
    for k in ("id", "title", "author", "type", "questions"):
        if not w.get(k):
            raise ValueError(f"Fiche incomplète ({k}) : {w.get('id')}")
    if w["type"] not in types:
        raise ValueError(f"Type inconnu {w['type']} : {w['id']}")
    if len(w["questions"]) < C.BOOK_QUIZ_QUESTIONS:
        raise ValueError(f"Pas assez de questions : {w['id']}")
    seen = set()
    for q in w["questions"]:
        ch = q.get("choices")
        if (not isinstance(q.get("q"), str) or not isinstance(ch, list) or len(ch) != 4
                or not all(isinstance(c, str) and c.strip() for c in ch)
                or len({" ".join(c.lower().split()) for c in ch}) != 4 or not isinstance(q.get("answer"), int) or not 0 <= q["answer"] < 4):
            raise ValueError(f"Question mal formée dans {w['id']} : {q.get('q')}")
        if norm(q["q"]) in seen:
            raise ValueError(f"Question en double dans {w['id']}")
        seen.add(norm(q["q"]))


def public(w: dict) -> dict:
    return {"id": w["id"], "title": w["title"], "author": w["author"], "type": TYPES[w["type"]],
            "part": w.get("part", ""), "questions": len(w["questions"])}


def search(query: str, limit: int = 12) -> list[dict]:
    q = norm(query)
    if len(q) < 2:
        return []
    words = q.split()
    scored = []
    for w in bank().values():
        hay = norm(" ".join([w["title"], w["author"], *w.get("aliases", [])]))
        if all(x in hay for x in words):
            start = norm(w["title"]).startswith(q)
            scored.append((0 if start else 1, w["title"], w))
    return [public(w) for _, _, w in sorted(scored, key=lambda t: (t[0], t[1]))[:limit]]


def catalog() -> list[dict]:
    return sorted((public(w) for w in bank().values()), key=lambda x: (x["type"], norm(x["title"])))


def draw(work_id: str, excluded: set[str], seed=None, source=None) -> list[dict]:
    """Tire les questions d'un quiz (hors questions signalées). Lève ValueError si impossible.
    `source` : banque à utiliser (livres par défaut, ou `subjects()`)."""
    w = (bank() if source is None else source).get(work_id)
    if w is None:
        raise ValueError("Quiz inconnu dans la banque")
    pool = [q for q in w["questions"] if q["id"] not in excluded]
    if len(pool) < C.BOOK_QUIZ_QUESTIONS:
        raise ValueError("Trop de questions signalées pour ce livre : quiz indisponible pour l'instant")
    rnd = random.Random(seed)
    picked = rnd.sample(pool, C.BOOK_QUIZ_QUESTIONS)
    out = []
    for q in picked:   # on mélange aussi l'ordre des réponses
        order = list(range(4))
        rnd.shuffle(order)
        out.append({"id": q["id"], "q": q["q"], "choices": [q["choices"][i] for i in order], "answer": order.index(q["answer"])})
    return out


# ------------------------------------------------------------------ quiz de matière (devoirs)
SUBJECT_DIR = BANK_DIR / "matieres"


@lru_cache(maxsize=1)
def subjects() -> dict[str, dict]:
    """Quiz de matière : {"id", "title" (matière), "author": "ASCEND", "type": niveau, "questions"}."""
    works: dict[str, dict] = {}
    extra: list[dict] = []
    for f in sorted(SUBJECT_DIR.glob("*.json")):
        for w in json.loads(f.read_text(encoding="utf-8")):
            if "extend" in w:                      # questions ajoutées à un palier existant (autre fichier)
                extra.append(w)
                continue
            check_work(w, C.SUBJECT_LEVELS)
            if w.get("subject") not in C.SUBJECT_CHAINS:
                raise ValueError(f"Matière inconnue : {w['id']}")
            if w["id"] in works or w["id"] in bank():
                raise ValueError(f"Quiz en double dans la banque : {w['id']}")
            works[w["id"]] = w
    for e in extra:
        if e["extend"] not in works:
            raise ValueError(f"Palier inconnu à compléter : {e['extend']}")
        works[e["extend"]]["questions"] = works[e["extend"]]["questions"] + e["questions"]
    for w in works.values():
        check_work(w, C.SUBJECT_LEVELS)       # contrôle aussi les doublons entre fichiers
        for i, q in enumerate(w["questions"]):
            q["id"] = f"{w['id']}#{i}"
    return works


def subject_catalog() -> list[dict]:
    return sorted(({"id": w["id"], "subject": C.SUBJECT_CHAINS[w["subject"]], "chain": w["subject"], "level": w["type"],
                    "level_label": C.LEVEL_LABELS[w["type"]], "questions": len(w["questions"]),
                    "difficulty": C.SUBJECT_LEVELS[w["type"]]} for w in subjects().values()),
                  key=lambda x: (list(C.SUBJECT_CHAINS).index(x["chain"]), list(C.SUBJECT_LEVELS).index(x["level"])))


def chains(passed: dict[str, int]) -> list[dict]:
    """Parcours par matière. `passed` : {id de quiz: nombre de réussites}. Le premier palier d'une
    matière est ouvert ; chaque palier suivant s'ouvre quand le précédent a été réussi une fois."""
    out: dict[str, dict] = {}
    for it in subject_catalog():
        ch = out.setdefault(it["chain"], {"chain": it["chain"], "subject": it["subject"], "levels": []})
        prev = ch["levels"][-1] if ch["levels"] else None
        reached = prev is None or prev["passed"] > 0
        ch["levels"].append({**it, "passed": passed.get(it["id"], 0), "reached": reached,
                             "requires": None if reached else prev["level_label"]})
    # Un seul palier jouable : le plus haut atteint. Revenir à un palier dépassé serait de l'XP facile.
    for ch in out.values():
        top = max(i for i, l in enumerate(ch["levels"]) if l["reached"])
        for i, l in enumerate(ch["levels"]):
            l["unlocked"] = i == top
            l["surpassed"] = i < top
        ch["current"] = ch["levels"][top]["level_label"]
    return list(out.values())


def find_question(qid: str) -> dict | None:
    work_id = str(qid).split("#")[0]
    w = bank().get(work_id) or subjects().get(work_id)
    return next((q for q in w["questions"] if q["id"] == qid), None) if w else None