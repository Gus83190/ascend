import sys

if hasattr(sys.stdout, "reconfigure"):   # accents et flèches corrects dans la console Windows
    sys.stdout.reconfigure(encoding="utf-8")
from datetime import date, time

from . import sim
from .engine import Hero, log, summary


def demo():
    h = Hero()
    d = date(2026, 3, 2)
    print("=== Démo : une journée d'Aria ===\n")
    for kind, data in [
        ("strength", dict(exercise="squat", sets=[(70, 8), (70, 8), (80, 5), (90, 3)])),
        ("reading", dict(minutes=30, quiz=0.86)),
        ("reading", dict(minutes=60, quiz=None)),
        ("endurance", dict(distance_km=5, minutes=30)),
        ("sleep", dict(bedtime=time(23, 10), hours=7.5)),
        ("focus", dict(minutes=50, interruptions=1)),
    ]:
        r = log(h, d, kind, **data)
        print(f"[{kind}] {r.stat} : +{r.granted:.0f} XP")
        for n in r.notes:
            print("   -", n)
    print("\nMême squat une semaine plus tard, 2,5 % plus lourd :")
    r = log(h, date(2026, 3, 9), "strength", exercise="squat", sets=[(72, 8), (72, 8), (82, 5), (92.5, 3)])
    print(f"[strength] +{r.granted:.0f} XP"); [print("   -", n) for n in r.notes]
    print("\n" + summary(h, d))


def force_demo():
    from . import catalog as K
    from .engine import assess, suggest
    h = Hero()
    d = date(2026, 3, 2)
    print("=== Catalogue des exercices à variantes (tout est ouvert dès le départ) ===")
    for fam, info in K.FAMILIES.items():
        unit = "s" if info["unit"] == "s" else "rép."
        print(f"\n{info['stat']} · {fam.capitalize()}")
        for v in info["variants"]:
            print(f"  ×{v.coef:<4} {v.name}  (maîtrisée à {v.mastery} {unit})")
    print("\n=== Évaluation de départ ===")
    for n in assess(h, d, {"poussée": ("classique", 18), "jambes": ("bulgare", 10),
                           "tirage": ("traction", 6), "gainage": ("planche", 75)}):
        print("   -", n)
    print("\n=== Séance du lendemain ===")
    for fam, vid, sets in [("poussée", "classique", [20, 16, 14]), ("jambes", "bulgare", [11, 10, 9]),
                           ("tirage", "traction", [6, 5, 5]), ("gainage", "planche", [80, 60])]:
        r = log(h, date(2026, 3, 3), "bodyweight", family=fam, variant=vid, sets=sets)
        print(f"[{fam}] +{r.granted:.0f} XP"); [print("   -", n) for n in r.notes]
    print("\nSaut improbable : tractions archer juste après des tractions classiques à 6 :")
    r = log(h, date(2026, 3, 5), "bodyweight", family="tirage", variant="archer", sets=[8, 7])
    print(f"[tirage] +{r.granted:.0f} XP"); [print("   -", n) for n in r.notes]
    print(f"\nVariante suggérée en poussée : {suggest(h, 'poussée').name}")
    print("\n" + summary(h, date(2026, 3, 5)))


def day_demo():
    """Deux jours avec la base SQLite : quêtes du jour, changement de quête, Discipline, sauvegarde."""
    import json
    import tempfile
    from datetime import timedelta
    from pathlib import Path
    from .store import Store
    tmp = Path(tempfile.mkdtemp(prefix="ascend-demo-"))
    s = Store(tmp / "ascend.db")
    h = s.create_hero("Aria", 62)
    d = date(2026, 3, 2)
    print(f"=== Base de démonstration : {tmp / 'ascend.db'} ===\n")
    print("Évaluation de départ :")
    for n in s.assess(h, d, {"poussée": ("classique", 18), "jambes": ("bulgare", 10),
                             "tirage": ("traction", 6), "gainage": ("planche", 75)}) + s.cooper(h, d, 2450):
        print("   -", n)

    def show(day):
        print(f"\nQuêtes du {day.strftime('%d/%m')} :")
        for r in s.daily_quests(h, day):
            print(f"   [{r['status']:>7}] #{r['id']} {r['stat']:<12} {r['title']}")

    show(d)
    from . import quests as Q
    first = s.daily_quests(h, d)[0]
    reason = Q.valid_reasons(s._quest(first))[0]
    print(f"\nAria change la quête #{first['id']} (raisons possibles : {', '.join(Q.valid_reasons(s._quest(first)))} ; choisie : {reason}) :")
    print("   →", s.swap_quest(h, first["id"], reason))
    show(d)
    print("\nAria fait ses quêtes :")
    for r in s.daily_quests(h, d):
        t, k = json.loads(r["target"]), r["kind"]
        data = {"bodyweight": dict(family=t.get("family"), variant=t.get("variant"), sets=[t.get("amount", 0)] * t.get("sets", 1)),
                "endurance": dict(distance_km=t.get("minutes", 0) / 6, minutes=t.get("minutes", 0)),
                "reading": dict(minutes=t.get("minutes", 0), quiz=0.8),
                "focus": dict(minutes=t.get("minutes", 0), interruptions=1, proof="app"),
                "meditation": dict(minutes=t.get("minutes", 0)),
                "sleep": dict(bedtime=time(23, 0), hours=7.8),
                "expedition": dict(distance_km=t.get("distance_km", 0), elevation_m=200, proof="gpx")}[k]
        res = s.record(h, d, k, **data)
        print(f"   [{k}] +{res.granted:.0f} XP — " + " · ".join(n for n in res.notes if n.startswith("Quête")))
    show(d)
    d2 = d + timedelta(days=1)
    print("\nLe lendemain, Aria déclare un jour de repos (neutre pour la Discipline).")
    s.rest(h, d2)
    hero = s.hero(h, until=d2)
    print(f"Discipline : {hero.discipline.value(d2):.0f} %")
    path = s.backup(tmp / "sauvegardes", today=d2)
    print(f"Sauvegarde du jour : {path}")
    print("\n" + summary(hero, d2))
    s.close()


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "demo"
    if cmd == "demo":
        demo()
    elif cmd == "jour":
        day_demo()
    elif cmd == "app":
        from .server import run
        run(sys.argv[2:])
    elif cmd == "force":
        force_demo()
    elif cmd == "sim":
        print(sim.report(sys.argv[2:] or sim.PROFILES))
    else:
        print("Usage : python -m ascend [app|demo|force|jour|sim [profil ...]]")
