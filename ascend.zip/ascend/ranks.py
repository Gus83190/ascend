from . import config as C


def rank_for(xp: float) -> str:
    r = "E"
    for name in C.RANKS:
        if xp >= C.RANK_THRESHOLDS[name]:
            r = name
    return r


def progress_to_next(xp: float) -> tuple[str, float, float]:
    """Retourne (rang actuel, fraction 0..1 vers le suivant, XP restante)."""
    cur = rank_for(xp)
    i = C.RANKS.index(cur)
    if i == len(C.RANKS) - 1:
        return cur, 1.0, 0.0
    lo = C.RANK_THRESHOLDS[cur]
    hi = C.RANK_THRESHOLDS[C.RANKS[i + 1]]
    return cur, (xp - lo) / (hi - lo), hi - xp


def level_for(total_xp: float) -> int:
    frac = min(1.0, max(0.0, total_xp / C.LEVEL_XP_REF))
    return 1 + int((C.LEVEL_MAX - 1) * frac ** C.LEVEL_EXPONENT)


def global_rank(stat_xp: dict[str, float]) -> str:
    """Rang global : moyenne des indices de rang des 7 stats (arrondi bas)."""
    idx = [C.RANKS.index(rank_for(v)) for v in stat_xp.values()]
    return C.RANKS[int(sum(idx) / len(idx))]
